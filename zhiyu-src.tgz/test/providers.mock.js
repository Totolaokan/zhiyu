// Dry run of the chat providers with a mocked fetch (no network, no real keys). node test/providers.mock.js
const assert = require('assert');
process.env.ANTHROPIC_API_KEY = 'test-key'; process.env.OPENROUTER_API_KEY = 'test-or'; process.env.DEEPSEEK_API_KEY = process.env.DEEPSEEK_API_KEY || 'test-ds';
const ai = require('../lib/ai'); const talk = require('../lib/talk');
const calls = []; let script = [];
ai._fetch = async (url, init) => { const body = JSON.parse(init.body); calls.push({ url, headers: init.headers, body }); const r = script.shift() || {};
  if (r.status) return { ok: false, status: r.status, text: async () => r.err || 'bad', json: async () => ({}) };
  if (/anthropic/.test(url)) return { ok: true, json: async () => ({ content: [{ type: 'thinking', thinking: '' }, { type: 'text', text: r.text }] }) };
  return { ok: true, json: async () => ({ choices: [{ message: { content: r.text } }] }) }; };
const hist = [{ role: 'ahe', text: '嗨，我是阿禾。' }, { role: 'ahe', text: '我该怎么叫你？' }, { role: 'user', text: 'toto' }, { role: 'ahe', text: '我猜是《绿野仙踪》那只小狗？' }];
(async () => {
  // 1. provider resolution
  process.env.CHAT_PROVIDER = 'anthropic'; delete process.env.CHAT_MODEL;
  assert.equal(ai.chatProvider(), 'anthropic'); assert.equal(ai.chatModel(), 'claude-sonnet-5-5'); assert.equal(ai.extractProvider(), 'deepseek');
  delete process.env.CHAT_PROVIDER; process.env.CHAT_MODEL = 'claude-sonnet-4-5'; assert.equal(ai.chatProvider(), 'anthropic'); assert.equal(ai.chatModel(), 'claude-sonnet-4-5');
  // 2. Claude 5 request shape: system top-level, alternating roles starting with user, no temperature, thinking off, low effort
  process.env.CHAT_PROVIDER = 'anthropic'; delete process.env.CHAT_MODEL;
  script = [{ text: '不对的话，那我猜《天堂电影院》里的小男孩。\n是他吗？' }];
  let r = await talk.reply({ meetTurns: 2 }, { name: 'toto' }, hist, '看电影取的');
  let c = calls.pop();
  assert.equal(c.url, 'https://api.anthropic.com/v1/messages'); assert.equal(c.headers['x-api-key'], 'test-key'); assert.equal(c.headers['anthropic-version'], '2023-06-01');
  assert.ok(c.body.system.startsWith('你是阿禾')); assert.equal(c.body.model, 'claude-sonnet-5-5');
  assert.equal(c.body.messages[0].role, 'user'); assert.equal(c.body.messages[0].content, '（打开了聊天）');
  c.body.messages.forEach((m, i) => i && assert.notEqual(m.role, c.body.messages[i - 1].role));
  assert.equal(c.body.messages[c.body.messages.length - 1].role, 'user');
  assert.equal(c.body.temperature, undefined); assert.deepEqual(c.body.thinking, { type: 'between_tools' }); assert.equal(c.body.output_config.effort, 'low');
  assert.deepEqual(r.messages, ['不对的话，那我猜《天堂电影院》里的小男孩。', '是他吗？']); assert.equal(r.retried, false);
  console.log('anthropic request ok:', JSON.stringify(c.body.messages).slice(0, 220));
  // 3. a 400 (e.g. params not accepted) -> one retry with plain params
  script = [{ status: 400, err: 'thinking not supported' }, { text: '那就是它了。\n你现在在哪个城市？' }];
  r = await talk.reply({ meetTurns: 3 }, { name: 'toto' }, hist, '对'); const [a1, a2] = calls.splice(-2);
  assert.ok(a1.body.thinking); assert.equal(a2.body.thinking, undefined); assert.equal(a2.body.output_config, undefined); assert.equal(r.messages[1], '你现在在哪个城市？');
  // 4. light post-check with Claude: a no-guess / abstract reply is NOT rewritten, a stacked question IS
  script = [{ text: '片子里什么让你记到现在？' }]; r = await talk.reply({ meetTurns: 3 }, {}, hist, '你猜'); assert.equal(r.retried, false);
  script = [{ text: '你在哪个城市？平时做什么？' }, { text: '你现在在哪个城市？' }]; r = await talk.reply({ meetTurns: 3 }, {}, hist, '嗯'); assert.equal(r.retried, true); assert.deepEqual(r.messages, ['你现在在哪个城市？']);
  assert.equal(calls[calls.length - 1].body.messages.slice(-1)[0].role, 'user');   // the rewrite note goes in as a user turn
  // 5. older Claude takes temperature
  process.env.CHAT_MODEL = 'claude-sonnet-4-5'; script = [{ text: '好。\n你在哪个城市？' }]; await talk.reply({ meetTurns: 3 }, {}, hist, '嗯');
  c = calls.pop(); assert.equal(c.body.temperature, 0.9); assert.equal(c.body.thinking, undefined); assert.equal(c.body.max_tokens, 400);
  // 6. OpenRouter path
  process.env.CHAT_PROVIDER = 'openrouter'; delete process.env.CHAT_MODEL; script = [{ text: '好。\n你在哪个城市？' }];
  r = await talk.reply({ meetTurns: 3 }, {}, hist, '嗯'); c = calls.pop();
  assert.equal(c.url, 'https://openrouter.ai/api/v1/chat/completions'); assert.equal(c.headers.Authorization, 'Bearer test-or'); assert.equal(c.body.model, 'anthropic/claude-sonnet-4.5'); assert.equal(c.body.messages[0].role, 'system');
  // 7. extraction stays on DeepSeek; EXTRACT_PROVIDER=anthropic moves it
  script = [{ text: '{"seeds":[],"profile":{"name":"toto"},"memory":[],"guess":""}' }];
  let j = await talk.extract({ history: hist, text: '看电影取的', seeds: [], profile: {}, known: '', allowGuess: false });
  assert.ok(/deepseek/.test(calls.pop().url)); assert.equal(j.profile.name, 'toto');
  process.env.EXTRACT_PROVIDER = 'anthropic'; script = [{ text: '好的：{"seeds":[],"profile":{},"memory":[],"guess":""}' }];
  j = await talk.extract({ history: hist, text: 'x', seeds: [], profile: {}, known: '', allowGuess: false }); assert.ok(/anthropic/.test(calls.pop().url)); assert.ok(j);
  console.log('ALL PROVIDER MOCK TESTS PASSED');
})().catch((e) => { console.error('FAIL', e); process.exit(1); });
