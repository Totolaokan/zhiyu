// 知遇 · single Node service: API + static frontend.
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const db = require('./lib/db');
const { q, one } = db;
const ai = require('./lib/ai');
const email = require('./lib/email');
const P = require('./lib/prompts');

/* ------------------------------------------------------------------ *
 * TEST_MODE=1  ->  the login code is returned by the API and shown ON
 * SCREEN. Anyone who knows an email can log in as it. Use only while
 * no email provider (RESEND_API_KEY + EMAIL_FROM) is configured, and
 * turn it off (TEST_MODE=0) before real users join.
 * ------------------------------------------------------------------ */
const TEST_MODE = process.env.TEST_MODE === '1';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || '';
const SECRET = process.env.SESSION_SECRET || crypto.createHash('sha256').update('zhiyu:' + ADMIN_PASSWORD + ':' + (process.env.DEEPSEEK_API_KEY || 'dev')).digest('hex');
const PORT = process.env.PORT || 3000;

const app = express();
if (process.env.TRUST_PROXY === '1' || process.env.RENDER) app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use((req, res, next) => { res.set('X-Content-Type-Options', 'nosniff'); res.set('Referrer-Policy', 'same-origin'); next(); });

/* ---------------- helpers ---------------- */
const sha = (s) => crypto.createHash('sha256').update(String(s)).digest('hex');
const hmac = (s) => crypto.createHmac('sha256', SECRET).update(String(s)).digest('hex');
const wrap = (fn) => (req, res) => Promise.resolve(fn(req, res)).catch((e) => { console.error(req.method, req.path, e); if (!res.headersSent) res.status(500).json({ error: 'SERVER_ERROR' }); });
const clip = P.clip;
const nowIso = () => new Date().toISOString();

function cookies(req) {
  const out = {};
  (req.headers.cookie || '').split(';').forEach((c) => { const i = c.indexOf('='); if (i > 0) out[c.slice(0, i).trim()] = decodeURIComponent(c.slice(i + 1).trim()); });
  return out;
}
function setCookie(req, res, name, value, maxAgeSec) {
  const secure = req.secure ? '; Secure' : '';
  res.append('Set-Cookie', `${name}=${encodeURIComponent(value)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAgeSec}${secure}`);
}

async function currentUser(req) {
  const t = cookies(req).zy_sid;
  if (!t) return null;
  const u = await one(`SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>now()`, [sha(t)]);
  return u;
}
const auth = (fn) => wrap(async (req, res) => {
  const u = await currentUser(req);
  if (!u) return res.status(401).json({ error: 'LOGIN_REQUIRED' });
  req.user = u;
  if (!u.last_seen || Date.now() - new Date(u.last_seen).getTime() > 60e3) q('UPDATE users SET last_seen=now() WHERE id=$1', [u.id]).catch(() => {});
  return fn(req, res);
});
function isAdmin(req) {
  const t = cookies(req).zy_admin; if (!t || !ADMIN_PASSWORD) return false;
  const [exp, sig] = t.split('.');
  if (!exp || !sig || Number(exp) < Date.now()) return false;
  const good = hmac('admin:' + exp);
  return sig.length === good.length && crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(good));
}
const admin = (fn) => wrap(async (req, res) => { if (!isAdmin(req)) return res.status(401).json({ error: 'ADMIN_REQUIRED' }); return fn(req, res); });
async function newSession(req, res, userId) {
  const token = crypto.randomBytes(32).toString('hex');
  await q(`INSERT INTO sessions (token_hash,user_id,expires_at) VALUES ($1,$2,now()+interval '60 days')`, [sha(token), userId]);
  setCookie(req, res, 'zy_sid', token, 60 * 86400);
}
const aiGuard = (req, res) => {
  if (!ai.configured()) { res.status(503).json({ error: 'AI_NOT_CONFIGURED' }); return false; }
  if (!ai.allow(req.user.id)) { res.status(429).json({ error: 'AI_RATE_LIMIT' }); return false; }
  return true;
};
const displayName = (u) => (u && u.name && u.name !== '朋友' ? u.name : '一位朋友');
const publicSummary = (s) => (s ? { headline: s.headline || '', about: s.about || '', traits: Array.isArray(s.traits) ? s.traits.slice(0, 5) : [] } : null);

/* ---------------- static ---------------- */
app.use('/fonts', express.static(path.join(__dirname, 'node_modules/@fontsource/instrument-serif/files'), { maxAge: '30d' }));
app.use('/build', express.static(path.join(__dirname, 'public/build'), { maxAge: '5m' }));
app.get('/healthz', (req, res) => res.json({ ok: true }));
app.get(['/admin', '/admin/'], (req, res) => res.sendFile(path.join(__dirname, 'public/admin.html')));

app.use('/api', express.json({ limit: '600kb' }));

/* ---------------- config & auth ---------------- */
app.get('/api/config', (req, res) => res.json({ testMode: TEST_MODE, emailConfigured: email.configured(), aiConfigured: ai.configured() }));

const ipHits = new Map();
app.post('/api/auth/request', wrap(async (req, res) => {
  const em = String((req.body || {}).email || '').trim().toLowerCase();
  if (!/^[^\s@]{1,64}@[^\s@]{1,190}\.[^\s@]{2,}$/.test(em)) return res.status(400).json({ error: 'BAD_EMAIL' });
  if (em.endsWith('.invalid')) return res.status(400).json({ error: 'BAD_EMAIL' });
  const ip = req.ip || 'x'; const h = ipHits.get(ip) || { t: Date.now(), n: 0 };
  if (Date.now() - h.t > 3600e3) { h.t = Date.now(); h.n = 0; } h.n++; ipHits.set(ip, h);
  if (h.n > 30) return res.status(429).json({ error: 'TOO_MANY' });
  const prev = await one('SELECT sent_at FROM login_codes WHERE email=$1', [em]);
  if (prev && Date.now() - new Date(prev.sent_at).getTime() < 40e3) return res.status(429).json({ error: 'WAIT', wait: 40 });
  const code = String(crypto.randomInt(0, 1e6)).padStart(6, '0');
  await q(`INSERT INTO login_codes (email,code_hash,expires_at,attempts,sent_at) VALUES ($1,$2,now()+interval '10 minutes',0,now())
    ON CONFLICT (email) DO UPDATE SET code_hash=EXCLUDED.code_hash, expires_at=EXCLUDED.expires_at, attempts=0, sent_at=now()`, [em, hmac(em + ':' + code)]);
  if (email.configured()) await email.sendCode(em, code);
  if (!email.configured() && !TEST_MODE) return res.status(503).json({ error: 'EMAIL_NOT_CONFIGURED' });
  res.json({ ok: true, ...(TEST_MODE ? { testCode: code } : {}) });
}));

app.post('/api/auth/verify', wrap(async (req, res) => {
  const em = String((req.body || {}).email || '').trim().toLowerCase();
  const code = String((req.body || {}).code || '').trim();
  const row = await one('SELECT * FROM login_codes WHERE email=$1', [em]);
  if (!row || new Date(row.expires_at) < new Date() || row.attempts >= 5) return res.status(400).json({ error: 'CODE_EXPIRED' });
  if (row.code_hash !== hmac(em + ':' + code)) { await q('UPDATE login_codes SET attempts=attempts+1 WHERE email=$1', [em]); return res.status(400).json({ error: 'CODE_WRONG' }); }
  await q('DELETE FROM login_codes WHERE email=$1', [em]);
  let u = await one('SELECT id FROM users WHERE email=$1', [em]);
  if (!u) u = await one('INSERT INTO users (email) VALUES ($1) RETURNING id', [em]);
  await newSession(req, res, u.id);
  res.json({ ok: true });
}));

app.post('/api/auth/logout', wrap(async (req, res) => {
  const t = cookies(req).zy_sid; if (t) await q('DELETE FROM sessions WHERE token_hash=$1', [sha(t)]);
  setCookie(req, res, 'zy_sid', '', 0); res.json({ ok: true });
}));

/* ---------------- me ---------------- */
async function photoIds(userId) { return (await q('SELECT id FROM photos WHERE user_id=$1 ORDER BY id', [userId])).map((r) => r.id); }

app.get('/api/me', auth(async (req, res) => {
  const u = req.user;
  res.json({ id: u.id, email: u.email, isTest: u.is_test, ob: u.ob || {}, prefs: u.prefs || {}, edit: u.edit || {}, summary: publicSummary(u.summary), photos: await photoIds(u.id) });
}));

app.put('/api/me/state', auth(async (req, res) => {
  const b = req.body || {}; const u = req.user;
  const ob = b.ob && typeof b.ob === 'object' ? b.ob : u.ob || {};
  if (ob.msgs && ob.msgs.length > 400) ob.msgs = ob.msgs.slice(-400);
  if (ob.log && ob.log.length > 200) ob.log = ob.log.slice(-200);
  ob.photos = []; // photos live in the photos table
  const prefs = b.prefs && typeof b.prefs === 'object' ? b.prefs : u.prefs || {};
  const edit = b.edit && typeof b.edit === 'object' ? b.edit : u.edit || {};
  const a = ob.ans || {};
  const seek = edit.seek || a.seek || null;
  const intent = edit.intent || a.intent || null;
  const INT = { '先交个朋友': 'friend', '轻松约会': 'date', '认真谈恋爱': 'serious', '以结婚为前提': 'marry', '成年人的轻松关系': 'casual', '还没想清楚': 'unsure' };
  await q(`UPDATE users SET ob=$2, prefs=$3, edit=$4, name=$5, gender=$6, seek=$7, city=$8, intent=$9, intent_k=$10, first_done=$11 WHERE id=$1`,
    [u.id, JSON.stringify(ob), JSON.stringify(prefs), JSON.stringify(edit), clip(edit.name || a.name || '', 40) || null, a.gender || null, seek,
      clip(edit.city || a.city || '', 40) || null, intent, INT[intent] || a.intentK || null, !!ob.firstDone]);
  res.json({ ok: true });
}));

app.post('/api/me/photos', express.raw({ type: ['image/jpeg', 'image/png', 'image/webp'], limit: '2.5mb' }), auth(async (req, res) => {
  if (!Buffer.isBuffer(req.body) || !req.body.length) return res.status(400).json({ error: 'NO_IMAGE' });
  const n = await one('SELECT count(*)::int AS n FROM photos WHERE user_id=$1', [req.user.id]);
  if (n.n >= 3) return res.status(400).json({ error: 'MAX_3' });
  const r = await one('INSERT INTO photos (user_id,mime,data) VALUES ($1,$2,$3) RETURNING id', [req.user.id, req.headers['content-type'], req.body]);
  res.json({ id: r.id, photos: await photoIds(req.user.id) });
}));
app.delete('/api/me/photos/:id', auth(async (req, res) => {
  await q('DELETE FROM photos WHERE id=$1 AND user_id=$2', [Number(req.params.id), req.user.id]);
  res.json({ photos: await photoIds(req.user.id) });
}));
// Who can see a photo: the owner, the admin, and people with an OPEN introduction (both said yes).
app.get('/api/photos/:id', wrap(async (req, res) => {
  const p = await one('SELECT id,user_id,mime,data FROM photos WHERE id=$1', [Number(req.params.id)]);
  if (!p) return res.status(404).end();
  let ok = isAdmin(req);
  if (!ok) {
    const u = await currentUser(req);
    if (u && u.id === p.user_id) ok = true;
    else if (u) ok = !!(await one(`SELECT id FROM intros WHERE opened_at IS NOT NULL AND ((a_id=$1 AND b_id=$2) OR (a_id=$2 AND b_id=$1))`, [u.id, p.user_id]));
  }
  if (!ok) return res.status(403).end();
  res.setHeader('Content-Type', p.mime); res.setHeader('Cache-Control', 'private, max-age=3600'); res.end(Buffer.from(p.data));
}));

/* ---------------- 阿禾 ---------------- */
app.post('/api/ahe/react', auth(async (req, res) => {
  if (!aiGuard(req, res)) return;
  const b = req.body || {};
  const nextOpts = Array.isArray(b.nextOpts) ? b.nextOpts.slice(0, 8).map((x) => clip(x, 30)) : [];
  const prompt = `你是「阿禾」，「知遇」App 里的 AI 朋友，正在和一个新朋友第一次聊天，慢慢认识 TA。${P.STYLE}
已知：${clip(b.known, 1500) || '（还不了解）'}
你刚问：「${clip(b.q, 80)}」
TA ${b.typed ? '自己写了' : '选了'}：「${clip(b.v, 200)}」
${b.nextQ ? `接下来你要问：「${clip(b.nextQ, 80)}」\n${b.dyn ? `请为这道题生成 4 个具体、真实的选项（每个不超过 10 个字），要结合 TA 的城市和之前说的细节，像是你在猜 TA 的真实去处。参考：${nextOpts.join('、')}` : nextOpts.length ? `这道题的选项：${nextOpts.map((x, i) => `${i}. ${x}`).join('；')}` : ''}` : '这是最后一个问题。'}

只输出 JSON：
{"reply":"对 TA 刚才回答的回应：1–2 句，不超过 36 字，具体接住 TA 说的东西，不要提问","chips":${b.dyn ? '["…","…","…","…"]' : '[]'},"guess":${b.nextQ && (b.dyn || nextOpts.length) ? '根据已知细节，你猜 TA 会选第几个（从 0 开始）；没把握就填 -1' : -1},"note":"从 TA 这次回答里记下的一条事实，15 字以内，没有就空字符串"}`;
  try { res.json((await ai.chatJSON([{ role: 'user', content: prompt }], { maxTokens: 220, timeoutMs: 12000 })) || {}); }
  catch (e) { console.error('ai react', e.message); res.json({}); }
}));

app.post('/api/ahe/guess', auth(async (req, res) => {
  if (!aiGuard(req, res)) return;
  const known = clip((req.body || {}).known, 2000) || P.knownText(req.user.ob);
  const prompt = `你是「阿禾」，「知遇」App 里的 AI 朋友，刚和一个新朋友聊完第一次。${P.STYLE}
你知道的：${known}
请以“我猜，你”开头，根据这些具体细节，对 TA 这个人做一个具体、朴素的猜测（35–60 字）：比如 TA 的性格、过日子的方式、和人相处的样子。要从细节推出来，不要空泛，不要夸 TA，不要评判。只输出这句话。`;
  try { res.json({ text: (await ai.chat([{ role: 'user', content: prompt }], { maxTokens: 160, timeoutMs: 12000 })).trim().replace(/^["“「]+|["”」]+$/g, '') }); }
  catch (e) { console.error('ai guess', e.message); res.json({ text: '' }); }
}));

async function buildSummary(userId) {
  const u = await one('SELECT * FROM users WHERE id=$1', [userId]);
  if (!u) return null;
  const hist = (await q('SELECT role,text FROM ahe_messages WHERE user_id=$1 ORDER BY id DESC LIMIT 40', [userId])).reverse()
    .map((m) => (m.role === 'user' ? 'TA：' : '阿禾：') + clip(m.text, 200)).join('\n');
  const a = (u.ob && u.ob.ans) || {};
  const prompt = `你是「知遇」App 的 AI 朋友阿禾。根据你知道的关于 TA 的事，整理一份画像，用来帮 TA 匹配合适的人。${P.STYLE}
基本信息：称呼 ${u.name || '未知'}；性别 ${u.gender || a.gender || '未知'}；想认识 ${u.seek || a.seek || '未知'}；城市 ${u.city || '未知'}；此刻想找的关系 ${u.intent || '未知'}。
你知道的：${P.knownText(u.ob)}
${hist ? '最近和你的聊天：\n' + hist : ''}
只输出 JSON：{"headline":"8–14 字，朴素具体的一句话（给 TA 本人看）","about":"30–50 字，第二人称，从具体细节出发（给 TA 本人看）","traits":["3–4 个短标签，每个不超过 8 字"],"personality":"性格（后台匹配用，30 字内）","values":"在意的东西、价值观（30 字内）","emotional_style":"情绪和相处方式（30 字内）","longing":"TA 渴望什么样的关系或陪伴（30 字内）","intention":"此刻的心意","gender":"性别","seek":"想认识","city":"城市"}
信息不够的字段写“还不清楚”，不要编造。`;
  const s = await ai.chatJSON([{ role: 'user', content: prompt }], { maxTokens: 500, timeoutMs: 20000, temperature: 0.6 });
  if (!s || !s.headline) return null;
  await q('UPDATE users SET summary=$2, summary_at=now(), chats_since_summary=0 WHERE id=$1', [userId, JSON.stringify(s)]);
  return s;
}

app.post('/api/ahe/summary', auth(async (req, res) => {
  if (!aiGuard(req, res)) return;
  try { res.json({ summary: publicSummary(await buildSummary(req.user.id)) }); }
  catch (e) { console.error('ai summary', e.message); res.json({ summary: null }); }
}));

app.post('/api/ahe/chat', auth(async (req, res) => {
  const text = clip(String((req.body || {}).text || '').trim(), 1000);
  if (!text) return res.status(400).json({ error: 'EMPTY' });
  const u = req.user;
  await q('INSERT INTO ahe_messages (user_id,role,text) VALUES ($1,$2,$3)', [u.id, 'user', text]);
  let out;
  const crisis = P.CRISIS.test(text);
  if (!ai.configured() || !ai.allow(u.id)) out = { reply: '我在。刚才有点卡，你可以再说一遍吗？', notes: [] };
  else {
    const hist = (await q('SELECT role,text FROM ahe_messages WHERE user_id=$1 ORDER BY id DESC LIMIT 20', [u.id])).reverse();
    const msgs = [{ role: 'system', content: P.AHE_SYSTEM + `\n你知道的关于 TA 的事：${P.knownText(u.ob)}` }];
    for (const m of hist) msgs.push({ role: m.role === 'user' ? 'user' : 'assistant', content: m.role === 'user' ? m.text : JSON.stringify({ reply: m.text, notes: [] }) });
    try { out = await ai.chatJSON(msgs, { maxTokens: 260, timeoutMs: 20000 }); } catch (e) { console.error('ai chat', e.message); out = null; }
    if (!out || !out.reply) out = { reply: '嗯，我听着。\n你愿意多说点吗？不说也没事。', notes: [] };
  }
  let reply = String(out.reply).trim();
  // The model is told not to give phone numbers; we add one generic, safe line ourselves.
  if (crisis && !reply.includes('紧急')) reply += '\n' + P.CRISIS_NOTE;
  await q('INSERT INTO ahe_messages (user_id,role,text) VALUES ($1,$2,$3)', [u.id, 'ahe', reply]);
  const r = await one('UPDATE users SET chats_since_summary=chats_since_summary+1 WHERE id=$1 RETURNING chats_since_summary, first_done', [u.id]);
  if (r && r.first_done && r.chats_since_summary >= 10 && ai.configured()) buildSummary(u.id).catch((e) => console.error('bg summary', e.message));
  res.json({ reply, crisis, notes: (Array.isArray(out.notes) ? out.notes : []).map((x) => clip(x, 30)).filter(Boolean).slice(0, 3) });
}));

/* ---------------- intros & rooms ---------------- */
const side = (it, uid) => (it.a_id === uid ? 'a' : 'b');
const otherId = (it, uid) => (it.a_id === uid ? it.b_id : it.a_id);
async function myIntro(req, res) {
  const it = await one('SELECT * FROM intros WHERE id=$1 AND (a_id=$2 OR b_id=$2)', [Number(req.params.id), req.user.id]);
  if (!it) { res.status(404).json({ error: 'NOT_FOUND' }); return null; }
  return it;
}

const ICE = [
  ['你最常去的那个地方，是怎么发现的？', '最近一顿让你记住的饭，在哪吃的？', '周末一般几点起？'],
  ['你住的那一片，有什么只有本地人知道的小店？', '最近一次一个人出门，去了哪？', '你手机里最近拍的一张照片是什么？'],
  ['小时候家附近有什么店，现在还在吗？', '下班回家路上，你一般在想什么？', '最近在听什么歌？'],
];
const WYR = [['一辈子只能吃火锅', '一辈子只能吃烧烤'], ['去没去过的城市', '回很喜欢的老地方'], ['早起看日出', '睡到自然醒'], ['旅行全部计划好', '到了再说'], ['一起做饭', '一起出门吃'], ['住在海边', '住在山里']];
const QCARDS = ['最近一次被小事打动，是什么时候？', '如果有空白的一周，你会怎么过？', '你身上最被低估的优点？', '小时候的梦想，现在还剩多少？', '最近一次笑到停不下来，是因为？'];

async function openRoom(it) {
  await q('UPDATE intros SET opened_at=now() WHERE id=$1 AND opened_at IS NULL', [it.id]);
  await q(`INSERT INTO room_messages (intro_id,kind,text) VALUES ($1,'sys','互相愿意 · 房间已打开')`, [it.id]);
  await q(`INSERT INTO room_messages (intro_id,kind,text) VALUES ($1,'host',$2)`, [it.id, '不着急，挑一张开场卡？']);
  await q(`INSERT INTO room_messages (intro_id,kind,payload) VALUES ($1,'ice',$2)`, [it.id, JSON.stringify({ items: ICE[it.id % ICE.length] })]);
}

async function introView(it, uid) {
  const s = side(it, uid), o = s === 'a' ? 'b' : 'a';
  const other = await one('SELECT id,name,city,is_test FROM users WHERE id=$1', [otherId(it, uid)]);
  const last = it.opened_at ? await one(`SELECT id,sender_id,kind,text,created_at FROM room_messages WHERE intro_id=$1 AND kind IN ('text','host') ORDER BY id DESC LIMIT 1`, [it.id]) : null;
  const readAt = it[s + '_read_at'];
  const unread = it.opened_at ? !!(last && last.sender_id && last.sender_id !== uid && (!readAt || new Date(last.created_at) > new Date(readAt))) : !it[s + '_decision'];
  return {
    id: it.id, other: { id: other.id, name: displayName(other), city: other.city || '', isTest: other.is_test },
    reason: it['reason_' + s] || it.reason_a || '', myDecision: it[s + '_decision'], open: !!it.opened_at,
    // the other side's "no" is never revealed; we only show "waiting"
    waiting: it[s + '_decision'] === 'yes' && !it.opened_at,
    last: last ? { text: last.kind === 'host' ? '阿禾：' + last.text : (last.sender_id === uid ? '你：' : '') + last.text, at: last.created_at } : null,
    unread, createdAt: it.created_at,
    wx: it.opened_at ? { mine: it[s + '_wx'] || '', theirs: it[s + '_wx'] && it[o + '_wx'] ? it[o + '_wx'] : '', theirsReady: !!it[o + '_wx'] } : null,
    hostOn: it.host_on,
  };
}

app.get('/api/intros', auth(async (req, res) => {
  const uid = req.user.id;
  const rows = await q(`SELECT * FROM intros WHERE (a_id=$1 OR b_id=$1) ORDER BY id DESC`, [uid]);
  const list = [];
  for (const it of rows) {
    const s = side(it, uid); const o = s === 'a' ? 'b' : 'a';
    if (it[s + '_decision'] === 'no') continue;
    if (it[o + '_decision'] === 'no' && it[s + '_decision'] === 'yes') { list.push({ ...(await introView(it, uid)), waiting: true }); continue; }
    list.push(await introView(it, uid));
  }
  res.json({ intros: list });
}));

app.post('/api/intros/:id/decide', auth(async (req, res) => {
  const it = await myIntro(req, res); if (!it) return;
  const d = (req.body || {}).d === 'yes' ? 'yes' : 'no';
  const s = side(it, req.user.id);
  if (it[s + '_decision']) return res.json({ ok: true });
  await q(`UPDATE intros SET ${s}_decision=$2 WHERE id=$1`, [it.id, d]);
  const it2 = await one('SELECT * FROM intros WHERE id=$1', [it.id]);
  let opened = false;
  if (it2.a_decision === 'yes' && it2.b_decision === 'yes' && !it2.opened_at) {
    await openRoom(it2); opened = true;
    const other = await one('SELECT email,is_test FROM users WHERE id=$1', [otherId(it2, req.user.id)]);
    if (other && !other.is_test) email.send(other.email, '你们互相愿意认识', `你在知遇的一位介绍对象也愿意认识你，聊天已经打开。\n${(process.env.APP_URL || '')}`);
  }
  res.json({ ok: true, opened });
}));

function maskPayload(m, uid) {
  const p = m.payload || {};
  if ((m.kind === 'wyr' || m.kind === 'q') && p.answers) {
    const keys = Object.keys(p.answers); const both = keys.length >= 2;
    const mine = p.answers[uid];
    const theirsKey = keys.find((k) => String(k) !== String(uid));
    return { ...p, answers: undefined, mine: mine || null, theirs: both ? p.answers[theirsKey] : null, theirsDone: !!theirsKey };
  }
  return p;
}

app.get('/api/rooms/:id', auth(async (req, res) => {
  const it = await myIntro(req, res); if (!it) return;
  if (!it.opened_at) return res.status(403).json({ error: 'NOT_OPEN' });
  const uid = req.user.id; const s = side(it, uid);
  const after = Number(req.query.after || 0);
  const msgs = await q('SELECT id,sender_id,kind,text,payload,created_at FROM room_messages WHERE intro_id=$1 AND id>$2 ORDER BY id LIMIT 300', [it.id, after]);
  // games can change after creation; always resend the open game cards
  const games = after ? await q(`SELECT id,sender_id,kind,text,payload,created_at FROM room_messages WHERE intro_id=$1 AND id<=$2 AND kind IN ('wyr','q') ORDER BY id DESC LIMIT 10`, [it.id, after]) : [];
  await q(`UPDATE intros SET ${s}_read_at=now() WHERE id=$1`, [it.id]);
  const view = await introView({ ...it, [s + '_read_at']: nowIso() }, uid);
  const photos = await photoIds(otherId(it, uid));
  const out = (m) => ({ id: m.id, from: m.kind === 'sys' ? 'sys' : !m.sender_id ? 'host' : m.sender_id === uid ? 'me' : 'them', kind: m.kind, text: m.text, payload: maskPayload(m, uid), at: m.created_at });
  res.json({ room: { ...view, otherPhotos: photos }, msgs: msgs.map(out), updates: games.map(out) });
}));

async function maybeNotify(it, fromUser) {
  const toId = otherId(it, fromUser.id);
  const to = await one('SELECT email,is_test,last_seen FROM users WHERE id=$1', [toId]);
  if (!to || to.is_test) return;
  if (to.last_seen && Date.now() - new Date(to.last_seen).getTime() < 5 * 60e3) return;
  if (it.last_email_at && Date.now() - new Date(it.last_email_at).getTime() < 30 * 60e3) return;
  await q('UPDATE intros SET last_email_at=now() WHERE id=$1', [it.id]);
  email.notifyMessage(to.email, displayName(fromUser));
}

app.post('/api/rooms/:id/messages', auth(async (req, res) => {
  const it = await myIntro(req, res); if (!it) return;
  if (!it.opened_at) return res.status(403).json({ error: 'NOT_OPEN' });
  const text = clip(String((req.body || {}).text || '').trim(), 2000);
  if (!text) return res.status(400).json({ error: 'EMPTY' });
  await q(`INSERT INTO room_messages (intro_id,sender_id,kind,text) VALUES ($1,$2,'text',$3)`, [it.id, req.user.id, text]);
  maybeNotify(it, req.user).catch(() => {});
  res.json({ ok: true });
}));

app.post('/api/rooms/:id/game', auth(async (req, res) => {
  const it = await myIntro(req, res); if (!it) return;
  if (!it.opened_at) return res.status(403).json({ error: 'NOT_OPEN' });
  const type = (req.body || {}).type;
  const n = (await one('SELECT count(*)::int AS n FROM room_messages WHERE intro_id=$1 AND kind=$2', [it.id, type === 'q' ? 'q' : 'wyr'])).n;
  if (type === 'q') {
    await q(`INSERT INTO room_messages (intro_id,kind,text) VALUES ($1,'host','问题卡。两个人都写完，才同时揭晓。')`, [it.id]);
    await q(`INSERT INTO room_messages (intro_id,kind,payload) VALUES ($1,'q',$2)`, [it.id, JSON.stringify({ q: QCARDS[n % QCARDS.length], answers: {} })]);
  } else {
    const [a, b] = WYR[(n + it.id) % WYR.length];
    await q(`INSERT INTO room_messages (intro_id,kind,text) VALUES ($1,'host','二选一。两个人都选完，才揭晓。')`, [it.id]);
    await q(`INSERT INTO room_messages (intro_id,kind,payload) VALUES ($1,'wyr',$2)`, [it.id, JSON.stringify({ a, b, answers: {} })]);
  }
  res.json({ ok: true });
}));

app.post('/api/rooms/:id/game/:mid', auth(async (req, res) => {
  const it = await myIntro(req, res); if (!it) return;
  const m = await one(`SELECT * FROM room_messages WHERE id=$1 AND intro_id=$2 AND kind IN ('wyr','q')`, [Number(req.params.mid), it.id]);
  if (!m) return res.status(404).json({ error: 'NOT_FOUND' });
  const p = m.payload || {}; p.answers = p.answers || {};
  if (p.answers[req.user.id]) return res.json({ ok: true });
  const ans = clip(String((req.body || {}).answer || '').trim(), 300);
  if (!ans) return res.status(400).json({ error: 'EMPTY' });
  if (m.kind === 'wyr' && ans !== p.a && ans !== p.b) return res.status(400).json({ error: 'BAD' });
  p.answers[req.user.id] = ans;
  await q('UPDATE room_messages SET payload=$2 WHERE id=$1', [m.id, JSON.stringify(p)]);
  if (Object.keys(p.answers).length === 2 && m.kind === 'wyr') {
    const v = Object.values(p.answers);
    await q(`INSERT INTO room_messages (intro_id,kind,text) VALUES ($1,'host',$2)`, [it.id, v[0] === v[1] ? '选得一样。' : '不一样，正好聊聊为什么？']);
  }
  res.json({ ok: true });
}));

app.post('/api/rooms/:id/topic', auth(async (req, res) => {
  const it = await myIntro(req, res); if (!it) return;
  if (!it.opened_at) return res.status(403).json({ error: 'NOT_OPEN' });
  if (!aiGuard(req, res)) return;
  const hist = (await q(`SELECT sender_id,kind,text FROM room_messages WHERE intro_id=$1 AND kind IN ('text','host') ORDER BY id DESC LIMIT 12`, [it.id])).reverse()
    .map((m) => (!m.sender_id ? '阿禾' : m.sender_id === it.a_id ? 'A' : 'B') + '：' + clip(m.text, 120)).join('\n');
  const prompt = `你是「知遇」App 的 AI 主持人阿禾，在两个刚认识的人的聊天室里温和地帮忙找话题。${P.STYLE}
介绍他们认识的理由：${clip(it.reason_a, 200)}
最近聊天：
${hist || '（还没开始聊）'}
给一个轻松、具体、两个人都容易接的话题，一句话，不超过 35 字。不要涉及隐私和收入。只输出正文。`;
  let t = '';
  try { t = (await ai.chat([{ role: 'user', content: prompt }], { maxTokens: 80, timeoutMs: 12000 })).trim().replace(/^["“「]+|["”」]+$/g, ''); } catch (e) { console.error('ai topic', e.message); }
  if (!t) t = '聊聊：你们手机里最近拍的一张照片是什么？';
  await q(`UPDATE intros SET host_on=TRUE WHERE id=$1`, [it.id]);
  await q(`INSERT INTO room_messages (intro_id,kind,text) VALUES ($1,'host',$2)`, [it.id, t]);
  res.json({ ok: true });
}));

app.post('/api/rooms/:id/host', auth(async (req, res) => {
  const it = await myIntro(req, res); if (!it) return;
  await q('UPDATE intros SET host_on=$2 WHERE id=$1', [it.id, !!(req.body || {}).on]);
  res.json({ ok: true });
}));

app.post('/api/rooms/:id/wechat', auth(async (req, res) => {
  const it = await myIntro(req, res); if (!it) return;
  if (!it.opened_at) return res.status(403).json({ error: 'NOT_OPEN' });
  const wx = clip(String((req.body || {}).wx || '').trim(), 60);
  if (!wx) return res.status(400).json({ error: 'EMPTY' });
  const s = side(it, req.user.id), o = s === 'a' ? 'b' : 'a';
  await q(`UPDATE intros SET ${s}_wx=$2 WHERE id=$1`, [it.id, wx]);
  if (it[o + '_wx'] && !it[s + '_wx']) {
    await q(`INSERT INTO room_messages (intro_id,kind,text) VALUES ($1,'sys','你们交换了微信')`, [it.id]);
    await q(`INSERT INTO room_messages (intro_id,kind,text) VALUES ($1,'host','我先退场啦。祝你们聊得开心。')`, [it.id]);
    await q('UPDATE intros SET host_on=FALSE WHERE id=$1', [it.id]);
  }
  res.json({ ok: true });
}));

/* ---------------- feed ---------------- */
app.get('/api/posts', auth(async (req, res) => {
  const rows = await q(`SELECT p.id,p.text,p.created_at,p.user_id,u.name,u.is_test,
      (SELECT count(*)::int FROM post_likes l WHERE l.post_id=p.id AND l.user_id=$1) AS liked
    FROM posts p JOIN users u ON u.id=p.user_id ORDER BY p.id DESC LIMIT 60`, [req.user.id]);
  res.json({ posts: rows.map((r) => ({ id: r.id, text: r.text, at: r.created_at, name: displayName(r), mine: r.user_id === req.user.id, liked: r.liked > 0, isTest: r.is_test })) });
}));
app.post('/api/posts', auth(async (req, res) => {
  const text = clip(String((req.body || {}).text || '').trim(), 500);
  if (!text) return res.status(400).json({ error: 'EMPTY' });
  await q('INSERT INTO posts (user_id,text) VALUES ($1,$2)', [req.user.id, text]);
  res.json({ ok: true });
}));
app.post('/api/posts/:id/like', auth(async (req, res) => {
  const id = Number(req.params.id);
  const had = await one('DELETE FROM post_likes WHERE post_id=$1 AND user_id=$2 RETURNING post_id', [id, req.user.id]);
  if (!had) await q('INSERT INTO post_likes (post_id,user_id) VALUES ($1,$2) ON CONFLICT DO NOTHING', [id, req.user.id]);
  res.json({ liked: !had });
}));
app.delete('/api/posts/:id', auth(async (req, res) => {
  await q('DELETE FROM posts WHERE id=$1 AND user_id=$2', [Number(req.params.id), req.user.id]);
  res.json({ ok: true });
}));

/* ---------------- admin ---------------- */
const adminTries = new Map();
app.post('/api/admin/login', wrap(async (req, res) => {
  const ip = req.ip || 'x'; const t = adminTries.get(ip) || { t: Date.now(), n: 0 };
  if (Date.now() - t.t > 900e3) { t.t = Date.now(); t.n = 0; } t.n++; adminTries.set(ip, t);
  if (t.n > 10) return res.status(429).json({ error: 'TOO_MANY' });
  const pw = String((req.body || {}).password || '');
  if (!ADMIN_PASSWORD) return res.status(503).json({ error: 'ADMIN_NOT_CONFIGURED' });
  const ok = pw.length === ADMIN_PASSWORD.length && crypto.timingSafeEqual(Buffer.from(pw), Buffer.from(ADMIN_PASSWORD));
  if (!ok) return res.status(401).json({ error: 'WRONG' });
  const exp = Date.now() + 7 * 86400e3;
  setCookie(req, res, 'zy_admin', exp + '.' + hmac('admin:' + exp), 7 * 86400);
  res.json({ ok: true });
}));
app.post('/api/admin/logout', (req, res) => { setCookie(req, res, 'zy_admin', '', 0); res.json({ ok: true }); });
app.get('/api/admin/me', (req, res) => res.json({ admin: isAdmin(req) }));

app.get('/api/admin/users', admin(async (req, res) => {
  const rows = await q(`SELECT id,email,is_test,name,gender,seek,city,intent,intent_k,first_done,summary,summary_at,appearance_tag,admin_note,last_seen,created_at,ob,prefs,
      (SELECT count(*)::int FROM ahe_messages m WHERE m.user_id=u.id AND m.role='user') AS chat_count
    FROM users u ORDER BY is_test, id DESC`);
  const photos = await q('SELECT id,user_id FROM photos ORDER BY id');
  res.json({ users: rows.map((u) => ({ ...u, ob: undefined, prefs: undefined, paused: !!(u.prefs && u.prefs.paused), answers: (u.ob && u.ob.ans) || {}, log: ((u.ob && u.ob.log) || []).slice(-30), photos: photos.filter((p) => p.user_id === u.id).map((p) => p.id) })) });
}));
app.post('/api/admin/users/:id', admin(async (req, res) => {
  const b = req.body || {};
  await q('UPDATE users SET appearance_tag=$2, admin_note=$3 WHERE id=$1', [Number(req.params.id), clip(b.appearance_tag || '', 40) || null, clip(b.admin_note || '', 500) || null]);
  res.json({ ok: true });
}));
app.post('/api/admin/users/:id/summary', admin(async (req, res) => {
  try { res.json({ summary: await buildSummary(Number(req.params.id)) }); } catch (e) { res.status(500).json({ error: e.message.slice(0, 100) }); }
}));
app.post('/api/admin/test-users/delete', admin(async (req, res) => {
  const r = await q('DELETE FROM users WHERE is_test=TRUE RETURNING id');
  res.json({ deleted: r.length });
}));
app.post('/api/admin/test-users/seed', admin(async (req, res) => {
  if (process.env.NODE_ENV === 'production' && process.env.SEED !== '1') return res.status(403).json({ error: 'SET_SEED_1' });
  res.json({ created: await require('./lib/seed').seed() });
}));
// For demos only: log in as a TEST user (never a real one) to try the other side of a chat.
app.post('/api/admin/impersonate/:id', admin(async (req, res) => {
  const u = await one('SELECT id,is_test FROM users WHERE id=$1', [Number(req.params.id)]);
  if (!u || !u.is_test) return res.status(403).json({ error: 'TEST_USERS_ONLY' });
  await newSession(req, res, u.id); res.json({ ok: true });
}));

const INTENT_OK = {
  friend: ['friend', 'unsure', 'date'], date: ['date', 'friend', 'unsure', 'serious'], serious: ['serious', 'marry', 'date', 'unsure'],
  marry: ['marry', 'serious'], casual: ['casual'], unsure: ['unsure', 'friend', 'date', 'serious'],
};
const wants = (a, b) => !a.seek || a.seek === '都可以' ? true : a.seek === b.gender;
function compatible(a, b) {
  if (a.id === b.id) return false;
  if (!wants(a, b) || !wants(b, a)) return false;
  const ia = a.intent_k || 'unsure', ib = b.intent_k || 'unsure';
  return (INTENT_OK[ia] || []).includes(ib) && (INTENT_OK[ib] || []).includes(ia);
}
const pairKey = (a, b) => (a < b ? a + '-' + b : b + '-' + a);

app.post('/api/admin/generate', admin(async (req, res) => {
  if (!ai.configured()) return res.status(503).json({ error: 'AI_NOT_CONFIGURED' });
  const users = (await q(`SELECT id,name,gender,seek,city,intent,intent_k,summary,appearance_tag,prefs,is_test,ob FROM users WHERE first_done=TRUE ORDER BY id`))
    .filter((u) => !(u.prefs && u.prefs.paused));
  const used = new Set((await q(`SELECT a_id,b_id FROM intros UNION ALL SELECT a_id,b_id FROM proposals WHERE status IN ('proposed','approved','rejected')`)).map((r) => pairKey(r.a_id, r.b_id)));
  const cand = {};
  for (const a of users) cand[a.id] = users.filter((b) => compatible(a, b) && !used.has(pairKey(a.id, b.id))).map((b) => b.id);
  const pool = users.filter((u) => cand[u.id].length);
  if (!pool.length) return res.json({ created: 0, note: '没有可配对的组合（性别/心意不匹配，或都已经介绍过）' });
  const lines = pool.slice(0, 80).map((u) => {
    const s = u.summary || {};
    return `#${u.id} ${u.gender || '?'}，想认识${u.seek || '?'}，${u.city || '?'}，心意：${u.intent || '还没想清楚'}，外形标签：${u.appearance_tag || '未标'}。画像：${clip([s.headline, s.about, s.personality, s.values, s.emotional_style, s.longing].filter(Boolean).join('；'), 220) || clip(P.knownText(u.ob), 220)}。可配对：${cand[u.id].map((x) => '#' + x).join(' ')}`;
  }).join('\n');
  const perUser = Math.max(1, Math.min(3, Number((req.body || {}).perUser) || 2));
  const prompt = `你是「知遇」的红娘助手。知遇不让用户刷人，每月只给每个人介绍很少几个认真挑过的人。
下面是用户列表，每人后面的“可配对”是规则允许的对象（已满足性别取向和关系心意）。请只从“可配对”里选。
挑选原则：生活方式和节奏相近、在意的东西相通、同城优先、外形标签大致相当（不要明显悬殊）、心意越一致越好。宁缺毋滥，不合适就不配。每个人最多出现在 ${perUser} 对里。
${lines}

只输出 JSON：{"pairs":[{"a":用户id数字,"b":用户id数字,"reason":"一句话，25–45 字，写给两个人看的介绍理由，用“你们”开头，具体（地方、习惯、节奏），不要提外形标签、收入、心意等隐私"}]}`;
  let out;
  try { out = await ai.chatJSON([{ role: 'user', content: prompt }], { maxTokens: 1800, timeoutMs: 60000, temperature: 0.5 }); }
  catch (e) { return res.status(502).json({ error: 'AI_FAILED', detail: e.message.slice(0, 120) }); }
  const byId = Object.fromEntries(users.map((u) => [u.id, u]));
  const count = {}; let created = 0;
  for (const p of (out && out.pairs) || []) {
    const a = Number(p.a), b = Number(p.b);
    if (!byId[a] || !byId[b] || !cand[a].includes(b)) continue;
    const k = pairKey(a, b); if (used.has(k)) continue;
    if ((count[a] || 0) >= perUser || (count[b] || 0) >= perUser) continue;
    used.add(k); count[a] = (count[a] || 0) + 1; count[b] = (count[b] || 0) + 1;
    await q('INSERT INTO proposals (a_id,b_id,reason) VALUES ($1,$2,$3)', [a, b, clip(p.reason || '', 120)]);
    created++;
  }
  res.json({ created });
}));

app.get('/api/admin/proposals', admin(async (req, res) => {
  const rows = await q(`SELECT p.*, ua.name AS a_name, ua.is_test AS a_test, ua.gender AS a_gender, ua.city AS a_city, ua.intent AS a_intent, ua.appearance_tag AS a_tag,
      ub.name AS b_name, ub.is_test AS b_test, ub.gender AS b_gender, ub.city AS b_city, ub.intent AS b_intent, ub.appearance_tag AS b_tag
    FROM proposals p JOIN users ua ON ua.id=p.a_id JOIN users ub ON ub.id=p.b_id ORDER BY (p.status='proposed') DESC, p.id DESC LIMIT 200`);
  res.json({ proposals: rows });
}));
app.post('/api/admin/proposals', admin(async (req, res) => {
  const b = req.body || {}; const a = Number(b.a), c = Number(b.b);
  if (!a || !c || a === c) return res.status(400).json({ error: 'BAD' });
  const r = await one('INSERT INTO proposals (a_id,b_id,reason) VALUES ($1,$2,$3) RETURNING id', [a, c, clip(b.reason || '', 120)]);
  res.json({ id: r.id });
}));
app.post('/api/admin/proposals/:id', admin(async (req, res) => {
  const p = await one('SELECT * FROM proposals WHERE id=$1', [Number(req.params.id)]);
  if (!p) return res.status(404).json({ error: 'NOT_FOUND' });
  const b = req.body || {};
  if (typeof b.reason === 'string') await q('UPDATE proposals SET reason=$2 WHERE id=$1', [p.id, clip(b.reason, 120)]);
  if (b.action === 'reject') await q(`UPDATE proposals SET status='rejected' WHERE id=$1`, [p.id]);
  if (b.action === 'approve' && p.status === 'proposed') {
    const reason = typeof b.reason === 'string' ? clip(b.reason, 120) : p.reason;
    const ua = await one('SELECT id,email,is_test FROM users WHERE id=$1', [p.a_id]);
    const ub = await one('SELECT id,email,is_test FROM users WHERE id=$1', [p.b_id]);
    // test users say yes automatically, so a real tester can see the full flow
    const it = await one(`INSERT INTO intros (a_id,b_id,reason_a,reason_b,a_decision,b_decision) VALUES ($1,$2,$3,$3,$4,$5) RETURNING *`,
      [p.a_id, p.b_id, reason, ua.is_test ? 'yes' : null, ub.is_test ? 'yes' : null]);
    await q(`UPDATE proposals SET status='approved' WHERE id=$1`, [p.id]);
    if (ua.is_test && ub.is_test) await openRoom(it);
    if (!ua.is_test) email.notifyIntro(ua.email);
    if (!ub.is_test) email.notifyIntro(ub.email);
  }
  res.json({ ok: true });
}));
app.get('/api/admin/intros', admin(async (req, res) => {
  const rows = await q(`SELECT i.id,i.a_id,i.b_id,i.reason_a,i.a_decision,i.b_decision,i.opened_at,i.created_at,ua.name AS a_name,ub.name AS b_name,
      (SELECT count(*)::int FROM room_messages m WHERE m.intro_id=i.id AND m.kind='text') AS msg_count,
      (SELECT max(created_at) FROM room_messages m WHERE m.intro_id=i.id AND m.kind='text') AS last_at
    FROM intros i JOIN users ua ON ua.id=i.a_id JOIN users ub ON ub.id=i.b_id ORDER BY i.id DESC LIMIT 200`);
  res.json({ intros: rows });
}));

/* ---------------- spa ---------------- */
app.get('*', (req, res, next) => { if (req.path.startsWith('/api/')) return next(); res.sendFile(path.join(__dirname, 'public/index.html')); });
app.use('/api', (req, res) => res.status(404).json({ error: 'NOT_FOUND' }));

(async () => {
  await db.init();
  if (process.env.SEED === '1') { const n = await require('./lib/seed').seed(); if (n) console.log(`[seed] created ${n} test users`); }
  q(`DELETE FROM sessions WHERE expires_at<now()`).catch(() => {});
  app.listen(PORT, process.env.HOST || '0.0.0.0', () => console.log(`知遇 listening on :${PORT}  TEST_MODE=${TEST_MODE ? 'ON (codes shown on screen)' : 'off'}  email=${email.configured() ? 'resend' : 'off'}  ai=${ai.configured() ? ai.MODEL : 'off'}`));
})().catch((e) => { console.error(e); process.exit(1); });
