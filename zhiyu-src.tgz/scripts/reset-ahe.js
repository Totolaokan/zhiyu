// Reset every user's 阿禾 conversation in the LOCAL database (same effect as each user tapping 「重新开始」).
// Run only while the server is stopped (PGlite is single-process). Refuses to touch a real Postgres DATABASE_URL.
if (process.env.DATABASE_URL) { console.error('DATABASE_URL is set — this script is for the local PGlite DB only.'); process.exit(1); }
const { init, q } = require('../lib/db');
(async () => {
  await init();
  const n = (await q('SELECT count(*)::int AS n FROM users'))[0].n;
  await q('DELETE FROM ahe_messages');
  await q('DELETE FROM user_seeds');
  await q(`DELETE FROM proposals WHERE status='proposed'`);
  await q(`UPDATE users SET ob='{}'::jsonb, edit='{}'::jsonb, ahe_state='{}'::jsonb, summary=NULL, summary_at=NULL, chats_since_summary=0,
      name=NULL, gender=NULL, seek=NULL, city=NULL, intent=NULL, intent_k=NULL, first_done=FALSE`);
  console.log(`reset 阿禾 state for ${n} user(s) in ${process.env.PGLITE_DIR || '.data/pglite'}`);
  process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
