#!/usr/bin/env bash
# Reset the local test server before a handover, then restart it cleanly.
#   scripts/reset-local.sh          -> keep accounts, wipe every user's 阿禾 chat / seeds / profile (like 「重新开始」 for all)
#   scripts/reset-local.sh --wipe   -> delete the whole local DB (accounts too) and start empty
# Env (inherited from your shell): DEEPSEEK_API_KEY (required), optional ANTHROPIC_API_KEY / OPENROUTER_API_KEY,
# CHAT_PROVIDER, CHAT_MODEL, EXTRACT_PROVIDER. PORT (default 3101), PGLITE_DIR (default /tmp/zy9).
set -euo pipefail
cd "$(dirname "$0")/.."
PORT="${PORT:-3101}"; export PGLITE_DIR="${PGLITE_DIR:-/tmp/zy9}"
PW_FILE="${ADMIN_PASSWORD_FILE:-/workspace/dating/admin_password.txt}"
for pid in $(ss -ltnpH "sport = :$PORT" 2>/dev/null | grep -o 'pid=[0-9]*' | cut -d= -f2 | sort -u); do kill "$pid" 2>/dev/null || true; done
for i in $(seq 1 20); do ss -ltnH "sport = :$PORT" | grep -q . || break; sleep 0.5; done
if [ "${1:-}" = "--wipe" ]; then rm -rf "$PGLITE_DIR"; echo "wiped $PGLITE_DIR"; else node scripts/reset-ahe.js; fi
npm run build >/dev/null
ADMIN_PASSWORD="$(cat "$PW_FILE")" PORT="$PORT" TEST_MODE=1 setsid nohup node server.js > /tmp/zhiyu$PORT.log 2>&1 < /dev/null &
for i in $(seq 1 30); do curl -sf "http://127.0.0.1:$PORT/healthz" >/dev/null && break; sleep 0.5; done
echo "healthz: $(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:$PORT/healthz)  chat provider: ${CHAT_PROVIDER:-auto} ${CHAT_MODEL:-}  log: /tmp/zhiyu$PORT.log"
