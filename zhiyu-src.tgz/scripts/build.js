// Bundles the React frontend (no CDN needed, works from mainland China).
const esbuild = require('esbuild');
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
fs.mkdirSync(path.join(root, 'public/build'), { recursive: true });
Promise.all(['app', 'admin'].map((n) => esbuild.build({
  entryPoints: [path.join(root, `src/${n}.jsx`)], bundle: true, minify: true, sourcemap: false,
  outfile: path.join(root, `public/build/${n}.js`), jsx: 'transform', loader: { '.js': 'jsx' },
  define: { 'process.env.NODE_ENV': '"production"' }, target: ['es2020'], logLevel: 'warning',
}))).then(() => {
  fs.copyFileSync(path.join(root, 'src/app.css'), path.join(root, 'public/build/app.css'));
  console.log('build ok');
}).catch((e) => { console.error(e); process.exit(1); });
