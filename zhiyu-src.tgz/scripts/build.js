// Bundles the React frontend (no CDN needed, works from mainland China).
const esbuild = require('esbuild');
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
fs.mkdirSync(path.join(root, 'public/build'), { recursive: true });
Promise.all(['app', 'admin'].map((n) => esbuild.build({
  entryPoints: [path.join(root, `src/${n}.jsx`)], bundle: true, minify: true, sourcemap: false,
  outfile: path.join(root, `public/build/${n}.js`), jsx: 'transform', loader: { '.js': 'jsx' },
  define: { 'process.env.NODE_ENV': '"production"' }, target: ['es2020'], logLevel: 'warning',
}))).then(() => {
  // 霞鹜文楷 GB Screen: rename the family to "WenKai" and serve the subsets from /fonts/wenkai (see server.js)
  const wk = fs.readFileSync(require.resolve('lxgw-wenkai-screen-webfont/lxgwwenkaigbscreen.css'), 'utf8')
    .replace(/font-family:\s*'LXGW WenKai Screen'/g, "font-family:'WenKai'").replace(/url\('\.\/files\//g, "url('/fonts/wenkai/")
    .replace(/\/\*[^*]*\*\//g, '').replace(/\n\s*/g, '');
  fs.writeFileSync(path.join(root, 'public/build/app.css'), wk + '\n' + fs.readFileSync(path.join(root, 'src/app.css'), 'utf8'));
  console.log('build ok');
}).catch((e) => { console.error(e); process.exit(1); });
