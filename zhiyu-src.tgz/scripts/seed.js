const { seed } = require('../lib/seed.js');
if (process.env.NODE_ENV === 'production' && process.env.SEED !== '1') { console.error('Refusing to seed in production without SEED=1'); process.exit(1); }
seed().then(n => { console.log(`seeded ${n} test users`); process.exit(0); }).catch(e => { console.error(e); process.exit(1); });
