#!/usr/bin/env bash
# Run the 阿禾 regression set + 12 personas on Claude once ANTHROPIC_API_KEY (or OPENROUTER_API_KEY with CHAT_PROVIDER=openrouter) is set.
# Results land in /workspace/dating/v9_compare/ (regress_<model>.json, claude_<model>/).
set -euo pipefail
cd /workspace/dating/v9_compare
export CHAT_PROVIDER="${CHAT_PROVIDER:-anthropic}"
M="$(node -e "console.log(require('/workspace/dating/zhiyu/lib/ai').chatModel())")"
echo "provider=$CHAT_PROVIDER model=$M"
node regress.js "$M" "${REPS:-4}"
node harness.js new > "run_claude.log" 2>&1
D="claude_${M//\//_}"; rm -rf "$D"; mkdir -p "$D"; mv new_p* "$D/"
grep score run_claude.log
