# 知遇 Zhiyu

不用刷人。阿禾先认识你，再慢慢为你介绍合适的人。

One Node service (Express + Postgres) that serves the phone-first web app, the API, and an admin page.

## What's inside

| Part | Where |
|---|---|
| App (阿禾 / 聊天 / 动态 / 我) | `src/app.jsx`, `src/core.jsx` (阿禾 first-meeting flow, ≤10 questions), `src/app.css` |
| Admin page `/admin` | `src/admin.jsx` |
| API + static server | `server.js` |
| DB schema (auto-created on boot) | `lib/db.js` |
| DeepSeek client | `lib/ai.js` (OpenAI-compatible, `deepseek-chat`) |
| Prompts (server-side only) | `lib/prompts.js` + inline in `server.js` |
| Email sender (Resend) | `lib/email.js` |
| Test users | `lib/seed.js`, `npm run seed` |

The frontend is bundled with esbuild (`npm run build`), with no CDN and no Google Fonts, so it loads in mainland China.

## Environment variables

| Name | Needed | Notes |
|---|---|---|
| `DATABASE_URL` | prod | Postgres URL. Without it, local dev uses an embedded PGlite DB in `.data/`. |
| `DEEPSEEK_API_KEY` | yes | 阿禾, profile summaries, match generation. Never commit it. |
| `ADMIN_PASSWORD` | yes | Password for `/admin`. |
| `SESSION_SECRET` | recommended | Random string used to sign codes and admin cookies. |
| `TEST_MODE` | while no email | **`TEST_MODE=1` shows the 6-digit login code on screen.** Anyone who types an email can log in as that email. Use it only for closed testing, and set it to `0` once email works. |
| `RESEND_API_KEY`, `EMAIL_FROM` | for real logins | e.g. `EMAIL_FROM="知遇 <hello@yourdomain.com>"` (the domain must be verified in Resend). Also used for "new introduction / new message" emails. If these are missing, email is a no-op. |
| `APP_URL` | optional | Public URL, used in email links. |
| `SEED` | optional | `SEED=1` creates 10 test users at boot (idempotent). It is also required for the admin "创建测试用户" button in production. |
| `LLM_BASE_URL`, `LLM_MODEL` | optional | Defaults are `https://api.deepseek.com` and `deepseek-chat`. |

## Run locally

```bash
npm install
npm run build
TEST_MODE=1 ADMIN_PASSWORD=change-me DEEPSEEK_API_KEY=sk-... npm start   # http://localhost:3000
npm run seed        # optional: 10 test users
```

## How matching works

1. A user meets 阿禾. 阿禾 asks at most 10 concrete questions (name and its story, city, where they go, a corner to be alone, …, gender and who they want to meet, and their intention, with no judgment). After that 阿禾 only listens and quietly keeps notes.
2. After the first meeting, and again after every 10 chat turns, DeepSeek writes a profile. The user sees the headline, about and traits. The admin also sees personality, values, emotional style, what they long for, and intention.
3. In `/admin`, staff set an appearance tag per user, then click **生成匹配**. The server pre-filters pairs by gender/target and compatible intention. DeepSeek picks pairs from that list and writes a one-line reason. Its picks are checked against the list again.
4. Staff edit the reason and approve. Both people get an introduction card in 聊天, plus an email. The chat opens only when both say yes, and a "no" is never shown to the other side. Test users always say yes, so a real tester can try the whole flow.
5. Inside a chat, 阿禾 offers icebreakers, either-or questions, and question cards (both answers are revealed together). It can also suggest a topic (one AI call). Users can swap WeChat IDs; the IDs show only after both enter theirs.

Photos are stored in Postgres. Only the owner, the admin, and someone with an **open** introduction (both said yes) can see them.
