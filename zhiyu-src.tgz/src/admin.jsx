import React, { useState, useEffect } from 'react';
import { createRoot } from 'react-dom/client';
import { api, photoUrl } from './api.js';

const TAGS = ['', 'A', 'B', 'C', '待审核', '照片不清晰', '疑似非本人'];

function Login({ onDone }){
  const [pw, setPw] = useState(''); const [err, setErr] = useState('');
  const go = async () => { setErr(''); try { await api('/api/admin/login', { password: pw }); onDone(); } catch (e) { setErr(e.code === 'WRONG' ? '密码不对' : e.code); } };
  return <div className="wrap" style={{ maxWidth:380, paddingTop:100 }}><div className="card"><h3>知遇 · 后台</h3>
    <div className="row"><input type="password" value={pw} onChange={e => setPw(e.target.value)} onKeyDown={e => e.key === 'Enter' && go()} placeholder="管理员密码" style={{ flex:1 }}/><button className="p" onClick={go}>进入</button></div>
    {err && <p className="w">{err}</p>}</div></div>;
}

function UserCard({ u, onSaved }){
  const [tag, setTag] = useState(u.appearance_tag || '');
  const [note, setNote] = useState(u.admin_note || '');
  const [busy, setBusy] = useState(false);
  const s = u.summary || {};
  const save = async () => { setBusy(true); await api(`/api/admin/users/${u.id}`, { appearance_tag: tag, admin_note: note }); setBusy(false); onSaved(); };
  const resum = async () => { setBusy(true); try { await api(`/api/admin/users/${u.id}/summary`, {}); } catch (e) { alert('生成失败：' + e.code); } setBusy(false); onSaved(); };
  const imp = async () => { await api(`/api/admin/impersonate/${u.id}`, {}); window.open('/', '_blank'); };
  return (
    <div className="card">
      <div className="row" style={{ justifyContent:'space-between' }}>
        <div><b style={{ fontSize:16 }}>#{u.id} {u.name || '（未填称呼）'}</b> {u.is_test && <span className="tag t">测试</span>} {u.paused && <span className="tag t">暂停推荐</span>}
          <div className="muted">{u.email} · 注册 {new Date(u.created_at).toLocaleDateString()} · 最近 {u.last_seen ? new Date(u.last_seen).toLocaleString() : '—'}</div></div>
        <span className="tag">{u.first_done ? '已完成初次见面' : '初次见面中'}</span>
      </div>
      <div style={{ margin:'8px 0' }}>
        <span className="tag">{u.gender || '性别?'}</span><span className="tag">想认识 {u.seek || '?'}</span><span className="tag">{u.city || '城市?'}</span><span className="tag">{u.intent || '心意?'}</span><span className="tag">和阿禾聊了 {u.chat_count} 句</span><span className="tag">阿禾主动问了 {u.ahe ? u.ahe.asked : 0} 个问题</span>{u.ahe && u.ahe.guessStat && u.ahe.guessStat.total > 0 && <span className="tag">猜中 {u.ahe.guessStat.hit}/{u.ahe.guessStat.total}</span>}
      </div>
      {s.headline ? (<div style={{ lineHeight:1.6 }}>
        <div><b>{s.headline}</b></div><div>{s.about}</div>
        <div className="muted">性格：{s.personality || '—'}｜在意：{s.values || '—'}｜情绪：{s.emotional_style || '—'}｜渴望：{s.longing || '—'}</div>
        <div className="muted">画像更新于 {u.summary_at ? new Date(u.summary_at).toLocaleString() : '—'}</div>
      </div>) : <div className="muted">还没有 AI 画像</div>}
      <div style={{ marginTop:6, fontSize:13 }}><span className="muted">生活碎片（{(u.seeds || []).length}）：</span>{(u.seeds || []).length ? u.seeds.map(x => <span key={x.id} className="tag" title={x.detail}>{({ place:'📍', food:'🍜', thing:'🎒', ritual:'⏰', story:'💬' })[x.type] || ''} {x.name}</span>) : <span className="muted">还没有</span>}</div>
      <details style={{ marginTop:6 }}><summary>回答与阿禾记下的事（{u.log.length}）</summary>
        <div style={{ fontSize:12.5, lineHeight:1.7, marginTop:4 }}>{u.log.map((l, i) => <div key={i}><span className="muted">{l.q}：</span>{l.a}</div>)}</div></details>
      <div className="row" style={{ marginTop:8 }}>{u.photos.length ? u.photos.map(p => <a key={p} href={photoUrl(p)} target="_blank"><img className="ph" src={photoUrl(p)}/></a>) : <span className="muted">没有照片</span>}</div>
      <div className="row" style={{ marginTop:10 }}>
        <label className="muted">外形标签</label>
        <select value={TAGS.includes(tag) ? tag : '__'} onChange={e => e.target.value !== '__' && setTag(e.target.value)}>{TAGS.map(t => <option key={t} value={t}>{t || '（未标）'}</option>)}{!TAGS.includes(tag) && <option value="__">{tag}</option>}</select>
        <input value={tag} onChange={e => setTag(e.target.value)} placeholder="或自定义" style={{ width:100 }}/>
        <input value={note} onChange={e => setNote(e.target.value)} placeholder="内部备注" style={{ flex:1, minWidth:120 }}/>
        <button className="p" disabled={busy} onClick={save}>保存</button>
        <button disabled={busy} onClick={resum}>重新生成画像</button>
        {u.is_test && <button onClick={imp} title="以这个测试用户身份打开前台（会替换本浏览器的登录）">以 TA 身份打开</button>}
      </div>
    </div>
  );
}

function Proposals({ list, reload }){
  const [edits, setEdits] = useState({});
  const act = async (p, action) => { await api(`/api/admin/proposals/${p.id}`, { action, reason: edits[p.id] ?? p.reason }); reload(); };
  const open = list.filter(p => p.status === 'proposed');
  const done = list.filter(p => p.status !== 'proposed');
  return (<>
    {!open.length && <p className="muted">没有待确认的配对。点上面的「生成匹配」。</p>}
    {open.map(p => (
      <div key={p.id} className="card">
        <div className="row"><b>#{p.a_id} {p.a_name}</b><span className="muted">{p.a_gender}·{p.a_city}·{p.a_intent}·外形 {p.a_tag || '未标'}</span><span>↔</span>
          <b>#{p.b_id} {p.b_name}</b><span className="muted">{p.b_gender}·{p.b_city}·{p.b_intent}·外形 {p.b_tag || '未标'}</span></div>
        <div className="row" style={{ marginTop:8 }}>
          <textarea rows={2} style={{ flex:1, minWidth:260 }} value={edits[p.id] ?? p.reason ?? ''} onChange={e => setEdits({ ...edits, [p.id]: e.target.value })}/>
          <button className="p" onClick={() => act(p, 'approve')}>确认，发给双方</button>
          <button className="w" onClick={() => act(p, 'reject')}>不合适</button>
        </div>
        {p.shared && p.shared.line && <div style={{ fontSize:13, margin:'4px 0' }}>共同的生活碎片：<b>{p.shared.line}</b>{p.shared.idea ? ` · 约会小提案「${p.shared.idea.title}」` : ''}</div>}
        <div className="muted">这句理由会原样出现在双方的介绍卡上。</div>
      </div>
    ))}
    {done.length > 0 && <details><summary>已处理（{done.length}）</summary>{done.map(p => <div key={p.id} className="muted" style={{ padding:'3px 0' }}>{p.status === 'approved' ? '✓ 已发出' : '✗ 不合适'} · {p.a_name} ↔ {p.b_name} · {p.reason}</div>)}</details>}
  </>);
}

function Intros({ list }){
  if (!list.length) return <p className="muted">还没有介绍。</p>;
  const st = (d) => d === 'yes' ? '愿意' : d === 'no' ? '不了' : '未回应';
  return <div className="card"><table style={{ width:'100%', borderCollapse:'collapse' }}><thead><tr className="muted" style={{ textAlign:'left' }}><th>#</th><th>A</th><th>B</th><th>状态</th><th>消息</th><th>最近</th></tr></thead><tbody>
    {list.map(i => <tr key={i.id} style={{ borderTop:'1px solid #eee' }}><td>{i.id}</td><td>{i.a_name}（{st(i.a_decision)}）</td><td>{i.b_name}（{st(i.b_decision)}）</td><td>{i.opened_at ? '已打开聊天' : '等待'}</td><td>{i.msg_count}</td><td className="muted">{i.last_at ? new Date(i.last_at).toLocaleString() : '—'}</td></tr>)}
  </tbody></table></div>;
}

function Admin({ onLogout }){
  const [tab, setTab] = useState('users');
  const [users, setUsers] = useState([]); const [props, setProps] = useState([]); const [intros, setIntros] = useState([]);
  const [busy, setBusy] = useState(''); const [msg, setMsg] = useState(''); const [filter, setFilter] = useState('all');
  const load = async () => {
    const [a, b, c] = await Promise.all([api('/api/admin/users'), api('/api/admin/proposals'), api('/api/admin/intros')]);
    setUsers(a.users); setProps(b.proposals); setIntros(c.intros);
  };
  useEffect(() => { load(); }, []);
  const gen = async () => { setBusy('gen'); setMsg(''); try { const r = await api('/api/admin/generate', { perUser: 2 }); setMsg(r.created ? `生成了 ${r.created} 对，请逐一确认` : (r.note || '这次没有合适的新配对')); setTab('props'); } catch (e) { setMsg('生成失败：' + e.code); } setBusy(''); load(); };
  const seed = async () => { setBusy('seed'); try { const r = await api('/api/admin/test-users/seed', {}); setMsg(`创建了 ${r.created} 个测试用户`); } catch (e) { setMsg(e.code === 'SET_SEED_1' ? '线上环境需要先设置 SEED=1 才能创建测试用户' : e.code); } setBusy(''); load(); };
  const delTest = async () => { if (!confirm('删除所有测试用户（含他们的介绍和聊天）？')) return; const r = await api('/api/admin/test-users/delete', {}); setMsg(`删除了 ${r.deleted} 个测试用户`); load(); };
  const shown = users.filter(u => filter === 'all' || (filter === 'real' ? !u.is_test : filter === 'test' ? u.is_test : !u.appearance_tag));
  const real = users.filter(u => !u.is_test);
  return (
    <div className="wrap">
      <div className="row" style={{ justifyContent:'space-between', marginBottom:14 }}>
        <div><h1>知遇 · 后台</h1><div className="muted">真实用户 {real.length} · 完成初次见面 {real.filter(u => u.first_done).length} · 测试用户 {users.length - real.length}</div></div>
        <div className="row">
          <button className="p" disabled={!!busy} onClick={gen}>{busy === 'gen' ? 'AI 正在挑…' : '生成匹配'}</button>
          <button disabled={!!busy} onClick={seed}>创建测试用户</button>
          <button className="w" onClick={delTest}>删除测试用户</button>
          <button onClick={async () => { await api('/api/admin/logout', {}); onLogout(); }}>退出</button>
        </div>
      </div>
      {msg && <div className="card" style={{ background:'#FDF5EF' }}>{msg}</div>}
      <nav className="row" style={{ marginBottom:12 }}>
        <button className={tab === 'users' ? 'on' : ''} onClick={() => setTab('users')}>用户（{users.length}）</button>
        <button className={tab === 'props' ? 'on' : ''} onClick={() => setTab('props')}>待确认配对（{props.filter(p => p.status === 'proposed').length}）</button>
        <button className={tab === 'intros' ? 'on' : ''} onClick={() => setTab('intros')}>已发出的介绍（{intros.length}）</button>
        {tab === 'users' && <select value={filter} onChange={e => setFilter(e.target.value)} style={{ marginLeft:'auto' }}><option value="all">全部</option><option value="real">真实用户</option><option value="test">测试用户</option><option value="untagged">未标外形</option></select>}
      </nav>
      {tab === 'users' && <div className="grid">{shown.map(u => <UserCard key={u.id} u={u} onSaved={load}/>)}</div>}
      {tab === 'props' && <Proposals list={props} reload={load}/>}
      {tab === 'intros' && <Intros list={intros}/>}
    </div>
  );
}

function Root(){
  const [ok, setOk] = useState(null);
  const check = () => api('/api/admin/me').then(r => setOk(r.admin)).catch(() => setOk(false));
  useEffect(() => { check(); }, []);
  if (ok === null) return null;
  return ok ? <Admin onLogout={() => setOk(false)}/> : <Login onDone={check}/>;
}
createRoot(document.getElementById('root')).render(<Root/>);
