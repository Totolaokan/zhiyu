import React, { useState, useEffect, useRef } from 'react';
import { api, uploadPhoto, photoUrl } from './api.js';
export { I, Typing, Ahe, Toggle, Portrait };

const parseJSON = (t) => { if (!t) return null; const s = t.indexOf('{'), e = t.lastIndexOf('}'); if (s < 0 || e <= s) return null; try { return JSON.parse(t.slice(s, e + 1)); } catch (x) { return null; } };
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
const uid = () => Math.random().toString(36).slice(2, 9);
const pick = (a) => a[Math.floor(Math.random() * a.length)];
const clean = (t) => (t || '').trim().replace(/^["“「]+|["”」]+$/g, '');

/* ============ Icons ============ */
const S = (p) => <svg width={p.s||20} height={p.s||20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={p.w||1.7} strokeLinecap="round" strokeLinejoin="round">{p.children}</svg>;
const I = {
  lock:(p)=><S {...p}><rect x="5" y="11" width="14" height="9" rx="2.5"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></S>,
  sprout:(p)=><S {...p}><path d="M12 20v-8"/><path d="M12 12c0-3.5-2.5-6-7-6 0 4 2.5 6 7 6z"/><path d="M12 14c0-3 2-5.5 7-5.5 0 3.5-2.5 5.5-7 5.5z"/></S>,
  sun:(p)=><S {...p}><circle cx="12" cy="12" r="4"/><path d="M12 3v2M12 19v2M3 12h2M19 12h2M5.6 5.6l1.4 1.4M17 17l1.4 1.4M5.6 18.4L7 17M17 7l1.4-1.4"/></S>,
  chat:(p)=><S {...p}><path d="M20 11.5a7.5 7.5 0 0 1-11 6.6L4 19.5l1.3-4.3A7.5 7.5 0 1 1 20 11.5z"/></S>,
  leaf:(p)=><S {...p}><path d="M5 19c0-8 5-13 14-14-1 9-6 14-14 14z"/><path d="M5 19l7-7"/></S>,
  user:(p)=><S {...p}><circle cx="12" cy="8.5" r="3.5"/><path d="M5 20c1-4 4-6 7-6s6 2 7 6"/></S>,
  spark:(p)=><S {...p}><path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/></S>,
  send:(p)=><S {...p}><path d="M12 19V5M6 11l6-6 6 6"/></S>,
  plus:(p)=><S {...p}><path d="M12 5v14M5 12h14"/></S>,
  back:(p)=><S {...p}><path d="M15 5l-7 7 7 7"/></S>,
  x:(p)=><S {...p}><path d="M6 6l12 12M18 6L6 18"/></S>,
  check:(p)=><S {...p}><path d="M5 12.5l4.5 4.5L19 7.5"/></S>,
  eyeoff:(p)=><S {...p}><path d="M3 3l18 18"/><path d="M10.6 6.2A9.6 9.6 0 0 1 12 6c5 0 8.5 4.5 9 6-.3.9-1.4 2.6-3.1 4M6.3 7.7C4.4 9 3.3 10.8 3 12c.5 1.5 4 6 9 6 1.4 0 2.6-.3 3.7-.8"/></S>,
  shield:(p)=><S {...p}><path d="M12 3l7 3v5c0 5-3 8-7 10-4-2-7-5-7-10V6z"/><path d="M9 12l2 2 4-4"/></S>,
  moon:(p)=><S {...p}><path d="M19 14.5A7.5 7.5 0 0 1 9.5 5a7.5 7.5 0 1 0 9.5 9.5z"/></S>,
  pen:(p)=><S {...p}><path d="M4 20h4L19 9l-4-4L4 16z"/></S>,
  dice:(p)=><S {...p}><rect x="4" y="4" width="16" height="16" rx="4"/><circle cx="9" cy="9" r=".8" fill="currentColor"/><circle cx="15" cy="15" r=".8" fill="currentColor"/><circle cx="15" cy="9" r=".8" fill="currentColor"/><circle cx="9" cy="15" r=".8" fill="currentColor"/></S>,
  cards:(p)=><S {...p}><rect x="7" y="4" width="12" height="16" rx="2.5"/><path d="M5 7v11a2 2 0 0 0 2 2h8"/></S>,
  image:(p)=><S {...p}><rect x="4" y="5" width="16" height="14" rx="2.5"/><circle cx="9" cy="10" r="1.5"/><path d="M20 16l-5-5-8 8"/></S>,
  copy:(p)=><S {...p}><rect x="8" y="8" width="11" height="11" rx="2"/><path d="M5 15V6a1 1 0 0 1 1-1h9"/></S>,
  chev:(p)=><S {...p}><path d="M9 6l6 6-6 6"/></S>,
  heart:(p)=><S {...p}><path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z"/></S>,
  mail:(p)=><S {...p}><rect x="3.5" y="5.5" width="17" height="13" rx="2.5"/><path d="M4 7l8 6 8-6"/></S>,
  brain:(p)=><S {...p}><circle cx="12" cy="12" r="8"/><path d="M12 8v4l2.5 2.5"/></S>,
};

/* ============ First meeting: ≤10 concrete questions ============ */
const MAXQ = 10;
const RESERVED = ['who','intent'];
const CITY_GUESS = {
  上海:{ often:['滨江','武康路、安福路一带','家附近的咖啡店','商场'], corner:['滨江边的长椅','一家开得很晚的咖啡店','家里的阳台','末班地铁上'] },
  北京:{ often:['胡同里转转','三里屯','公园','家附近的咖啡店'], corner:['后海边上','一家安静的书店','家里的飘窗','二环上开车兜圈'] },
  深圳:{ often:['深圳湾','商场','家附近的咖啡店','爬山'], corner:['深圳湾的海边','一家安静的咖啡店','家里的阳台','公司楼下'] },
  杭州:{ often:['西湖边','家附近的咖啡店','商场','爬山'], corner:['西湖边','一条没什么人的小路','家里的阳台','一家常去的店'] },
  广州:{ often:['珠江边','老城区吃东西','商场','家附近的咖啡店'], corner:['珠江边','一家常去的糖水铺','家里的阳台','天台'] },
  成都:{ often:['玉林路一带','茶馆','火锅店','家附近的咖啡店'], corner:['河边','一家常去的茶馆','家里的阳台','人民公园'] },
};
const cityKey = (c) => Object.keys(CITY_GUESS).find(k => (c || '').includes(k));
const INTENT_OPTS = [
  { v:'先交个朋友', k:'friend', s:'不急，先看聊不聊得来' },
  { v:'轻松约会', k:'date', s:'吃饭、看展，合适再说' },
  { v:'认真谈恋爱', k:'serious', s:'想找一个长期的人' },
  { v:'以结婚为前提', k:'marry', s:'希望 1–2 年内有结果' },
  { v:'成年人的轻松关系', k:'casual', s:'彼此尊重，不谈承诺' },
  { v:'还没想清楚', k:'unsure', s:'边认识边感受' },
];
const FLOW = {
  name:{ key:'name', type:'text', ph:'名字或昵称', skip:'先不说', say:()=>['先认识一下，我该怎么称呼你？'],
    fb:(v)=> v === '朋友' ? '好，那我先叫你“朋友”。' : `${v}，记住了。`,
    next:(a)=> a.name === '朋友' ? 'city' : 'nameStory' },
  nameStory:{ key:'nameStory', type:'single', say:(a)=>[`「${a.name}」这个名字，有什么来历吗？`],
    opts:[
      { v:'家里人取的，有点讲究', go:'nameWhy', fb:'那一定有个说法。' },
      { v:'随便取的，没什么故事', fb:'哈，也挺好，名字本来就是给人叫的。' },
      { v:'是我自己起的', go:'nameWhy', fb:'自己起名字的人，不多。' },
      { v:'小名，只有熟人这么叫', fb:'那我算半个熟人了。' },
    ], next:'city' },
  nameWhy:{ key:'nameWhy', type:'text', ph:'说说看…', skip:'下次再说', branch:true,
    say:(a)=>[a.nameStory === '是我自己起的' ? '为什么是这个名字？' : '什么讲究？说来听听。'],
    fb:()=> '这个我记住了。', next:'city' },
  city:{ key:'city', type:'text', ph:'城市', chips:['上海','北京','深圳','杭州','广州','成都'], say:()=>['你现在住在哪座城市？'],
    fb:(v)=> `${v}，好地方。`, next:'grew' },
  grew:{ key:'grew', type:'single', say:(a)=>[`是在${a.city || '这儿'}长大的，还是后来来的？`],
    opts:[{ v:'在这儿长大的', fb:'那你对这里的路，应该闭着眼都认得。' },{ v:'从别处来的，来了几年', fb:'几年了，应该慢慢有自己的地盘了。' },{ v:'刚来不久', fb:'刚来的时候，什么都新鲜，也什么都不熟。' },{ v:'来来回回好几次', fb:'来来回回，说明这里总有什么东西拉着你。' }],
    writePh:'比如：老家是哪里…', next:'often' },
  often:{ key:'often', type:'single', dyn:true, say:()=>['下班或者周末，你最常去哪儿？'],
    fbOpts:(a)=> (CITY_GUESS[cityKey(a.city)] || {}).often || ['家附近的咖啡店','公园或者江边','商场','基本在家'],
    fb:(v)=> v.includes('家') ? '在家待着，也是一种去处。' : '那里我记下了。', next:'corner' },
  corner:{ key:'corner', type:'single', dyn:true, say:(a)=>[`${a.city || '这座城市'}里，有没有一个你喜欢一个人待着的角落？`],
    fbOpts:(a)=> [...((CITY_GUESS[cityKey(a.city)] || {}).corner || ['家里的某个位置','一家常去的店','一条常走的路']).slice(0, 3), '好像没有'],
    fbGuess:0, fb:(v)=> v === '好像没有' ? '也正常。很多人一个人的时候，就待在家里。' : '嗯，我能想象那个地方。',
    next:(a)=> a.corner && a.corner !== '好像没有' ? 'cornerWhy' : 'sleep' },
  cornerWhy:{ key:'cornerWhy', type:'single', branch:true, say:()=>['为什么是那儿？'],
    opts:[{ v:'安静，没人打扰' },{ v:'没人认识我' },{ v:'能看得很远' },{ v:'习惯了，说不上来' }],
    fb:(v)=> v === '没人认识我' ? '不用当任何人，挺轻松的。' : '我懂了。', next:'sleep' },
  sleep:{ key:'sleep', type:'single', optional:true, say:()=>['你一般几点睡？'],
    opts:[{ v:'12 点前' },{ v:'12 点到 1 点' },{ v:'1 点以后' },{ v:'很不规律' }], fbGuess:1,
    fb:(v)=> v === '12 点前' ? '作息这么好，不多见了。' : v === '1 点以后' ? '夜里那段时间，大概是留给自己的。' : '嗯，跟大多数人差不多。', next:'people' },
  people:{ key:'people', type:'single', optional:true, say:()=>['最近最常联系的人是谁？'],
    opts:[{ v:'家里人' },{ v:'一两个老朋友' },{ v:'同事' },{ v:'最近没怎么跟人联系' }],
    fb:(v)=> v === '最近没怎么跟人联系' ? '那今天，算我一个。' : '有人可以常联系，挺好的。', next:'who' },
  who:{ key:'who', type:'single', noWrite:true, say:()=>['问个实际的。','你是男生还是女生？想认识的是？'],
    opts:[{ v:'女生，想认识男生', g:'女生', sk:'男生' },{ v:'男生，想认识女生', g:'男生', sk:'女生' },{ v:'女生，想认识女生', g:'女生', sk:'女生' },{ v:'男生，想认识男生', g:'男生', sk:'男生' },{ v:'不想说 / 都可以', g:'不便透露', sk:'都可以' }],
    fb:()=> '好，记下了。', next:'intent' },
  intent:{ key:'intent', type:'single', note:'只用来匹配想法一样的人，不会显示在你的资料上',
    say:()=>['最后一个，也是最实在的。','来这里，你现在想找的是？我不评判，只帮你找想法一样的人。'],
    opts:INTENT_OPTS, fb:(v)=> ({ '先交个朋友':'好，慢慢来。', '轻松约会':'明白，轻松一点。', '认真谈恋爱':'好，认真的心意，我会认真对待。', '以结婚为前提':'谢谢你直说，这样能少走很多弯路。', '成年人的轻松关系':'收到，不用解释。', '还没想清楚':'没关系，边认识边想。' }[v] || '收到。'),
    next:'DONE' },
};
const INTENTS = INTENT_OPTS;
export { INTENTS, MAXQ, FLOW, clean, sleep, uid };
const qText = (n, a) => { const l = n.say(a); return l[l.length - 1]; };
/* budget: optional nodes are skipped when they'd push the total past MAXQ */
function resolveNext(id, a, asked){
  let nx = id;
  while (nx && nx !== 'DONE' && FLOW[nx].optional && asked + 1 + RESERVED.length > MAXQ) nx = FLOW[nx].next;
  return nx;
}
const GUESS_FB = (a) => {
  if (a.sleep === '1 点以后' || a.corner && a.corner !== '好像没有') return '我猜，你是那种白天把事情都做得好好的，晚上才留一点时间给自己的人。热闹也可以，但真正放松，是一个人的时候。';
  if (a.people === '家里人' || a.often && a.often.includes('朋友')) return '我猜，你是很顾念身边人的那种人。别人的事你记得很清楚，自己的事反而很少说。';
  return '我猜，你不是一下子就跟人很熟的人。但熟了以后，会很靠得住。';
};

/* ============ Profile ============ */
function fallbackSummary(a){
  const t = [];
  if (a.corner && a.corner !== '好像没有') t.push('需要一个人的时间');
  if (a.sleep === '1 点以后') t.push('夜里留给自己');
  if (a.people === '一两个老朋友') t.push('朋友不多，但很铁');
  if (a.people === '家里人') t.push('顾家');
  if (a.grew && a.grew.includes('别处')) t.push('一个人在外打拼');
  if (a.nameStory === '随便取的，没什么故事') t.push('不讲究，好相处');
  if (!t.length) t.push('慢热', '靠得住');
  return {
    headline: a.corner && a.corner !== '好像没有' ? '热闹也行，但更需要一个角落' : '慢热，但靠得住',
    about: `住在${a.city || '一座城市'}，常去${a.often || '家附近'}。${a.corner && a.corner !== '好像没有' ? `一个人的时候，会去${a.corner}。` : ''}`,
    traits: t.slice(0, 4),
  };
}
export function buildProfile(ob, sum, edit){
  const a = ob.ans || {};
  const s = sum || fallbackSummary(a);
  const base = {
    name: a.name || '朋友', headline: s.headline, about: s.about,
    traits: (s.traits || []).map((label, i) => ({ label, w: i === 0 ? 3 : 2 })),
    intent: a.intent || '还没想清楚', seek: a.seek || '都可以', city: a.city || '',
  };
  return { ...base, ...(edit || {}) };
}
function profileText(pf){
  if (!pf) return '（未知）';
  return `${pf.about} 特点：${(pf.traits || []).map(x => x.label).join('、')}。心意：${pf.intent}。`;
}
function nextLetter(){ const d = new Date(); const n = new Date(d.getFullYear(), d.getMonth() + 1, 1); return { m: n.getMonth() + 1, days: Math.ceil((n - d) / 86400000), mname: ['一','二','三','四','五','六','七','八','九','十','十一','十二'][n.getMonth()] }; }

/* ============ Small components ============ */
function Toggle({ on, onChange }){ return <button className={'tg' + (on ? ' on' : '')} onClick={() => onChange(!on)} aria-pressed={on}/>; }
function Portrait({ p, size = 56, radius, w, h }){
  const [a, b, c] = p.tone;
  return (
    <div className="portrait" style={{ width: w || size, height: h || size, borderRadius: radius ?? size / 2, fontSize: (h || size) * 0.34,
      background:`radial-gradient(120% 90% at 18% 12%, ${a} 0%, transparent 62%), radial-gradient(90% 90% at 88% 85%, ${c} 0%, transparent 60%), ${b}` }}>
      <svg viewBox="0 0 100 100" preserveAspectRatio="xMidYMid slice"><circle cx="50" cy="40" r="15" fill="#fff" opacity=".13"/><path d="M20 100c2-24 15-36 30-36s28 12 30 36z" fill="#fff" opacity=".11"/></svg>
      <span>{p.name[0]}</span>
    </div>
  );
}
function Typing(){ return <div className="typing"><i/><i/><i/></div>; }
function Ahe({ s = 30 }){ return <div style={{ width:s, height:s, borderRadius:'50%', background:'linear-gradient(145deg,#E3EEE7,#BFD5C8)', display:'flex', alignItems:'center', justifyContent:'center', color:'var(--brand)', flex:'none' }}><I.sprout s={s*0.56}/></div>; }

/* ============ 阿禾 · the heart ============ */
const CRISIS = /不想活|想死|自杀|轻生|结束生命|活着没意思|伤害自己|割腕|跳楼/;
const CRISIS_REPLY = ['谢谢你愿意告诉我。听起来你现在真的很辛苦，我很在意你的安全。','如果你现在有伤害自己的念头，请马上联系一个你信任的人，或者拨打你所在地的紧急求助电话。','我在这儿，你可以继续跟我说。'];
function freeFallback(t, n){
  if (CRISIS.test(t)) return { reply: CRISIS_REPLY.join('\n'), crisis:true };
  const rules = [
    [/累|疲|撑不住|加班/, '辛苦了。\n今天是忙的累，还是烦的累？'],
    [/睡不着|失眠|半夜|凌晨/, '又睡不着啊。\n是有事在脑子里转，还是单纯不困？'],
    [/喜欢|暗恋|分手|前任|感情|恋爱|对象|吵架/, '感情的事，跟身边人反而不好说。\n你说，我听着。'],
    [/孤独|一个人|没人|寂寞/, '一个人的时候，确实会有那么几个时刻特别明显。\n今天是哪个时刻？'],
    [/焦虑|迷茫|不知道|方向|未来|工作/, '这种不确定的感觉，挺磨人的。\n最让你放不下的是哪件？'],
    [/开心|高兴|好消息|哈哈/, '真好。\n说说看，什么事？'],
  ];
  for (const [re, r] of rules) if (re.test(t)) return { reply:r, notes:[] };
  return { reply: ['嗯，我听着。\n然后呢？','我好像懂一点了。\n你愿意多说点吗？不说也没事。','听起来不太容易。\n现在怎么样了？'][n % 3], notes:[] };
}
const withTimeout = (p, ms) => Promise.race([p, new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), ms))]);
const STYLE = '说人话，像朋友聊天。具体地接住 TA 说的细节（地名、人、习惯、名字）。不要文艺腔，不要心理咨询腔，不要用“被看见”“治愈”“内心”“灵魂”“温柔”“疗愈”“能量”这类词，不夸张，不说教，不用感叹号。';

export function AheTab({ ob, setOb, prefs, setPrefs, onSummary, onGoMe, onGoChat, visible, photos, setPhotos, saveNow }){
  const obRef = useRef(ob); obRef.current = ob;
  const upd = (fn) => { const n = fn(obRef.current); obRef.current = n; setOb(n); };
  const push = (m) => upd(o => ({ ...o, msgs:[...o.msgs, { id:uid(), ...m }] }));
  const [typing, setTyping] = useState(false);
  const [busy, setBusy] = useState(false);
  const [write, setWrite] = useState(false);
  const [text, setText] = useState('');
  const [input, setInput] = useState('');
  const [drawer, setDrawer] = useState(false);
  const scRef = useRef(null);
  const alive = useRef(true);
  useEffect(() => () => { alive.current = false; }, []);

  async function say(lines){
    for (const l of lines) {
      if (!alive.current) return;
      setTyping(true); await sleep(420 + Math.min(1000, l.length * 20)); setTyping(false);
      push({ kind:'ai', text:l }); await sleep(140);
    }
  }
  const known = () => obRef.current.log.map(l => `${l.q}：${l.a}`).join('；') || '（还不了解）';

  useEffect(() => { (async () => {
    const o = obRef.current;
    if (!o.started) {
      upd(x => ({ ...x, started:true, mode:'meet', phase:'busy' }));
      push({ kind:'intro' });
      await sleep(500);
      await say(['你好，我是阿禾。','有什么想说的，都可以跟我说。我先问你几个简单的，不多。']);
      if (!alive.current) return;
      await goNode('name', null);
    } else if (o.mode === 'meet' && o.phase === 'busy') {
      await goNode(o.node, null, true);
    } else if (o.mode === 'meet' && o.phase === 'ask') {
      setWrite(FLOW[o.node].type === 'text');
    }
  })(); }, []);
  useEffect(() => { const el = scRef.current; if (el) setTimeout(() => el.scrollTo({ top:el.scrollHeight, behavior:'smooth' }), 30); }, [ob.msgs.length, typing, ob.phase, ob.mode, visible, write]);

  /* ---- first meeting ---- */
  function optsFor(n, a, gen){
    if (n.dyn) {
      let list = (gen && gen.chips && gen.chips.length >= 2) ? gen.chips.slice(0, 4).map(String) : n.fbOpts(a);
      if (n.key === 'corner' && !list.includes('好像没有')) list = [...list.slice(0, 3), '好像没有'];
      return list.map(v => ({ v }));
    }
    return n.opts || null;
  }
  async function goNode(id, gen, again){
    const n = FLOW[id]; const a = obRef.current.ans;
    const opts = optsFor(n, a, gen);
    let g = gen && Number.isInteger(gen.guess) ? gen.guess : (gen ? -1 : (n.fbGuess ?? -1));
    if (!opts || g < 0 || g >= opts.length) g = -1;
    upd(o => ({ ...o, mode:'meet', node:id, phase:'busy', curOpts:opts, curGuess:g, asked: again ? o.asked : o.asked + 1 }));
    await say(n.say(a));
    if (!alive.current) return;
    setText(''); setWrite(n.type === 'text');
    upd(o => ({ ...o, phase:'ask' }));
  }
  async function answer({ v, opt, typed, skip }){
    const o = obRef.current; const id = o.node; const n = FLOW[id];
    if (o.phase !== 'ask') return;
    upd(x => ({ ...x, phase:'busy' })); setWrite(false); setText('');
    let val = v;
    if (skip && id === 'name') val = '朋友';
    push({ kind:'me', text: skip ? n.skip : v });
    const patch = { [n.key]:val };
    if (id === 'who' && opt) { patch.gender = opt.g; patch.seek = opt.sk; }
    if (id === 'intent') patch.intentK = opt ? opt.k : 'unsure';
    const hit = o.curGuess >= 0 && o.curOpts && !typed && o.curOpts[o.curGuess] && o.curOpts[o.curGuess].v === v;
    const a2 = { ...o.ans, ...patch };
    upd(x => ({ ...x, ans:a2, guessStat: o.curGuess >= 0 && !typed ? { hit:x.guessStat.hit + (hit ? 1 : 0), total:x.guessStat.total + 1 } : x.guessStat,
      log:[...x.log.filter(l => l.key !== n.key), { key:n.key, cat:'初次见面', q:qText(n, o.ans), a: skip ? '（没说）' : String(v) }] }));
    let nx = typeof n.next === 'function' ? n.next(a2) : n.next;
    if (opt && opt.go) nx = opt.go;
    nx = resolveNext(nx, a2, obRef.current.asked);
    const N = nx !== 'DONE' ? FLOW[nx] : null;
    // one Claude call: react to this answer + prepare the next question's chips / guess
    setTyping(true);
    let gen = null;
    if (!skip) {
      try {
        const nextOpts = N && (N.opts || (N.dyn ? N.fbOpts(a2) : null));
        gen = await withTimeout(api('/api/ahe/react', { known: known(), q: qText(n, o.ans), v: String(v), typed: !!typed,
          nextQ: N ? qText(N, a2) : '', dyn: !!(N && N.dyn), nextOpts: nextOpts ? nextOpts.map(x => x.v || x) : [] }), 14000);
      } catch (e) { gen = null; }
    }
    setTyping(false);
    const reply = (gen && gen.reply && clean(gen.reply)) || (opt && opt.fb) || (n.fb ? n.fb(val) : '');
    const lines = [];
    if (hit) lines.push('猜中了。');
    if (reply) lines.push(reply);
    if (lines.length) await say(lines);
    if (gen && gen.note) upd(x => ({ ...x, log:[...x.log, { key:'n' + uid(), cat:'阿禾记下的', q:'关于你', a:clean(gen.note) }] }));
    if (nx === 'DONE') return finishMeet();
    await goNode(nx, gen && (gen.chips || Number.isInteger(gen.guess)) ? gen : null);
  }
  async function pauseMeet(){
    if (obRef.current.phase !== 'ask') return;
    upd(x => ({ ...x, mode:'free', phase:'idle', resumeNode:x.node, freeSince:0 }));
    setWrite(false);
    await say(['好，先不问了。想聊什么都行。']);
  }
  async function resumeMeet(){
    const r = obRef.current.resumeNode; if (!r || busy) return;
    upd(x => ({ ...x, resumeNode:null }));
    await say(['好，接着刚才的。']);
    await goNode(r, null, true);
  }
  async function finishMeet(){
    upd(x => ({ ...x, phase:'busy', firstDone:true }));
    const gs = obRef.current.guessStat;
    push({ kind:'done', text:`初次见面 · 完成${gs.total ? ` · 阿禾猜中 ${gs.hit}/${gs.total}` : ''}` });
    setTyping(true);
    let t = '';
    try { t = clean((await withTimeout(api('/api/ahe/guess', { known: known() }), 14000)).text); } catch (e) {}
    await sleep(t ? 200 : 900); setTyping(false);
    push({ kind:'guesscard', text: t || GUESS_FB(obRef.current.ans), resp:null });
    upd(x => ({ ...x, mode:'free', phase:'idle', freeSince:0 }));
  }
  async function respondGuess(m, yes){
    if (m.resp || busy) return;
    setBusy(true);
    upd(x => ({ ...x, msgs:x.msgs.map(y => y.id === m.id ? { ...y, resp: yes ? 'yes' : 'no' } : y),
      log:[...x.log, { key:'g' + uid(), cat:'阿禾记下的', q:'阿禾的猜测', a:(yes ? '说中了：' : '不太对：') + m.text.replace(/^我猜，?/, '').slice(0, 24) }] }));
    push({ kind:'me', text: yes ? '被你说中了' : '不太对' });
    await say([yes ? '嗯，我会记得。' : '好，那我再多了解你一点。', '就问这些。之后我不会一直提问了。', '想说什么就说，我听着，也记着。']);
    await sleep(300);
    push({ kind:'photo' });
    setBusy(false);
  }
  async function photoDone(mid, saved){
    setBusy(true);
    upd(x => ({ ...x, msgs:x.msgs.map(m => m.id === mid ? { ...m, done:true } : m) }));
    const count = photos.length;
    push({ kind:'me', text: saved ? `放好了 ${count} 张` : '以后再说' });
    upd(x => ({ ...x, log:[...x.log.filter(l => l.key !== 'photos'), { key:'photos', cat:'初次见面', q:'照片', a: saved ? `${count} 张 · 人工审核中` : '暂未上传' }] }));
    await say([saved ? '收到。现在只有审核同事能看到。等你们互相愿意认识，对方才会看到。' : '没关系，想放的时候在「我」里随时可以加。']);
    setTyping(true);
    let s = null;
    try { await saveNow(obRef.current); s = (await withTimeout(api('/api/ahe/summary', {}), 25000)).summary; } catch (e) { await sleep(800); }
    setTyping(false);
    if (s && s.headline) onSummary({ headline:clean(s.headline), about:clean(s.about || ''), traits:(s.traits || []).slice(0, 4).map(String) });
    push({ kind:'reveal', s: s && s.headline ? s : null });
    await sleep(400);
    await say(['有合适的人，我会写成一封信放在「聊天」里，也会发邮件告诉你。']);
    setBusy(false);
  }

  /* ---- free talk: listen, and quietly remember ---- */
  async function sendFree(t){
    t = (t || '').trim(); if (!t || busy) return;
    setInput(''); setBusy(true);
    push({ kind:'me', text:t });
    const o = obRef.current; const n = o.freeSince || 0;
    setTyping(true);
    let j = null;
    try { j = await api('/api/ahe/chat', { text: t }); } catch (e) { j = null; }
    if (!j || !j.reply) j = freeFallback(t, n);
    setTyping(false);
    const parts = String(j.reply).split(/\n+/).map(s => s.trim()).filter(Boolean);
    for (let i = 0; i < parts.length; i++) { if (i) { setTyping(true); await sleep(650); setTyping(false); } push({ kind:'ai', text:parts[i] }); }
    const notes = (j.notes || []).filter(x => x && String(x).trim()).slice(0, 3);
    upd(x => ({ ...x, freeSince:(x.freeSince || 0) + 1, memNew: x.memNew + notes.length,
      log:[...x.log, ...notes.map(nt => ({ key:'f' + uid(), cat:'聊天时提到', q:'聊天时提到', a:clean(String(nt)) }))] }));
    setBusy(false);
  }

  /* ---- render ---- */
  const inMeet = ob.mode === 'meet';
  const n = FLOW[ob.node] || FLOW.name;
  const opts = ob.curOpts;
  const gi = ob.curGuess;
  const order = opts ? opts.map((_, i) => i) : [];
  if (opts && gi >= 0) { order.splice(order.indexOf(gi), 1); order.unshift(gi); }
  const twoCol = opts && !opts.some(o => o.s) && opts.every(o => o.v.length <= 7) && !(gi >= 0);
  const lastKind = ob.msgs.length ? ob.msgs[ob.msgs.length - 1].kind : '';
  const starters = ['今天有点累','有件事想说说','感情上有点困惑','睡不着'];
  const est = Math.min(MAXQ, Math.max(ob.asked, 8));

  let bottom = null;
  if (inMeet && ob.phase === 'ask') {
    const showInput = write || !opts;
    bottom = (
      <div className="tray" key={ob.node + (showInput ? 'w' : 'o')} style={{ marginBottom:90 }}>
        {n.note && <div className="traynote"><I.lock s={13}/>{n.note}</div>}
        {!showInput && (
          <div className={'opts' + (twoCol ? ' two' : '')}>
            {order.map((idx, i) => {
              const o = opts[idx]; const isG = idx === gi;
              return (
                <button key={o.v} className={'opt' + (isG ? ' guess' : '')} style={{ animationDelay:i * 40 + 'ms' }} onClick={() => answer({ v:o.v, opt:o })}>
                  <span>{o.v}{o.s && <span className="s">{o.s}</span>}</span>
                  {isG && <span className="gbadge"><I.spark s={11}/>阿禾猜</span>}
                </button>
              );
            })}
            {!n.noWrite && <button className="opt write" style={{ animationDelay:order.length * 40 + 'ms' }} onClick={() => setWrite(true)}><span className="row gap6"><I.pen s={15}/>{gi >= 0 ? '都不是，我自己说' : '自己写'}</span></button>}
          </div>
        )}
        {showInput && (
          <>
            {n.chips && <div className="row gap6" style={{ flexWrap:'wrap', marginBottom:10 }}>{n.chips.map(c => <button key={c} className="minichip" onClick={() => answer({ v:c })}>{c}</button>)}</div>}
            <div className="inputrow">
              {opts && <button className="iconbtn" onClick={() => setWrite(false)}><I.back s={18}/></button>}
              <textarea autoFocus rows={1} value={text} placeholder={n.ph || n.writePh || '用自己的话说说…'} onChange={e => setText(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) { e.preventDefault(); text.trim() && answer({ v:text.trim(), typed:!!opts }); } }}/>
              <button className="sendbtn" disabled={!text.trim()} onClick={() => answer({ v:text.trim(), typed:!!opts })}><I.send s={19}/></button>
            </div>
            {n.skip && <button className="tiny" style={{ marginTop:10, alignSelf:'center' }} onClick={() => answer({ v:n.skip, skip:true })}>{n.skip}</button>}
          </>
        )}
      </div>
    );
  } else if (!inMeet) {
    bottom = (
      <div style={{ flex:'none' }}>
        {!busy && !typing && lastKind !== 'me' && (
          <div className="starters">
            {ob.resumeNode && <button className="hl" onClick={resumeMeet}><span className="row gap6"><I.spark s={13}/>接着刚才的问题</span></button>}
            {!ob.freeSince && starters.map((s, i) => <button key={s} style={{ animationDelay:(i + 1) * 40 + 'ms' }} onClick={() => sendFree(s)}>{s}</button>)}
          </div>
        )}
        <div className="ahecomposer inputrow">
          <textarea rows={1} value={input} placeholder="想说什么都可以…" onChange={e => setInput(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) { e.preventDefault(); sendFree(input); } }}/>
          <button className="sendbtn" disabled={!input.trim() || busy} onClick={() => sendFree(input)}><I.send s={19}/></button>
        </div>
      </div>
    );
  } else bottom = <div style={{ height:96, flex:'none' }}/>;

  return (
    <div className="screen night" style={{ display:visible ? 'flex' : 'none' }}>
      <div className="bgorbs">
        <div className="orb" style={{ width:320, height:320, left:-140, top:-90, background:'#2F6A55', opacity:.6 }}/>
        <div className="orb" style={{ width:260, height:260, right:-130, top:60, background:'#C47F5B', opacity:.38, animationDelay:'-5s' }}/>
        <div className="orb" style={{ width:240, height:240, left:40, bottom:80, background:'#2D4A66', opacity:.3, animationDelay:'-9s' }}/>
      </div>
      <div className="safe"/>
      <div className="ahehead">
        <div className="aheorb"/>
        <div style={{ flex:1, lineHeight:1.3 }}>
          <div style={{ fontWeight:700, fontSize:18, letterSpacing:'.02em' }}>阿禾</div>
          <div className="tiny">{typing ? '正在输入…' : '在这儿'}</div>
        </div>
        <button className="iconbtn" style={{ position:'relative' }} onClick={() => { setDrawer(true); upd(x => ({ ...x, memNew:0 })); }} title="隐私与记忆">
          <I.lock s={18}/>{ob.memNew > 0 && <span className="memdot"/>}
        </button>
      </div>
      {inMeet && (
        <div className="chstrip">
          <span style={{ fontSize:13, fontWeight:500, whiteSpace:'nowrap' }}>初次见面</span>
          <div className="qdots">{Array.from({ length:est }).map((_, i) => <i key={i} className={i < ob.asked ? 'on' : ''}/>)}</div>
          <span className="tiny" style={{ whiteSpace:'nowrap' }}>{ob.asked}/{est}</span>
          <button className="tiny" style={{ whiteSpace:'nowrap', color:'rgba(255,255,255,.6)', marginLeft:4 }} onClick={pauseMeet}>先聊别的</button>
        </div>
      )}
      <div className="scroll" ref={scRef} style={{ position:'relative' }}>
        <div className="msgs">
          {ob.msgs.map(m => {
            if (m.kind === 'intro') return <div key={m.id} className="introline fade"><I.lock s={12}/>阿禾 · 可以说心里话的 AI 朋友 · 只有你能看到</div>;
            if (m.kind === 'done') return <div key={m.id} className="chdone pop"><I.check s={13} w={2.2}/>{m.text}</div>;
            if (m.kind === 'guesscard') return (
              <div key={m.id} className="insight pop">
                <div className="orb" style={{ width:120, height:120, right:-30, bottom:-50, background:'#F0B593', opacity:.5 }}/>
                <div className="lab" style={{ position:'relative' }}><I.spark s={13}/>阿禾的猜测</div>
                <p style={{ position:'relative' }}>{m.text}</p>
                {!m.resp && (
                  <div className="row gap8" style={{ marginTop:14, position:'relative' }}>
                    <button className="gbtn on" onClick={() => respondGuess(m, true)}>被你说中了</button>
                    <button className="gbtn" onClick={() => respondGuess(m, false)}>不太对</button>
                  </div>
                )}
              </div>
            );
            if (m.kind === 'photo') return <PhotoCard key={m.id} m={m} ob={ob} upd={upd} prefs={prefs} setPrefs={setPrefs} photos={photos} setPhotos={setPhotos} onDone={(s) => photoDone(m.id, s)}/>;
            if (m.kind === 'reveal') return <RevealCard key={m.id} ob={ob} s={m.s} onGoMe={onGoMe} onGoChat={onGoChat}/>;
            if (m.kind === 'me') return <div key={m.id} className="me-line pop">{m.text}</div>;
            return <div key={m.id} className="ai-line rise">{m.text}</div>;
          })}
          {typing && <Typing/>}
        </div>
      </div>
      {bottom}
      {drawer && <Memory log={ob.log} guess={ob.guessStat} onForget={(key) => upd(x => ({ ...x, log:x.log.filter(l => l.key !== key) }))} onClose={() => setDrawer(false)}/>}
    </div>
  );
}

function RevealCard({ ob, s, onGoMe, onGoChat }){
  const pf = buildProfile(ob, s);
  return (
    <div className="revealcard pop">
      <div className="orb" style={{ width:200, height:200, right:-70, top:-80, background:'#F0B593', opacity:.55 }}/>
      <div className="orb" style={{ width:160, height:160, left:-60, bottom:-70, background:'#BFD8C9', opacity:.7, animationDelay:'-6s' }}/>
      <div style={{ position:'relative' }}>
        <div className="tiny" style={{ letterSpacing:'.14em' }}>阿禾眼中的你</div>
        <div className="title" style={{ fontSize:24, marginTop:8 }}>{pf.headline}</div>
        <p style={{ marginTop:8, fontSize:14.5, color:'var(--ink2)', lineHeight:1.65 }}>{pf.about}</p>
        <div className="tags" style={{ marginTop:12 }}>{pf.traits.map((t, i) => <span key={i} className="chip line" style={{ background:'rgba(255,255,255,.55)' }}>{t.label}</span>)}</div>
        <div className="row gap8" style={{ marginTop:16 }}>
          <button className="btn sm" style={{ flex:1 }} onClick={onGoMe}>完整画像</button>
          <button className="btn ghost sm" style={{ flex:1 }} onClick={onGoChat}><I.mail s={15}/>去看看聊天</button>
        </div>
      </div>
    </div>
  );
}

function PhotoSlots({ photos, setPhotos, blur }){
  const [busy, setBusy] = useState(false);
  const add = async (file) => { if (!file) return; setBusy(true); try { const r = await uploadPhoto(file); setPhotos(r.photos); } catch (e) { alert('上传没成功，换一张试试'); } setBusy(false); };
  const rm = async (id) => { try { const r = await api('/api/me/photos/' + id, null, 'DELETE'); setPhotos(r.photos); } catch (e) {} };
  return (
    <div className="slots" style={{ marginTop:0 }}>
      {[0, 1, 2].map(i => (
        <div className="slot" key={i}>
          {photos[i] ? (<><img src={photoUrl(photos[i])} style={blur ? { filter:'blur(7px)', transform:'scale(1.12)' } : null}/><button className="rm" onClick={() => rm(photos[i])}><I.x s={13}/></button></>)
            : i === photos.length && busy ? <div className="spin" style={{ width:24, height:24 }}/>
            : (<><I.plus s={22}/><input type="file" accept="image/*" onChange={e => { add(e.target.files[0]); e.target.value = ''; }}/></>)}
        </div>
      ))}
    </div>
  );
}
export { PhotoSlots };
function PhotoCard({ m, prefs, setPrefs, photos, setPhotos, onDone }){
  if (m.done) return null;
  return (
    <div className="photocard pop">
      <div className="h3" style={{ marginBottom:4 }}>愿意放一两张照片吗？</div>
      <div className="tiny" style={{ marginBottom:12 }}>日常的就好。这里每个人都是真人真照。</div>
      <PhotoSlots photos={photos} setPhotos={setPhotos} blur={false}/>
      <div className="plist">
        <div><I.check s={14} w={2}/><span>只有<b style={{ fontWeight:500 }}>审核同事</b>和<b style={{ fontWeight:500 }}>你们互相愿意认识之后的那个人</b>能看到</span></div>
        <div><I.check s={14} w={2}/><span>审核只确认是否本人、照片是否清晰</span></div>
        <div><I.check s={14} w={2}/><span>不进入任何列表，没人能搜到，随时可删</span></div>
      </div>
      <div className="row gap8" style={{ marginTop:14 }}>
        <button className="btn ghost sm" style={{ flex:1 }} onClick={() => onDone(false)}>以后再说</button>
        <button className="btn sm" style={{ flex:1 }} disabled={!photos.length} onClick={() => onDone(true)}>放好了</button>
      </div>
    </div>
  );
}

export function Memory({ log, guess, onForget, onClose }){
  const cats = ['初次见面','阿禾记下的','聊天时提到'];
  return (
    <div className="overlay" onClick={onClose} style={{ color:'var(--ink)' }}>
      <div className="sheet" onClick={e => e.stopPropagation()}>
        <div className="grab"/>
        <div className="pad" style={{ paddingTop:6, paddingBottom:12 }}>
          <div className="title" style={{ fontSize:22 }}>隐私与记忆</div>
          <div className="plist" style={{ marginTop:10 }}>
            <div><I.lock s={14} w={2}/><span>你和阿禾的聊天只有你能看到，不会给任何人。</span></div>
            <div><I.check s={14} w={2}/><span>阿禾记下的事，只用来更懂你、为你挑人。</span></div>
          </div>
          {guess && guess.total > 0 && <div className="chip" style={{ marginTop:12 }}><I.spark s={12}/>阿禾猜中你 {guess.hit}/{guess.total} 次</div>}
        </div>
        <div className="scroll pad" style={{ paddingBottom:26 }}>
          <div className="eyebrow" style={{ margin:'8px 0 4px' }}>阿禾记得的事 · 删掉就真的忘了</div>
          {!log.length && <p className="tiny" style={{ padding:'24px 0', textAlign:'center' }}>还没有记下什么</p>}
          {cats.map(c => {
            const items = log.filter(l => l.cat === c); if (!items.length) return null;
            return (
              <div key={c} style={{ marginTop:12 }}>
                <div className="tiny" style={{ marginBottom:6 }}>{c}</div>
                {items.map(l => (
                  <div key={l.key} className="memitem">
                    <div>{l.q !== l.cat && l.q !== '关于你' && <div className="q">{l.q}</div>}<div className="a">{l.a}</div></div>
                    <button className="tiny" style={{ flex:'none' }} onClick={() => onForget(l.key)}>忘掉</button>
                  </div>
                ))}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}