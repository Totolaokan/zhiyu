import React, { useState, useEffect, useRef } from 'react';
import { api, uploadPhoto, photoUrl } from './api.js';
export { I, Typing, Ahe, Mascot, MOOD_WORD, Toggle, Portrait, clean, sleep, uid };

const sleep = (ms) => new Promise(r => setTimeout(r, ms));
const uid = () => Math.random().toString(36).slice(2, 9);
const clean = (t) => (t || '').trim().replace(/^["“「]+|["”」]+$/g, '');

/* ============ Icons ============ */
const S = (p) => <svg width={p.s||20} height={p.s||20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={p.w||1.7} strokeLinecap="round" strokeLinejoin="round">{p.children}</svg>;
const I = {
  lock:(p)=><S {...p}><rect x="5" y="11" width="14" height="9" rx="2.5"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></S>,
  sprout:(p)=><S {...p}><path d="M12 20v-8"/><path d="M12 12c0-3.5-2.5-6-7-6 0 4 2.5 6 7 6z"/><path d="M12 14c0-3 2-5.5 7-5.5 0 3.5-2.5 5.5-7 5.5z"/></S>,
  sun:(p)=><S {...p}><circle cx="12" cy="12" r="4"/><path d="M12 3v2M12 19v2M3 12h2M19 12h2M5.6 5.6l1.4 1.4M17 17l1.4 1.4M5.6 18.4L7 17M17 7l1.4-1.4"/></S>,
  chat:(p)=><S {...p}><path d="M20 11.5a7.5 7.5 0 0 1-11 6.6L4 19.5l1.3-4.3A7.5 7.5 0 1 1 20 11.5z"/></S>,
  leaf:(p)=><S {...p}><path d="M5 19c0-8 5-13 14-14-1 9-6 14-14 14z"/><path d="M5 19l7-7"/></S>,
  user:(p)=><S {...p}><circle cx="12" cy="8.5" r="3.5"/><path d="M5 20c1-4 4-6 7-6s6 2 7 6"/></S>,
  spark:(p)=><S {...p}><path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/></S>,
  send:(p)=><S {...p}><path d="M12 19V5M6 11l6-6 6 6"/></S>,
  plus:(p)=><S {...p}><path d="M12 5v14M5 12h14"/></S>,
  back:(p)=><S {...p}><path d="M15 5l-7 7 7 7"/></S>,
  x:(p)=><S {...p}><path d="M6 6l12 12M18 6L6 18"/></S>,
  check:(p)=><S {...p}><path d="M5 12.5l4.5 4.5L19 7.5"/></S>,
  eyeoff:(p)=><S {...p}><path d="M3 3l18 18"/><path d="M10.6 6.2A9.6 9.6 0 0 1 12 6c5 0 8.5 4.5 9 6-.3.9-1.4 2.6-3.1 4M6.3 7.7C4.4 9 3.3 10.8 3 12c.5 1.5 4 6 9 6 1.4 0 2.6-.3 3.7-.8"/></S>,
  shield:(p)=><S {...p}><path d="M12 3l7 3v5c0 5-3 8-7 10-4-2-7-5-7-10V6z"/><path d="M9 12l2 2 4-4"/></S>,
  moon:(p)=><S {...p}><path d="M19 14.5A7.5 7.5 0 0 1 9.5 5a7.5 7.5 0 1 0 9.5 9.5z"/></S>,
  pen:(p)=><S {...p}><path d="M4 20h4L19 9l-4-4L4 16z"/></S>,
  dice:(p)=><S {...p}><rect x="4" y="4" width="16" height="16" rx="4"/><circle cx="9" cy="9" r=".8" fill="currentColor"/><circle cx="15" cy="15" r=".8" fill="currentColor"/><circle cx="15" cy="9" r=".8" fill="currentColor"/><circle cx="9" cy="15" r=".8" fill="currentColor"/></S>,
  cards:(p)=><S {...p}><rect x="7" y="4" width="12" height="16" rx="2.5"/><path d="M5 7v11a2 2 0 0 0 2 2h8"/></S>,
  image:(p)=><S {...p}><rect x="4" y="5" width="16" height="14" rx="2.5"/><circle cx="9" cy="10" r="1.5"/><path d="M20 16l-5-5-8 8"/></S>,
  copy:(p)=><S {...p}><rect x="8" y="8" width="11" height="11" rx="2"/><path d="M5 15V6a1 1 0 0 1 1-1h9"/></S>,
  chev:(p)=><S {...p}><path d="M9 6l6 6-6 6"/></S>,
  heart:(p)=><S {...p}><path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z"/></S>,
  mail:(p)=><S {...p}><rect x="3.5" y="5.5" width="17" height="13" rx="2.5"/><path d="M4 7l8 6 8-6"/></S>,
  brain:(p)=><S {...p}><circle cx="12" cy="12" r="8"/><path d="M12 8v4l2.5 2.5"/></S>,
};

/* ============ 阿禾 · living mascot ============ */
const MOOD_WORD = { listening:'在听', curious:'有点好奇', thinking:'在想', happy:'开心', shy:'有点害羞', sleeping:'睡着了' };
let __mid = 0;
function Mascot({ state = 'listening', size = 64, style }){
  const s = state;
  const idRef = useRef(null); if (!idRef.current) idRef.current = 'm' + (++__mid);
  const gb = idRef.current + 'b', gl = idRef.current + 'l';
  const eyesNormal = (
    <g className="look"><g className="eyes">
      <ellipse cx="39" cy="57" rx={s === 'curious' ? 4.2 : 3.6} ry={s === 'curious' ? 5.2 : 4.6} fill="#3A2C26"/>
      <ellipse cx="61" cy="57" rx="3.6" ry="4.6" fill="#3A2C26"/>
      <circle cx="40.3" cy="55.4" r="1.2" fill="#fff"/><circle cx="62.3" cy="55.4" r="1.2" fill="#fff"/>
    </g></g>
  );
  const eyes = s === 'happy'
    ? <g stroke="#3A2C26" strokeWidth="2.6" fill="none" strokeLinecap="round"><path d="M34.5 58 Q39 52.5 43.5 58"/><path d="M56.5 58 Q61 52.5 65.5 58"/></g>
    : (s === 'sleeping' || s === 'shy')
      ? <g stroke="#3A2C26" strokeWidth="2.4" fill="none" strokeLinecap="round"><path d={s === 'shy' ? 'M35 58 Q39 61.5 43 58' : 'M35 57 Q39 60 43 57'}/><path d={s === 'shy' ? 'M57 58 Q61 61.5 65 58' : 'M57 57 Q61 60 65 57'}/></g>
      : eyesNormal;
  const mouth = {
    listening:<path d="M46 66 Q50 69.5 54 66" stroke="#3A2C26" strokeWidth="2.2" fill="none" strokeLinecap="round"/>,
    curious:<ellipse cx="51" cy="67.5" rx="2.4" ry="2.8" fill="#3A2C26"/>,
    thinking:<path d="M46.5 67.5 L53.5 66.5" stroke="#3A2C26" strokeWidth="2.2" strokeLinecap="round"/>,
    happy:<path d="M44.5 65 Q50 73 55.5 65 Z" fill="#3A2C26"/>,
    shy:<path d="M46 67 Q48 65.5 50 67 Q52 68.5 54 67" stroke="#3A2C26" strokeWidth="2" fill="none" strokeLinecap="round"/>,
    sleeping:<ellipse cx="50" cy="67.5" rx="2" ry="1.6" fill="#3A2C26"/>,
  }[s] || null;
  const blush = s === 'shy' ? .85 : s === 'happy' ? .6 : .38;
  return (
    <span className={'mascot m-' + s} style={{ width:size, height:size, ...style }}>
      <svg viewBox="0 0 100 100">
        <defs>
          <radialGradient id={gb} cx="38%" cy="32%" r="75%">
            <stop offset="0%" stopColor="#FFF4EC"/><stop offset="45%" stopColor="#FBD3BF"/><stop offset="100%" stopColor="#EE9F82"/>
          </radialGradient>
          <linearGradient id={gl} x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stopColor="#C4D0AC"/><stop offset="100%" stopColor="#93A579"/></linearGradient>
        </defs>
        <ellipse className="shadow" cx="50" cy="93" rx="26" ry="4" fill="#B47A5E" opacity=".16"/>
        <g className="body">
          <g className="leaf">
            <path d="M50 26 C50 20 50 17 50 14" stroke="#93A579" strokeWidth="2.4" strokeLinecap="round" fill="none"/>
            <path d="M50 17 C43 9 35 11 33 15 C39 19 45 19 50 17 Z" fill={`url(#${gl})`}/>
            <path d="M50 15 C55 6 64 6 67 10 C62 15 56 16 50 15 Z" fill={`url(#${gl})`}/>
          </g>
          <path d="M50 24 C73 24 87 41 87 60 C87 79 71 90 50 90 C29 90 13 79 13 60 C13 41 27 24 50 24 Z" fill={`url(#${gb})`}/>
          <ellipse cx="36" cy="38" rx="12" ry="7" fill="#fff" opacity=".45" transform="rotate(-20 36 38)"/>
          <ellipse cx="29" cy="67" rx="6.5" ry="4" fill="#F08A74" opacity={blush}/>
          <ellipse cx="71" cy="67" rx="6.5" ry="4" fill="#F08A74" opacity={blush}/>
          {eyes}
          {mouth}
        </g>
        {s === 'thinking' && <g className="dots" fill="#E07E62"><circle cx="80" cy="22" r="2.6"/><circle cx="88" cy="15" r="2.1"/><circle cx="94" cy="8" r="1.6"/></g>}
        {s === 'happy' && <g fill="#F0A389"><path className="spark" d="M86 30 l2 5 5 2 -5 2 -2 5 -2 -5 -5 -2 5 -2z"/><path className="spark" style={{ animationDelay:'.4s' }} d="M14 26 l1.5 3.5 3.5 1.5 -3.5 1.5 -1.5 3.5 -1.5 -3.5 -3.5 -1.5 3.5 -1.5z"/></g>}
        {s === 'sleeping' && <g fill="#B8A79C" fontFamily="Instrument Serif, serif" fontStyle="italic"><text className="z" x="74" y="28" fontSize="14">z</text><text className="z" x="82" y="18" fontSize="11">z</text></g>}
        {s === 'curious' && <text x="78" y="26" fontSize="16" fill="#E07E62" fontFamily="Instrument Serif, serif" fontStyle="italic" opacity=".9">?</text>}
      </svg>
    </span>
  );
}
function Ahe({ s = 30, state = 'listening' }){ return <Mascot size={s} state={state}/>; }
/* ============ Profile ============ */
export const INTENTS = [
  { v:'先交个朋友', k:'friend', s:'不急，先看聊不聊得来' }, { v:'轻松约会', k:'date', s:'吃饭、看展，合适再说' },
  { v:'认真谈恋爱', k:'serious', s:'想找一个长期的人' }, { v:'以结婚为前提', k:'marry', s:'希望 1–2 年内有结果' },
  { v:'成年人的轻松关系', k:'casual', s:'彼此尊重，不谈承诺' }, { v:'还没想清楚', k:'unsure', s:'边认识边感受' },
];
export const MAXQ = 10;
const memOf = (ob) => (ob.log || []).filter(l => l.key !== 'photos');
export function buildProfile(ob, sum, edit){
  const a = ob.ans || {};
  const mem = memOf(ob);
  const s = sum || {
    headline: mem.length ? '慢热，但心里有数' : '阿禾还在认识你',
    about: mem.length ? `阿禾记得：${mem.slice(0, 3).map(m => String(m.a).replace(/^[^：]*：/, '')).join('，')}。` : '多聊几句，阿禾会更懂你。',
    traits: [],
  };
  return {
    name: a.name || '朋友', headline: s.headline, about: s.about,
    traits: (s.traits || []).map((label, i) => ({ label, w: i === 0 ? 3 : 2 })),
    intent: a.intent || '', seek: a.seek || '', gender: a.gender || '', city: a.city || '',
    ...(edit || {}),
  };
}

/* ============ Small components ============ */
function Toggle({ on, onChange }){ return <button className={'tg' + (on ? ' on' : '')} onClick={() => onChange(!on)} aria-pressed={!!on}/>; }
function Portrait({ p, size = 56, radius, w, h }){
  const [a, b, c] = p.tone;
  return (
    <div className="portrait" style={{ width: w || size, height: h || size, borderRadius: radius ?? size / 2, fontSize: (h || size) * 0.34,
      background:`radial-gradient(120% 90% at 18% 12%, ${a} 0%, transparent 62%), radial-gradient(90% 90% at 88% 85%, ${c} 0%, transparent 60%), ${b}` }}>
      <svg viewBox="0 0 100 100" preserveAspectRatio="xMidYMid slice"><circle cx="50" cy="40" r="15" fill="#fff" opacity=".13"/><path d="M20 100c2-24 15-36 30-36s28 12 30 36z" fill="#fff" opacity=".11"/></svg>
      <span>{p.name[0]}</span>
    </div>
  );
}
function Typing(){ return <div className="typing"><i/><i/><i/></div>; }

/* ============ 阿禾 · conversation (server runs QUESTIONING_SKILL) ============ */
const withTimeout = (p, ms) => Promise.race([p, new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), ms))]);
const LOCAL_OPENER = { messages:['嗨，我是阿禾。','先不问名字。你现在在哪儿，在干嘛？'], suggestions:['躺着刷手机','在回家路上','刚忙完'], placeholder:'随便说说…', mood:'curious' };
const NET_FAIL = { messages:['我在。刚才网络有点卡，你可以再说一遍吗？'], mood:'shy', suggestions:[] };

export function AheTab({ ob, setOb, prefs, setPrefs, onSummary, onGoMe, onGoChat, visible, photos, setPhotos, saveNow, onMood }){
  const obRef = useRef(ob); obRef.current = ob;
  const upd = (fn) => { const n = fn(obRef.current); obRef.current = n; setOb(n); };
  const push = (m) => upd(o => ({ ...o, msgs:[...o.msgs, { id:uid(), ...m }] }));
  const [typing, setTyping] = useState(false);
  const [busy, setBusy] = useState(false);
  const [input, setInput] = useState('');
  const [focus, setFocus] = useState(false);
  const [drawer, setDrawer] = useState(false);
  const [flash, setFlash] = useState(null);
  const scRef = useRef(null);
  const alive = useRef(true);
  useEffect(() => () => { alive.current = false; }, []);

  const mood = flash || (typing ? 'thinking' : focus && input ? 'listening' : ob.mood || 'curious');
  useEffect(() => { onMood && onMood(mood); }, [mood]);

  async function bubbles(lines){
    for (const l of lines) {
      if (!alive.current) return;
      setTyping(true); await sleep(380 + Math.min(1100, l.length * 22)); setTyping(false);
      push({ kind:'ai', text:l }); await sleep(120);
    }
  }
  async function render(res){
    await bubbles((res.messages || []).map(clean).filter(Boolean).slice(0, 3));
    if (res.guess && res.guess.text) { await sleep(250); push({ kind:'guess', gid:res.guess.id, text:clean(res.guess.text), resp:null }); }
    const pr = res.profile || {};
    const mem = (res.memory || []).map(x => clean(String(x))).filter(Boolean).slice(0, 3);
    upd(o => {
      const ans = { ...o.ans };
      ['name','gender','seek','intent'].forEach(k => { if (pr[k]) ans[k] = String(pr[k]); });
      if (pr.intent) { const it = INTENTS.find(x => x.v === pr.intent); if (it) ans.intentK = it.k; }
      return { ...o, ans,
        mood: res.mood || 'listening',
        suggestions: (res.suggestions || []).map(String).filter(Boolean).slice(0, 3),
        placeholder: res.placeholder || (o.firstDone ? '想说什么都可以…' : '随便说说…'),
        guessStat: res.guessStat || o.guessStat,
        log: [...o.log, ...mem.map(a => ({ key:'m' + uid(), cat: o.firstDone ? '聊天时提到' : '初次见面', q:'阿禾记下的', a }))],
        memNew: (o.memNew || 0) + mem.length,
      };
    });
  }

  useEffect(() => { (async () => {
    if (obRef.current.started) return;
    upd(x => ({ ...x, started:true }));
    setBusy(true);
    await sleep(800);
    let r = null;
    try { r = await withTimeout(api('/api/ahe/open', {}), 15000); } catch (e) { r = LOCAL_OPENER; }
    await render(r);
    setBusy(false);
  })(); }, []);
  useEffect(() => { const el = scRef.current; if (el) setTimeout(() => el.scrollTo({ top:el.scrollHeight, behavior:'smooth' }), 40); }, [ob.msgs.length, typing, visible]);

  async function send(t, opts = {}){
    t = (t || '').trim(); if (!t || (busy && !opts.force)) return;
    setInput(''); setBusy(true);
    if (!opts.fromGuess) upd(x => ({ ...x, msgs:x.msgs.map(y => y.kind === 'guess' && !y.resp ? { ...y, resp:'skip' } : y) }));
    push({ kind:'me', text:t });
    upd(o => ({ ...o, suggestions:[] }));
    setTyping(true);
    let res = null;
    try { res = await withTimeout(api('/api/ahe/turn', { text:t }), 35000); } catch (e) { res = null; }
    setTyping(false);
    if (!res || !(res.messages || []).length && !res.guess) res = NET_FAIL;
    await render(res);
    if (res.just_done && !obRef.current.firstDone) {
      const g = res.guessStat || obRef.current.guessStat || { hit:0, total:0 };
      upd(x => ({ ...x, firstDone:true, mood:'happy', placeholder:'想说什么都可以…' }));
      await sleep(400);
      push({ kind:'done', text:`初次见面${g.total ? ` · 阿禾猜中 ${g.hit}/${g.total}` : ''}` });
      await sleep(600);
      push({ kind:'photo' });
    }
    setBusy(false);
  }
  function answerGuess(m, yes){
    if (m.resp || busy) return;
    upd(x => ({ ...x, msgs:x.msgs.map(y => y.id === m.id ? { ...y, resp: yes ? 'yes' : 'no' } : y),
      guessStat:{ hit:(x.guessStat.hit || 0) + (yes ? 1 : 0), total:(x.guessStat.total || 0) + 1 },
      log:[...x.log, { key:'g' + uid(), cat:'阿禾记下的', q:'阿禾的猜测', a:(yes ? '猜对了：' : '不太对：') + m.text.replace(/^我猜，?/, '').slice(0, 30) }] }));
    if (m.gid) api('/api/ahe/guess/' + m.gid, { resp: yes ? 'yes' : 'no' }).then(r => r && r.guessStat && upd(x => ({ ...x, guessStat:r.guessStat }))).catch(() => {});
    if (yes) { setFlash('happy'); setTimeout(() => setFlash(null), 2600); }
    else { setFlash('shy'); setTimeout(() => setFlash(null), 1800); }
    send(yes ? '猜对了' : '不太对', { fromGuess:true });
  }
  async function photoDone(mid, saved){
    setBusy(true);
    upd(x => ({ ...x, msgs:x.msgs.map(m => m.id === mid ? { ...m, done:true } : m) }));
    const count = photos.length;
    push({ kind:'me', text: saved ? `放好了 ${count} 张` : '以后再说' });
    upd(x => ({ ...x, log:[...x.log.filter(l => l.key !== 'photos'), { key:'photos', cat:'初次见面', q:'照片', a: saved ? `${count} 张 · 人工审核中` : '暂未上传' }] }));
    await bubbles([saved ? '收到。现在只有审核同事能看到。等你们互相愿意认识，对方才会看到。' : '没关系，想放的时候在「我」里随时可以加。']);
    setTyping(true);
    let s = null;
    try { await saveNow(obRef.current); s = (await withTimeout(api('/api/ahe/summary', {}), 25000)).summary; } catch (e) { await sleep(800); }
    setTyping(false);
    const sum = s && s.headline ? { headline:clean(s.headline), about:clean(s.about || ''), traits:(s.traits || []).slice(0, 4).map(String) } : null;
    if (sum) onSummary(sum);
    push({ kind:'reveal', s:sum });
    await sleep(500);
    await bubbles(['有合适的人，我会写成一封信放在「聊天」里，也会发邮件告诉你。']);
    upd(x => ({ ...x, mood:'listening' }));
    setBusy(false);
  }

  const lastKind = ob.msgs.length ? ob.msgs[ob.msgs.length - 1].kind : '';
  const pendingGuess = ob.msgs.some(m => m.kind === 'guess' && !m.resp);
  const photoOpen = ob.msgs.some(m => m.kind === 'photo' && !m.done);
  const sugg = !busy && !typing && lastKind !== 'me' && !pendingGuess ? (ob.suggestions || []) : [];
  const starters = ob.firstDone && !busy && !typing && lastKind !== 'me' && !sugg.length && !photoOpen ? ['今天有点累','有件事想说说','睡不着'] : [];

  return (
    <div className="screen ahe-screen" style={{ display:visible ? 'flex' : 'none' }}>
      <div className="safe"/>
      <div className="ahehead">
        <Mascot state={mood} size={40}/>
        <div style={{ flex:1, lineHeight:1.3 }}>
          <div className="nm">阿禾</div>
          <div className="st"><i/>{MOOD_WORD[mood] || '在这儿'}</div>
        </div>
        <button className="iconbtn" style={{ position:'relative' }} onClick={() => { setDrawer(true); upd(x => ({ ...x, memNew:0 })); }} title="隐私与记忆" aria-label="隐私与记忆">
          <I.lock s={18}/>{ob.memNew > 0 && <span className="memdot"/>}
        </button>
      </div>
      <div className="scroll" ref={scRef}>
        <div className="hero">
          <Mascot state={mood} size={112}/>
          <div className="cap"><I.lock s={12}/>说心里话的地方 · 只有你能看到</div>
        </div>
        <div className="msgs">
          {ob.msgs.map(m => {
            if (m.kind === 'done') return <div key={m.id} className="donepill pop"><I.check s={13} w={2.2}/>{m.text}</div>;
            if (m.kind === 'guess') return (
              <div key={m.id} className="guess pop">
                <div className="orb" style={{ width:120, height:120, right:-40, bottom:-50, background:'#F7B79E', opacity:.45 }}/>
                <div className="lab" style={{ position:'relative' }}><I.spark s={13}/>阿禾猜</div>
                <p style={{ position:'relative' }}>{m.text}</p>
                {!m.resp ? (
                  <div className="acts" style={{ position:'relative' }}>
                    <button className="yes" onClick={() => answerGuess(m, true)}>猜对了</button>
                    <button onClick={() => answerGuess(m, false)}>不太对</button>
                  </div>
                ) : m.resp !== 'skip' ? <div className={'res' + (m.resp === 'yes' ? '' : ' no')} style={{ position:'relative' }}>{m.resp === 'yes' ? <><I.check s={12} w={2.4}/>被猜中了</> : '没猜中'}</div> : null}
              </div>
            );
            if (m.kind === 'photo') return <PhotoCard key={m.id} m={m} photos={photos} setPhotos={setPhotos} onDone={(s) => photoDone(m.id, s)}/>;
            if (m.kind === 'reveal') return <RevealCard key={m.id} ob={ob} s={m.s} onGoMe={onGoMe} onGoChat={onGoChat}/>;
            if (m.kind === 'me') return <div key={m.id} className="me-line pop">{m.text}</div>;
            if (m.kind === 'ai') return <div key={m.id} className="ai-line rise">{m.text}</div>;
            return null;
          })}
          {typing && <Typing/>}
        </div>
      </div>
      <div className="dock">
        {(sugg.length > 0 || starters.length > 0) && (
          <div className="suggest">
            {sugg.map((s, i) => <button key={s + i} style={{ animationDelay:i * 50 + 'ms' }} onClick={() => send(s)}>{s}</button>)}
            {starters.map((s, i) => <button key={s} style={{ animationDelay:i * 50 + 'ms' }} onClick={() => send(s)}>{s}</button>)}
          </div>
        )}
        <div className={'composer glass' + (focus ? ' focus' : '')}>
          <textarea rows={1} value={input} placeholder={ob.placeholder || '随便说说…'} maxLength={1000}
            onFocus={() => setFocus(true)} onBlur={() => setFocus(false)} onChange={e => setInput(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) { e.preventDefault(); send(input); } }}/>
          <button className="sendbtn" disabled={!input.trim() || busy} onClick={() => send(input)} aria-label="发送"><I.send s={18}/></button>
        </div>
      </div>
      {drawer && <Memory ob={ob} onForget={(key) => upd(x => ({ ...x, log:x.log.filter(l => l.key !== key) }))} onClose={() => setDrawer(false)}/>}
    </div>
  );
}

function RevealCard({ ob, s, onGoMe, onGoChat }){
  const pf = buildProfile(ob, s);
  return (
    <div className="revealcard pop">
      <div className="orb" style={{ width:200, height:200, right:-80, top:-90, background:'#F7B79E', opacity:.5 }}/>
      <div style={{ position:'relative' }}>
        <div className="row gap8"><Mascot state="happy" size={34}/><span className="eyebrow">阿禾眼中的你</span></div>
        <div className="title" style={{ marginTop:12 }}>{pf.headline}</div>
        <p style={{ marginTop:8, fontSize:14.5, color:'var(--ink2)', lineHeight:1.7 }}>{pf.about}</p>
        {pf.traits.length > 0 && <div className="tags" style={{ marginTop:12 }}>{pf.traits.map((t, i) => <span key={i} className="chip">{t.label}</span>)}</div>}
        <div className="row gap8" style={{ marginTop:18 }}>
          <button className="btn sm" style={{ flex:1 }} onClick={onGoMe}>看完整的</button>
          <button className="btn ghost sm" style={{ flex:1 }} onClick={onGoChat}><I.mail s={15}/>去看看聊天</button>
        </div>
      </div>
    </div>
  );
}

export function PhotoSlots({ photos, setPhotos }){
  const [busy, setBusy] = useState(false);
  const add = async (file) => { if (!file) return; setBusy(true); try { const r = await uploadPhoto(file); setPhotos(r.photos); } catch (e) { alert('上传没成功，换一张试试'); } setBusy(false); };
  const rm = async (id) => { try { const r = await api('/api/me/photos/' + id, null, 'DELETE'); setPhotos(r.photos); } catch (e) {} };
  return (
    <div className="slots">
      {[0, 1, 2].map(i => (
        <div className="slot" key={i}>
          {photos[i] ? (<><img src={photoUrl(photos[i])} alt=""/><button className="rm" onClick={() => rm(photos[i])} aria-label="删除"><I.x s={13}/></button></>)
            : i === photos.length && busy ? <div className="spin" style={{ width:24, height:24 }}/>
            : (<><I.plus s={22}/><input type="file" accept="image/*" onChange={e => { add(e.target.files[0]); e.target.value = ''; }}/></>)}
        </div>
      ))}
    </div>
  );
}
function PhotoCard({ m, photos, setPhotos, onDone }){
  if (m.done) return null;
  return (
    <div className="photocard pop">
      <div className="row gap8"><Mascot state="shy" size={32}/><div className="h3">放一两张照片？</div></div>
      <div className="tiny" style={{ marginTop:4 }}>日常的就好。这里每个人都是真人。</div>
      <PhotoSlots photos={photos} setPhotos={setPhotos}/>
      <div className="plist">
        <div><I.check s={14} w={2}/><span>只有<b style={{ fontWeight:500 }}>审核同事</b>和<b style={{ fontWeight:500 }}>你们互相愿意认识之后的那个人</b>能看到</span></div>
        <div><I.check s={14} w={2}/><span>审核只确认是否本人、照片是否清晰</span></div>
        <div><I.check s={14} w={2}/><span>不进入任何列表，没人能搜到，随时可删</span></div>
      </div>
      <div className="row gap8" style={{ marginTop:14 }}>
        <button className="btn ghost sm" style={{ flex:1 }} onClick={() => onDone(false)}>以后再说</button>
        <button className="btn accent sm" style={{ flex:1 }} disabled={!photos.length} onClick={() => onDone(true)}>放好了</button>
      </div>
    </div>
  );
}

export function Memory({ ob, onForget, onClose }){
  const g = ob.guessStat || { hit:0, total:0 };
  const log = memOf(ob);
  const cats = ['初次见面','阿禾记下的','聊天时提到'];
  return (
    <div className="overlay" onClick={onClose}>
      <div className="sheet" onClick={e => e.stopPropagation()}>
        <div className="grab"/>
        <div className="pad" style={{ paddingTop:6, paddingBottom:12 }}>
          <div className="row gap12"><Mascot state="listening" size={46}/><div><div className="title" style={{ fontSize:21 }}>隐私与记忆</div>{g.total > 0 && <div className="tiny">猜中你 {g.hit}/{g.total} 次</div>}</div></div>
          <div className="plist" style={{ marginTop:14 }}>
            <div><I.lock s={14} w={2}/><span>你和阿禾的聊天只有你能看到，不会给任何人。</span></div>
            <div><I.check s={14} w={2}/><span>阿禾记下的事，只用来更懂你、为你挑人。</span></div>
          </div>
        </div>
        <div className="scroll pad" style={{ paddingBottom:26 }}>
          <div className="eyebrow" style={{ margin:'8px 0 8px' }}>阿禾记得的事 · 删掉就真的忘了</div>
          {!log.length && <div style={{ textAlign:'center', padding:'20px 0' }}><Mascot state="sleeping" size={60}/><p className="tiny" style={{ marginTop:6 }}>还没有记下什么</p></div>}
          {cats.map(c => {
            const items = log.filter(l => (l.cat || '阿禾记下的') === c); if (!items.length) return null;
            return (
              <div key={c} style={{ marginTop:10 }}>
                <div className="tiny" style={{ marginBottom:6 }}>{c}</div>
                {items.slice().reverse().map(l => (
                  <div key={l.key} className="memitem">
                    <div>{l.q && !['关于你','阿禾记下的','聊天时提到',c].includes(l.q) && <div className="q">{l.q}</div>}<div className="a">{l.a}</div></div>
                    <button className="tiny" style={{ flex:'none' }} onClick={() => onForget(l.key)}>忘掉</button>
                  </div>
                ))}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
