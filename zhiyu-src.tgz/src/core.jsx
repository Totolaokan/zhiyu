import React, { useState, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { api, uploadPhoto, photoUrl } from './api.js';
export { I, S, Typing, Ahe, Mascot, MOOD_WORD, Toggle, Portrait, clean, sleep, uid };

const sleep = (ms) => new Promise(r => setTimeout(r, ms));
const uid = () => Math.random().toString(36).slice(2, 9);
const clean = (t) => (t || '').trim().replace(/^["“「]+|["”」]+$/g, '');

/* ============ Icons ============ */
const S = (p) => <svg width={p.s||20} height={p.s||20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={p.w||1.7} strokeLinecap="round" strokeLinejoin="round">{p.children}</svg>;
const I = {
  lock:(p)=><S {...p}><rect x="5" y="11" width="14" height="9" rx="2.5"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></S>,
  sprout:(p)=><S {...p}><path d="M12 20v-8"/><path d="M12 12c0-3.5-2.5-6-7-6 0 4 2.5 6 7 6z"/><path d="M12 14c0-3 2-5.5 7-5.5 0 3.5-2.5 5.5-7 5.5z"/></S>,
  sun:(p)=><S {...p}><circle cx="12" cy="12" r="4"/><path d="M12 3v2M12 19v2M3 12h2M19 12h2M5.6 5.6l1.4 1.4M17 17l1.4 1.4M5.6 18.4L7 17M17 7l1.4-1.4"/></S>,
  chat:(p)=><S {...p}><path d="M20 11.5a7.5 7.5 0 0 1-11 6.6L4 19.5l1.3-4.3A7.5 7.5 0 1 1 20 11.5z"/></S>,
  leaf:(p)=><S {...p}><path d="M5 19c0-8 5-13 14-14-1 9-6 14-14 14z"/><path d="M5 19l7-7"/></S>,
  user:(p)=><S {...p}><circle cx="12" cy="8.5" r="3.5"/><path d="M5 20c1-4 4-6 7-6s6 2 7 6"/></S>,
  spark:(p)=><S {...p}><path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/></S>,
  send:(p)=><S {...p}><path d="M12 19V5M6 11l6-6 6 6"/></S>,
  plus:(p)=><S {...p}><path d="M12 5v14M5 12h14"/></S>,
  back:(p)=><S {...p}><path d="M15 5l-7 7 7 7"/></S>,
  x:(p)=><S {...p}><path d="M6 6l12 12M18 6L6 18"/></S>,
  check:(p)=><S {...p}><path d="M5 12.5l4.5 4.5L19 7.5"/></S>,
  eyeoff:(p)=><S {...p}><path d="M3 3l18 18"/><path d="M10.6 6.2A9.6 9.6 0 0 1 12 6c5 0 8.5 4.5 9 6-.3.9-1.4 2.6-3.1 4M6.3 7.7C4.4 9 3.3 10.8 3 12c.5 1.5 4 6 9 6 1.4 0 2.6-.3 3.7-.8"/></S>,
  shield:(p)=><S {...p}><path d="M12 3l7 3v5c0 5-3 8-7 10-4-2-7-5-7-10V6z"/><path d="M9 12l2 2 4-4"/></S>,
  moon:(p)=><S {...p}><path d="M19 14.5A7.5 7.5 0 0 1 9.5 5a7.5 7.5 0 1 0 9.5 9.5z"/></S>,
  pen:(p)=><S {...p}><path d="M4 20h4L19 9l-4-4L4 16z"/></S>,
  dice:(p)=><S {...p}><rect x="4" y="4" width="16" height="16" rx="4"/><circle cx="9" cy="9" r=".8" fill="currentColor"/><circle cx="15" cy="15" r=".8" fill="currentColor"/><circle cx="15" cy="9" r=".8" fill="currentColor"/><circle cx="9" cy="15" r=".8" fill="currentColor"/></S>,
  cards:(p)=><S {...p}><rect x="7" y="4" width="12" height="16" rx="2.5"/><path d="M5 7v11a2 2 0 0 0 2 2h8"/></S>,
  image:(p)=><S {...p}><rect x="4" y="5" width="16" height="14" rx="2.5"/><circle cx="9" cy="10" r="1.5"/><path d="M20 16l-5-5-8 8"/></S>,
  copy:(p)=><S {...p}><rect x="8" y="8" width="11" height="11" rx="2"/><path d="M5 15V6a1 1 0 0 1 1-1h9"/></S>,
  chev:(p)=><S {...p}><path d="M9 6l6 6-6 6"/></S>,
  heart:(p)=><S {...p}><path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z"/></S>,
  mail:(p)=><S {...p}><rect x="3.5" y="5.5" width="17" height="13" rx="2.5"/><path d="M4 7l8 6 8-6"/></S>,
  brain:(p)=><S {...p}><circle cx="12" cy="12" r="8"/><path d="M12 8v4l2.5 2.5"/></S>,
};

/* ============ 阿禾 · a handmade line character (two colours: ink + forest) ============ */
const MOOD_WORD = { listening:'在听', curious:'好奇', thinking:'在写', happy:'笑了', shy:'不好意思', sleeping:'睡了' };
let __mid = 0;
function Mascot({ state = 'listening', size = 56, style }){
  const s = state;
  const idRef = useRef(null); if (!idRef.current) idRef.current = 'ah' + (++__mid);
  const f = idRef.current;
  const INK = '#3A3A3A', LEAF = '#497749';
  const eyes = s === 'happy'
    ? <g className="eyes"><path d="M37 58 q4 -5 8 0" /><path d="M55 58 q4 -5 8 0"/></g>
    : (s === 'shy' || s === 'sleeping')
      ? <g><path d="M37 58 q4 4 8 0"/><path d="M55 58 q4 4 8 0"/></g>
      : <g className="eyes" transform={s === 'thinking' ? 'translate(-2 -2)' : s === 'curious' ? 'translate(1 0)' : ''}>
          <circle cx="41" cy="57" r="2.3" fill={INK} stroke="none"/><circle cx="59" cy="57" r="2.3" fill={INK} stroke="none"/>
        </g>;
  const mouth = { happy:<path d="M45 66 q5 5 10 0"/>, shy:<path d="M47 67 q3 -1.5 6 0"/>, sleeping:<circle cx="50" cy="67" r="1.4" fill={INK} stroke="none"/>, thinking:<path d="M46 67 h7"/>, curious:<circle cx="51" cy="67" r="1.8"/> }[s] || <path d="M46 66 q4 3 8 0"/>;
  return (
    <span className={'mascot m-' + s} style={{ width:size, height:size, ...style }}>
      <svg viewBox="0 0 100 100">
        <defs>
          <filter id={f} x="-10%" y="-10%" width="120%" height="120%">
            <feTurbulence type="fractalNoise" baseFrequency="0.035" numOctaves="2" seed="7"/>
            <feDisplacementMap in="SourceGraphic" scale="2.2"/>
          </filter>
        </defs>
        <g filter={`url(#${f})`} fill="none" stroke={INK} strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round">
          <g className="leaf">
            <path d="M50 32 C50 26 50.5 22 50 17"/>
            <path d="M50 22 C44 13 35 15 33.5 19 C39 23.5 45 23.5 50 22 Z" fill={LEAF} stroke={LEAF} strokeWidth="1.6"/>
            <path d="M50 19 C55 10 64 10 66.5 14 C61.5 19 56 20 50 19 Z" fill="none" stroke={LEAF} strokeWidth="2"/>
          </g>
          {/* body: a slightly lopsided grain, drawn by hand */}
          <path d="M49 31 C66 30.5 79 44 78.5 60 C78 77 66 87 50.5 87.5 C34 88 21.5 77 21.5 60.5 C21.5 44 33 31.5 49 31 Z" fill="#FFFEFB"/>
          {eyes}
          {mouth}
          {s === 'shy' && <g stroke="#C75943" strokeWidth="1.6" opacity=".75"><path d="M29 65 l3 -3 M33 66 l3 -3"/><path d="M64 66 l3 -3 M68 65 l3 -3"/></g>}
          {s === 'thinking' && <g className="pen"><path d="M73 78 L86 64" /><path d="M86 64 l3 -3" stroke={LEAF}/></g>}
          {s === 'curious' && <path d="M80 30 q4 -6 8 -1 q2 4 -3 6 l0 3" strokeWidth="2"/>}
          {s === 'happy' && <g stroke={LEAF} strokeWidth="2"><path d="M18 40 l-5 -3"/><path d="M82 40 l5 -3"/></g>}
        </g>
        {s === 'sleeping' && <g fill="#AF8F6E" fontFamily="Bodoni Moda, Didot, serif" fontStyle="italic"><text className="z" x="76" y="34" fontSize="13">z</text><text className="z" x="83" y="24" fontSize="10">z</text></g>}
        <path d="M30 93 C42 91.5 58 91.5 70 93" stroke="#AF8F6E" strokeWidth="1.4" strokeLinecap="round" fill="none" opacity=".5"/>
      </svg>
    </span>
  );
}
function Ahe({ s = 30, state = 'listening' }){ return <Mascot size={s} state={state}/>; }
/* ============ Profile ============ */
export const INTENTS = [
  { v:'先交个朋友', k:'friend', s:'不急，先看聊不聊得来' }, { v:'轻松约会', k:'date', s:'吃饭、看展，合适再说' },
  { v:'认真谈恋爱', k:'serious', s:'想找一个长期的人' }, { v:'以结婚为前提', k:'marry', s:'希望 1–2 年内有结果' },
  { v:'成年人的轻松关系', k:'casual', s:'彼此尊重，不谈承诺' }, { v:'还没想清楚', k:'unsure', s:'边认识边感受' },
];
export const MAXQ = 10;
const memOf = (ob) => (ob.log || []).filter(l => l.key !== 'photos');
export function buildProfile(ob, sum, edit, seeds){
  const a = ob.ans || {};
  const mem = memOf(ob);
  seeds = seeds || [];
  const fd = (t) => (seeds.find(x => x.type === t) || {}).name;
  const s = sum || (seeds.length || mem.length ? {
    headline: fd('place') ? '有几家只属于自己的店' : '慢热，但心里有数',
    about: seeds.length ? [fd('place') && `常去${fd('place')}`, fd('food') && `爱吃${fd('food')}`, fd('thing') && `身上总带着${fd('thing')}`].filter(Boolean).join('，') + '。'
      : `阿禾记得：${mem.slice(0, 3).map(m => String(m.a).replace(/^[^：]*：/, '')).join('，')}。`,
    traits: [fd('place') && '有自己的小据点', fd('food') && '会吃', fd('thing') && '念旧'].filter(Boolean),
  } : { headline:'阿禾还在认识你', about:'多聊几句，阿禾会更懂你。', traits:[] });
  return {
    name: a.name || '', headline: s.headline, about: s.about,
    traits: (s.traits || []).map((label, i) => ({ label, w: i === 0 ? 3 : 2 })),
    intent: a.intent || '', seek: a.seek || '', gender: a.gender || '', city: a.city || '',
    ...(edit || {}),
  };
}

/* ============ 生活碎片 (life seeds) ============ */
export const SEED_LABEL = { place:'地方', food:'吃的', thing:'东西', ritual:'小习惯', story:'故事' };
export function SeedIcon({ type, s = 16 }){
  if (type === 'place') return <S s={s}><path d="M12 21s-6-5.5-6-11a6 6 0 0 1 12 0c0 5.5-6 11-6 11z"/><circle cx="12" cy="10" r="2.2"/></S>;
  if (type === 'food') return <S s={s}><path d="M4 11h16a8 8 0 0 1-16 0z"/><path d="M9 7c0-1.5 1-1.5 1-3M13 7c0-1.5 1-1.5 1-3"/></S>;
  if (type === 'thing') return <S s={s}><rect x="5" y="7" width="14" height="12" rx="3"/><path d="M9 7V5h6v2"/></S>;
  if (type === 'ritual') return <S s={s}><circle cx="12" cy="12" r="8"/><path d="M12 8v4l3 2"/></S>;
  return <S s={s}><path d="M5 5h14v11H9l-4 4z"/></S>;
}
export const seedWhen = (at) => { const d = new Date(at || Date.now()); return `${d.getMonth() + 1}月${d.getDate()}日聊起`; };
export function SeedRow({ sd, onForget }){
  return (
    <div className="memitem">
      <div className="row gap12" style={{ minWidth:0 }}>
        <span className="seedic"><SeedIcon type={sd.type}/></span>
        <div style={{ minWidth:0 }}><div className="a">{sd.name}</div>{sd.detail && sd.detail !== sd.name && <div className="q">{sd.detail}</div>}</div>
      </div>
      {onForget && <button className="tiny" style={{ flex:'none' }} onClick={onForget}>删去</button>}
    </div>
  );
}
export function SeedCard({ sd, onForget }){
  return (
    <div className="seedcard rise">
      <div className="obj"><SeedIcon type={sd.type} s={34}/>{sd.where && <span className="add">{sd.where}</span>}</div>
      <div className="body">
        <div className="nm">{sd.name}</div>
        {sd.detail && sd.detail !== sd.name && <div className="qt">「{sd.detail}」</div>}
        <div className="cap"><span>{SEED_LABEL[sd.type] || '故事'} · {seedWhen(sd.at)}</span>{onForget && <button onClick={onForget}>删去</button>}</div>
      </div>
    </div>
  );
}
export function DateIdea({ idea }){
  if (!idea) return null;
  return (
    <div className="dateidea rise">
      <div className="stamp">知遇<br/>小笺</div>
      <div className="lab">阿禾的约会小提案</div>
      <div className="ttl">{idea.title}</div>
      <p>{idea.text}</p>
      <div className="sig">—— 阿禾</div>
    </div>
  );
}
export function letterDate(){ const d = new Date(); const wk = ['日','一','二','三','四','五','六'][d.getDay()]; const h = d.getHours(); const part = h < 5 ? '深夜' : h < 11 ? '早上' : h < 14 ? '中午' : h < 18 ? '下午' : h < 23 ? '晚上' : '深夜'; return `${d.getFullYear()}.${d.getMonth() + 1}.${d.getDate()} · 星期${wk} · ${part}`; }

/* ============ Small components ============ */
function Toggle({ on, onChange }){ return <button className={'tg' + (on ? ' on' : '')} onClick={() => onChange(!on)} aria-pressed={!!on}/>; }
function Portrait({ p, size = 56, radius, w, h }){
  const [a, b, c] = p.tone;
  return (
    <div className="portrait" style={{ width: w || size, height: h || size, borderRadius: radius ?? size / 2, fontSize: (h || size) * 0.34,
      background:`radial-gradient(120% 90% at 18% 12%, ${a} 0%, transparent 62%), radial-gradient(90% 90% at 88% 85%, ${c} 0%, transparent 60%), ${b}` }}>
      <svg viewBox="0 0 100 100" preserveAspectRatio="xMidYMid slice"><circle cx="50" cy="40" r="15" fill="#fff" opacity=".13"/><path d="M20 100c2-24 15-36 30-36s28 12 30 36z" fill="#fff" opacity=".11"/></svg>
      <span>{p.name[0]}</span>
    </div>
  );
}
function Typing({ who = '阿禾在写' }){ return <div className="typing">{who}<i/><i/><i/></div>; }

/* ============ 阿禾 · conversation (server runs 聊天之道 v2) ============ */
const withTimeout = (p, ms) => Promise.race([p, new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), ms))]);
const LOCAL_OPENER = { messages:['嗨，我是阿禾。','先聊点轻松的：你家附近，有没有一家你常去的小店？'], suggestions:[], placeholder:'说说那家店…', mood:'curious' };
const NET_FAIL = { messages:['我在。刚才信号有点慢，你可以再说一遍吗？'], mood:'shy', suggestions:[] };

export function AheTab({ ob, setOb, prefs, setPrefs, onSummary, onGoMe, onGoChat, visible, photos, setPhotos, saveNow, onMood, seeds, setSeeds }){
  const obRef = useRef(ob); obRef.current = ob;
  const upd = (fn) => { const n = fn(obRef.current); obRef.current = n; setOb(n); };
  const push = (m) => upd(o => ({ ...o, msgs:[...o.msgs, { id:uid(), ...m }] }));
  const [typing, setTyping] = useState(false);
  const [busy, setBusy] = useState(false);
  const [input, setInput] = useState('');
  const [focus, setFocus] = useState(false);
  const [drawer, setDrawer] = useState(false);
  const [flash, setFlash] = useState(null);
  const scRef = useRef(null);
  const alive = useRef(true);
  useEffect(() => () => { alive.current = false; }, []);

  const mood = flash || (typing ? 'thinking' : focus && input ? 'listening' : ob.mood || 'curious');
  useEffect(() => { onMood && onMood(mood); }, [mood]);

  async function bubbles(lines){
    for (const l of lines) {
      if (!alive.current) return;
      setTyping(true); await sleep(420 + Math.min(1200, l.length * 24)); setTyping(false);
      push({ kind:'ai', text:l }); await sleep(140);
    }
  }
  async function render(res){
    await bubbles((res.messages || []).map(clean).filter(Boolean).slice(0, 3));
    if (res.guess && res.guess.text) { await sleep(250); push({ kind:'guess', gid:res.guess.id, text:clean(res.guess.text), resp:null }); }
    const pr = res.profile || {};
    const mem = (res.memory || []).map(x => clean(String(x))).filter(Boolean).slice(0, 3);
    const ns = (res.seeds || []).filter(x => x && x.id);
    if (ns.length) setSeeds(prev => [...prev, ...ns.filter(x => !prev.some(y => y.id === x.id))]);
    upd(o => {
      const ans = { ...o.ans };
      ['name','gender','seek','intent'].forEach(k => { if (pr[k]) ans[k] = String(pr[k]); });
      if (pr.intent) { const it = INTENTS.find(x => x.v === pr.intent); if (it) ans.intentK = it.k; }
      return { ...o, ans,
        mood: res.mood || 'listening',
        suggestions: (res.suggestions || []).map(String).filter(Boolean).slice(0, 3),
        placeholder: res.placeholder || (o.firstDone ? '想说什么都可以…' : '想说什么，写在这里…'),
        guessStat: res.guessStat || o.guessStat,
        log: [...o.log, ...mem.map(a => ({ key:'m' + uid(), cat: o.firstDone ? '聊天时提到' : '初次见面', q:'阿禾记下的', a }))],
        memNew: (o.memNew || 0) + mem.length + ns.length,
      };
    });
  }

  useEffect(() => { (async () => {
    if (obRef.current.started) return;
    upd(x => ({ ...x, started:true }));
    setBusy(true);
    await sleep(900);
    let r = null;
    try { r = await withTimeout(api('/api/ahe/open', {}), 15000); } catch (e) { r = LOCAL_OPENER; }
    await render(r);
    setBusy(false);
  })(); }, []);
  useEffect(() => { const el = scRef.current; if (el) setTimeout(() => el.scrollTo({ top:el.scrollHeight, behavior:'smooth' }), 40); }, [ob.msgs.length, typing, visible]);

  async function send(t, opts = {}){
    t = (t || '').trim(); if (!t || (busy && !opts.force)) return;
    setInput(''); setBusy(true);
    if (!opts.fromGuess) upd(x => ({ ...x, msgs:x.msgs.map(y => y.kind === 'guess' && !y.resp ? { ...y, resp:'skip' } : y) }));
    push({ kind:'me', text:t });
    upd(o => ({ ...o, suggestions:[] }));
    setTyping(true);
    let res = null;
    try { res = await withTimeout(api('/api/ahe/turn', { text:t }), 45000); } catch (e) { res = null; }
    setTyping(false);
    if (!res || !(res.messages || []).length && !res.guess) res = NET_FAIL;
    await render(res);
    if (res.just_done && !obRef.current.firstDone) {
      const g = res.guessStat || obRef.current.guessStat || { hit:0, total:0 };
      upd(x => ({ ...x, firstDone:true, mood:'happy', placeholder:'想说什么都可以…' }));
      await sleep(400);
      push({ kind:'done', text:`初次见面${g.total ? ` · 阿禾猜中 ${g.hit}/${g.total}` : ''}` });
      await sleep(600);
      push({ kind:'photo' });
    }
    setBusy(false);
  }
  function answerGuess(m, yes){
    if (m.resp || busy) return;
    upd(x => ({ ...x, msgs:x.msgs.map(y => y.id === m.id ? { ...y, resp: yes ? 'yes' : 'no' } : y),
      guessStat:{ hit:(x.guessStat.hit || 0) + (yes ? 1 : 0), total:(x.guessStat.total || 0) + 1 },
      log:[...x.log, { key:'g' + uid(), cat:'阿禾记下的', q:'阿禾的猜测', a:(yes ? '猜对了：' : '不太对：') + m.text.replace(/^我猜，?/, '').slice(0, 30) }] }));
    if (m.gid) api('/api/ahe/guess/' + m.gid, { resp: yes ? 'yes' : 'no' }).then(r => r && r.guessStat && upd(x => ({ ...x, guessStat:r.guessStat }))).catch(() => {});
    if (yes) { setFlash('happy'); setTimeout(() => setFlash(null), 2600); }
    else { setFlash('shy'); setTimeout(() => setFlash(null), 1800); }
    send(yes ? '猜对了' : '不太对', { fromGuess:true });
  }
  async function photoDone(mid, saved){
    setBusy(true);
    upd(x => ({ ...x, msgs:x.msgs.map(m => m.id === mid ? { ...m, done:true } : m) }));
    const count = photos.length;
    push({ kind:'me', text: saved ? `放好了 ${count} 张` : '以后再说' });
    upd(x => ({ ...x, log:[...x.log.filter(l => l.key !== 'photos'), { key:'photos', cat:'初次见面', q:'照片', a: saved ? `${count} 张 · 人工审核中` : '暂未上传' }] }));
    await bubbles([saved ? '收到。现在只有审核同事能看到。等你们互相愿意认识，对方才会看到。' : '没关系，想放的时候在「我」里随时可以加。']);
    setTyping(true);
    let s = null;
    try { await saveNow(obRef.current); s = (await withTimeout(api('/api/ahe/summary', {}), 25000)).summary; } catch (e) { await sleep(800); }
    setTyping(false);
    const sum = s && s.headline ? { headline:clean(s.headline), about:clean(s.about || ''), traits:(s.traits || []).slice(0, 4).map(String) } : null;
    if (sum) onSummary(sum);
    push({ kind:'reveal', s:sum });
    await sleep(500);
    await bubbles(['有合适的人，我会写成一封信放在「聊天」里，也会发邮件告诉你。']);
    upd(x => ({ ...x, mood:'listening' }));
    setBusy(false);
  }
  async function forgetSeed(id){
    setSeeds(prev => prev.filter(x => x.id !== id));
    try { const r = await api('/api/me/seeds/' + id, null, 'DELETE'); if (r.seeds) setSeeds(r.seeds); } catch (e) {}
  }

  const lastKind = ob.msgs.length ? ob.msgs[ob.msgs.length - 1].kind : '';
  const pendingGuess = ob.msgs.some(m => m.kind === 'guess' && !m.resp);
  const photoOpen = ob.msgs.some(m => m.kind === 'photo' && !m.done);
  const sugg = !busy && !typing && lastKind !== 'me' && !pendingGuess ? (ob.suggestions || []) : [];
  const starters = ob.firstDone && !busy && !typing && lastKind !== 'me' && !sugg.length && !photoOpen ? ['今天有点累','有件事想说说','睡不着'] : [];

  return (
    <div className="screen ahe-screen" style={{ display:visible ? 'flex' : 'none' }}>
      <div className="safe"/>
      <div className="ahehead">
        <Mascot state={mood} size={38}/>
        <div style={{ flex:1, lineHeight:1.3 }}>
          <div className="nm">阿禾</div>
          <div className="st">{MOOD_WORD[mood] || '在听'}</div>
        </div>
        <button className="iconbtn" style={{ position:'relative' }} onClick={() => { setDrawer(true); upd(x => ({ ...x, memNew:0 })); }} title="阿禾记得的" aria-label="阿禾记得的">
          <I.lock s={18}/>{ob.memNew > 0 && <span className="memdot"/>}
        </button>
      </div>
      <div className="scroll" ref={scRef}>
        <div className="letterhead">
          <div className="date">{letterDate()}</div>
          <div className="note"><I.lock s={12}/>这页纸只有你和阿禾看得到</div>
        </div>
        <div className="lettersheet">
          <div className="msgs">
            {ob.msgs.map(m => {
              if (m.kind === 'done') return <div key={m.id} className="donepill pop">{m.text}</div>;
              if (m.kind === 'guess') return (
                <div key={m.id} className="guess pop">
                  <div className="lab">阿禾猜一猜</div>
                  <p style={{ position:'relative' }}>{m.text}</p>
                  {!m.resp ? (
                    <div className="acts" style={{ position:'relative' }}>
                      <button className="yes" onClick={() => answerGuess(m, true)}>猜对了</button>
                      <button onClick={() => answerGuess(m, false)}>不太对</button>
                    </div>
                  ) : m.resp !== 'skip' ? <div className="res">{m.resp === 'yes' ? '— 被猜中了' : '— 没猜中'}</div> : null}
                </div>
              );
              if (m.kind === 'photo') return <PhotoCard key={m.id} m={m} photos={photos} setPhotos={setPhotos} onDone={(s) => photoDone(m.id, s)}/>;
              if (m.kind === 'reveal') return <RevealCard key={m.id} ob={ob} s={m.s} seeds={seeds} onGoMe={onGoMe} onGoChat={onGoChat}/>;
              if (m.kind === 'me') return <div key={m.id} className="me-line pop">{m.text}</div>;
              if (m.kind === 'ai') return <div key={m.id} className="ai-line rise">{m.text}</div>;
              return null;
            })}
            {typing && <Typing/>}
          </div>
        </div>
        <div style={{ height:16 }}/>
      </div>
      <div className="dock">
        {(sugg.length > 0 || starters.length > 0) && (
          <div className="suggest">
            {sugg.map((s, i) => <button key={s + i} className={/猜/.test(s) ? 'g' : ''} style={{ animationDelay:i * 50 + 'ms' }} onClick={() => send(s)}>{s}</button>)}
            {starters.map((s, i) => <button key={s} style={{ animationDelay:i * 50 + 'ms' }} onClick={() => send(s)}>{s}</button>)}
          </div>
        )}
        <div className={'composer' + (focus ? ' focus' : '')}>
          <textarea rows={1} value={input} placeholder={ob.placeholder || '想说什么，写在这里…'} maxLength={1000}
            onFocus={() => setFocus(true)} onBlur={() => setFocus(false)} onChange={e => setInput(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) { e.preventDefault(); send(input); } }}/>
          <button className="sendbtn" disabled={!input.trim() || busy} onClick={() => send(input)} aria-label="发送"><I.send s={18}/></button>
        </div>
      </div>
      {drawer && createPortal(<Memory ob={ob} seeds={seeds} onForget={(key) => upd(x => ({ ...x, log:x.log.filter(l => l.key !== key) }))} onForgetSeed={forgetSeed} onClose={() => setDrawer(false)}/>, document.querySelector('.phone') || document.body)}
    </div>
  );
}

function RevealCard({ ob, s, seeds, onGoMe, onGoChat }){
  const pf = buildProfile(ob, s, null, seeds);
  return (
    <div className="revealcard pop">
      <div className="row gap8"><Mascot state="happy" size={30}/><span className="eyebrow">阿禾眼中的你</span></div>
      <div className="kai" style={{ fontSize:22, marginTop:12, letterSpacing:'.04em', lineHeight:1.5 }}>{pf.headline}</div>
      <p style={{ marginTop:8, fontSize:14.5, color:'var(--ink-2)', lineHeight:1.8 }}>{pf.about}</p>
      {pf.traits.length > 0 && <div className="tags" style={{ marginTop:12 }}>{pf.traits.map((t, i) => <span key={i} className="chip">{t.label}</span>)}</div>}
      <div className="row gap12" style={{ marginTop:16, justifyContent:'space-between' }}>
        <button className="textbtn" onClick={onGoMe}>去「我」里看看 →</button>
        <button className="tiny row gap6" onClick={onGoChat}><I.mail s={13}/>聊天</button>
      </div>
    </div>
  );
}

export function PhotoSlots({ photos, setPhotos }){
  const [busy, setBusy] = useState(false);
  const add = async (file) => { if (!file) return; setBusy(true); try { const r = await uploadPhoto(file); setPhotos(r.photos); } catch (e) { alert('上传没成功，换一张试试'); } setBusy(false); };
  const rm = async (id) => { try { const r = await api('/api/me/photos/' + id, null, 'DELETE'); setPhotos(r.photos); } catch (e) {} };
  return (
    <div className="slots">
      {[0, 1, 2].map(i => (
        <div className="slot" key={i}>
          {photos[i] ? (<><img src={photoUrl(photos[i])} alt=""/><button className="rm" onClick={() => rm(photos[i])} aria-label="删除"><I.x s={13}/></button></>)
            : i === photos.length && busy ? <div className="spin" style={{ width:24, height:24 }}/>
            : (<><I.plus s={22}/><input type="file" accept="image/*" onChange={e => { add(e.target.files[0]); e.target.value = ''; }}/></>)}
        </div>
      ))}
    </div>
  );
}
function PhotoCard({ m, photos, setPhotos, onDone }){
  if (m.done) return null;
  return (
    <div className="photocard pop">
      <div className="row gap8"><Mascot state="shy" size={30}/><div className="kai" style={{ fontSize:19 }}>放一两张照片？</div></div>
      <div className="tiny" style={{ marginTop:4 }}>日常的就好。这里每一位都是真人。</div>
      <PhotoSlots photos={photos} setPhotos={setPhotos}/>
      <div className="plist">
        <div><I.check s={14} w={2}/><span>只有<b style={{ fontWeight:500 }}>审核同事</b>和<b style={{ fontWeight:500 }}>你们互相愿意认识之后的那个人</b>能看到</span></div>
        <div><I.check s={14} w={2}/><span>审核只确认是否本人、照片是否清晰</span></div>
        <div><I.check s={14} w={2}/><span>不进入任何列表，没人能搜到，随时可删</span></div>
      </div>
      <div className="row gap8" style={{ marginTop:14 }}>
        <button className="btn ghost sm" style={{ flex:1 }} onClick={() => onDone(false)}>以后再说</button>
        <button className="btn sm" style={{ flex:1 }} disabled={!photos.length} onClick={() => onDone(true)}>放好了</button>
      </div>
    </div>
  );
}

export function Memory({ ob, seeds, onForget, onForgetSeed, onClose }){
  const g = ob.guessStat || { hit:0, total:0 };
  const log = memOf(ob);
  return (
    <div className="overlay" onClick={onClose}>
      <div className="sheet" onClick={e => e.stopPropagation()}>
        <div className="grab"/>
        <div className="pad" style={{ paddingTop:6, paddingBottom:12 }}>
          <div className="row gap12"><Mascot state="listening" size={42}/><div><div className="kai" style={{ fontSize:22 }}>阿禾记得的</div>{g.total > 0 && <div className="tiny">猜中你 {g.hit}/{g.total} 次</div>}</div></div>
          <div className="plist" style={{ marginTop:14 }}>
            <div><I.lock s={14} w={2}/><span>你和阿禾的聊天只有你能看到，不会给任何人。</span></div>
            <div><I.check s={14} w={2}/><span>阿禾记下的事，只用来更懂你、为你挑人。</span></div>
          </div>
        </div>
        <div className="scroll pad" style={{ paddingBottom:26 }}>
          {(seeds || []).length > 0 && <>
            <div className="eyebrow" style={{ margin:'8px 0 4px' }}>生活碎片 · 以后可能变成约会的地方</div>
            {seeds.slice().reverse().map(sd => <SeedRow key={sd.id} sd={sd} onForget={() => onForgetSeed(sd.id)}/>)}
          </>}
          <div className="eyebrow" style={{ margin:'22px 0 4px' }}>零碎的事 · 删去就真的忘了</div>
          {!log.length && <div style={{ textAlign:'center', padding:'20px 0' }}><Mascot state="sleeping" size={56}/><p className="tiny" style={{ marginTop:6 }}>还没有记下什么。</p></div>}
          {log.slice().reverse().map(l => (
            <div key={l.key} className="memitem">
              <div><div className="q">{l.q && !['关于你','阿禾记下的','聊天时提到'].includes(l.q) ? l.q : (l.cat || '阿禾记下的')}</div><div className="a">{l.a}</div></div>
              <button className="tiny" style={{ flex:'none' }} onClick={() => onForget(l.key)}>删去</button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
