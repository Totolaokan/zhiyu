export class ApiError extends Error { constructor(status, code, body) { super(code); this.status = status; this.code = code; this.body = body; } }
export async function api(path, body, method) {
  const res = await fetch(path, {
    method: method || (body === undefined || body === null ? 'GET' : 'POST'),
    headers: body ? { 'Content-Type': 'application/json' } : {},
    body: body ? JSON.stringify(body) : undefined,
    credentials: 'same-origin',
  });
  let j = null; try { j = await res.json(); } catch (e) {}
  if (!res.ok) throw new ApiError(res.status, (j && j.error) || 'HTTP_' + res.status, j);
  return j || {};
}
export const photoUrl = (id) => '/api/photos/' + id;
// downscale on the phone before upload: max 1280px, JPEG
export async function uploadPhoto(file) {
  const img = await new Promise((ok, bad) => { const u = URL.createObjectURL(file); const i = new Image(); i.onload = () => ok(i); i.onerror = bad; i.src = u; });
  const k = Math.min(1, 1280 / Math.max(img.width, img.height));
  const cv = document.createElement('canvas'); cv.width = Math.round(img.width * k); cv.height = Math.round(img.height * k);
  cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height);
  const blob = await new Promise((ok) => cv.toBlob(ok, 'image/jpeg', 0.85));
  const res = await fetch('/api/me/photos', { method: 'POST', headers: { 'Content-Type': 'image/jpeg' }, body: blob, credentials: 'same-origin' });
  const j = await res.json().catch(() => ({}));
  if (!res.ok) throw new ApiError(res.status, j.error || 'UPLOAD_FAILED', j);
  return j;
}
