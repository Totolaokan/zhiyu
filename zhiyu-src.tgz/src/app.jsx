import React, { useState, useEffect, useRef, useCallback } from 'react';
import { createRoot } from 'react-dom/client';
import { api, photoUrl } from './api.js';
import { AheTab, Memory, PhotoSlots, buildProfile, I, Typing, Ahe, Toggle, Portrait, INTENTS, MAXQ, clean, sleep, uid } from './core.jsx';

const freshOb = () => ({ msgs:[], ans:{}, log:[], node:'name', mode:'free', phase:'idle', asked:0, firstDone:false, curOpts:null, curGuess:-1, guessStat:{ hit:0, total:0 }, resumeNode:null, started:false, freeSince:0, memNew:0 });
const TONES = [['#F1D9BE','#B08C6C','#D9A988'],['#DCE8DA','#86A08D','#B9CDB8'],['#D5DDEA','#7D8DA8','#AAB7CF'],['#F3E6D2','#C5A27F','#E2C29E'],['#E4DCE8','#9585A2','#C0B2CB']];
const person = (o) => ({ name: (o && o.name || '友').replace(/^【测试】/, ''), tone: TONES[((o && o.id) || 0) % TONES.length] });
const ago = (t) => { if (!t) return ''; const d = (Date.now() - new Date(t).getTime()) / 1000; if (d < 60) return '刚刚'; if (d < 3600) return Math.floor(d / 60) + ' 分钟前'; if (d < 86400) return Math.floor(d / 3600) + ' 小时前'; return Math.floor(d / 86400) + ' 天前'; };

/* ============ Login ============ */
function Login({ cfg, onDone }){
  const [email, setEmail] = useState('');
  const [step, setStep] = useState('email');
  const [code, setCode] = useState('');
  const [testCode, setTestCode] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const ERR = { BAD_EMAIL:'邮箱格式好像不对', WAIT:'发得太快了，稍等几十秒再试', TOO_MANY:'尝试太多次了，过一会儿再来', CODE_WRONG:'验证码不对，再看一眼', CODE_EXPIRED:'验证码过期了，重新发一个', EMAIL_NOT_CONFIGURED:'邮件服务还没配置好，请联系我们' };
  async function send(){
    setErr(''); setBusy(true);
    try { const r = await api('/api/auth/request', { email: email.trim() }); setTestCode(r.testCode || ''); setStep('code'); }
    catch (e) { setErr(ERR[e.code] || '没发出去，再试一次'); }
    setBusy(false);
  }
  async function verify(c){
    setErr(''); setBusy(true);
    try { await api('/api/auth/verify', { email: email.trim(), code: c || code }); onDone(); }
    catch (e) { setErr(ERR[e.code] || '没登上，再试一次'); setBusy(false); }
  }
  return (
    <div className="screen night">
      <div className="bgorbs">
        <div className="orb" style={{ width:320, height:320, left:-140, top:-90, background:'#2F6A55', opacity:.6 }}/>
        <div className="orb" style={{ width:260, height:260, right:-130, top:160, background:'#C47F5B', opacity:.38, animationDelay:'-5s' }}/>
      </div>
      <div className="scroll" style={{ position:'relative' }}>
        <div className="pad" style={{ paddingTop:72, paddingBottom:40 }}>
          <div className="aheorb rise" style={{ width:56, height:56 }}/>
          <div className="display rise" style={{ marginTop:26, animationDelay:'.05s' }}>知遇</div>
          <p className="rise" style={{ marginTop:10, fontSize:16, color:'rgba(255,255,255,.72)', lineHeight:1.7, animationDelay:'.1s' }}>不用刷人。<br/>阿禾先认识你，再慢慢为你介绍合适的人。</p>
          <div className="rise" style={{ marginTop:34, animationDelay:'.15s' }}>
            {step === 'email' ? (<>
              <div className="inputrow"><input type="email" autoComplete="email" value={email} placeholder="你的邮箱" onChange={e => setEmail(e.target.value)} onKeyDown={e => e.key === 'Enter' && email.trim() && send()}/></div>
              <button className="btn" style={{ marginTop:12 }} disabled={!email.trim() || busy} onClick={send}>{busy ? '发送中…' : '获取验证码'}</button>
              <p className="tiny" style={{ marginTop:12, textAlign:'center' }}>不用密码。我们会往邮箱发一个 6 位验证码，新邮箱会自动注册。</p>
            </>) : (<>
              <div className="tiny" style={{ marginBottom:8 }}>验证码已发到 {email}</div>
              {testCode && <div className="testbox"><b>测试模式</b>邮件服务还没接上，验证码直接显示在这里：<span className="num" style={{ fontSize:26, letterSpacing:'.12em', display:'block', marginTop:4 }}>{testCode}</span></div>}
              <div className="inputrow"><input inputMode="numeric" autoComplete="one-time-code" maxLength={6} value={code} placeholder="6 位验证码" onChange={e => { const v = e.target.value.replace(/\D/g, ''); setCode(v); if (v.length === 6) verify(v); }}/></div>
              <button className="btn" style={{ marginTop:12 }} disabled={code.length !== 6 || busy} onClick={() => verify()}>{busy ? '登录中…' : '进入知遇'}</button>
              <button className="tiny" style={{ marginTop:14, display:'block', marginLeft:'auto', marginRight:'auto' }} onClick={() => { setStep('email'); setCode(''); setTestCode(''); }}>换个邮箱</button>
            </>)}
            {err && <p style={{ marginTop:12, color:'#F3BFA3', fontSize:13.5, textAlign:'center' }}>{err}</p>}
          </div>
          <div className="rise" style={{ marginTop:40, animationDelay:'.2s' }}>
            <div className="feat"><div className="ic"><I.lock s={17}/></div><div>和阿禾的聊天只有你能看到<div className="s">它只用来更懂你、为你挑人</div></div></div>
            <div className="feat"><div className="ic"><I.eyeoff s={17}/></div><div>没人能搜到你，也不会被熟人刷到<div className="s">只有互相愿意，才会互相知道</div></div></div>
            <div className="feat"><div className="ic"><I.mail s={17}/></div><div>不用天天打开<div className="s">有合适的人，阿禾会写信告诉你</div></div></div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ============ Chats ============ */
function IntroCard({ it, onDecide }){
  const [passing, setPassing] = useState(false);
  const [busy, setBusy] = useState(false);
  const p = person(it.other);
  const go = async (d) => { setBusy(true); await onDecide(it, d); setBusy(false); };
  return (
    <div className="lettercard rise" style={{ cursor:'default' }}>
      <div className="orb" style={{ width:200, height:200, right:-70, top:-90, background:'#C47F5B', opacity:.55 }}/>
      <div className="orb" style={{ width:180, height:180, left:-70, bottom:-90, background:'#3F7A63', opacity:.6, animationDelay:'-6s' }}/>
      <div style={{ position:'relative' }}>
        <div className="row gap8"><div className="aheorb" style={{ width:26, height:26 }}/><span className="tiny" style={{ color:'rgba(255,255,255,.6)' }}>阿禾的来信 · {ago(it.createdAt)}</span></div>
        <div className="row gap12" style={{ marginTop:14 }}>
          <Portrait p={p} size={56}/>
          <div style={{ flex:1, minWidth:0, textAlign:'left' }}>
            <div style={{ fontWeight:700, fontSize:19 }}>{p.name}{it.other.isTest && <span className="chip ap" style={{ marginLeft:8, verticalAlign:'middle' }}>测试用户</span>}</div>
            <div className="tiny" style={{ color:'rgba(255,255,255,.55)' }}>{it.other.city || '城市未填'} · 照片互相愿意后可见</div>
          </div>
        </div>
        <p style={{ marginTop:14, fontSize:15.5, lineHeight:1.7, color:'rgba(255,255,255,.88)', textAlign:'left' }}>{it.reason || '阿禾觉得你们可以认识一下。'}</p>
        {it.waiting ? <div className="tiny" style={{ marginTop:14, color:'rgba(255,255,255,.6)' }}>已悄悄告诉 TA。TA 也愿意时，聊天会打开。</div>
          : passing ? (
            <div style={{ marginTop:14 }}>
              <div className="tiny" style={{ color:'rgba(255,255,255,.55)', marginBottom:8 }}>TA 不会知道。确定这次先不了？</div>
              <div className="row gap8"><button className="btn ghost sm" style={{ flex:1, color:'#fff', borderColor:'rgba(255,255,255,.2)' }} onClick={() => setPassing(false)}>再想想</button><button className="btn sm" style={{ flex:1, background:'#EBD3BF', color:'#1E2B25' }} disabled={busy} onClick={() => go('no')}>这次先不了</button></div>
            </div>
          ) : (
            <div className="row gap8" style={{ marginTop:16 }}>
              <button className="btn ghost sm" style={{ flex:1, color:'rgba(255,255,255,.75)', borderColor:'rgba(255,255,255,.2)' }} onClick={() => setPassing(true)}>这次先不了</button>
              <button className="btn sm" style={{ flex:1.4, background:'#EBD3BF', color:'#1E2B25' }} disabled={busy} onClick={() => go('yes')}>想认识 TA</button>
            </div>
          )}
      </div>
    </div>
  );
}

function ChatList({ intros, firstDone, onOpen, onGoAhe, onDecide }){
  const pending = intros.filter(i => !i.open && !i.waiting);
  const waiting = intros.filter(i => !i.open && i.waiting);
  const rooms = intros.filter(i => i.open);
  const empty = !intros.length;
  return (
    <div className="scroll tabpage">
      <div className="pad" style={{ paddingTop:24 }}>
        <div className="title rise" style={{ fontSize:30 }}>聊天</div>
        {empty ? (
          <div className="emptyhero">
            <div style={{ position:'relative', height:150, width:220, margin:'0 auto' }}>
              <div className="breath" style={{ position:'absolute', left:20, top:10, width:120, height:120, borderRadius:'50%', background:'radial-gradient(circle at 35% 30%,#E3EEE7,#A9C8B6)', opacity:.9 }}/>
              <div className="breath" style={{ position:'absolute', right:20, top:30, width:110, height:110, borderRadius:'50%', background:'radial-gradient(circle at 35% 30%,#FBE3D3,#E8AE8C)', opacity:.85, mixBlendMode:'multiply', animationDelay:'-2s' }}/>
            </div>
            <div className="h3 rise" style={{ marginTop:18 }}>还没有对话</div>
            <p className="sub rise" style={{ marginTop:6, animationDelay:'.06s' }}>阿禾为你挑到合适的人，<br/>会写成一封信放在这里，也会发邮件告诉你。</p>
            {!firstDone && (
              <div className="card rise" style={{ marginTop:26, padding:16, textAlign:'left', animationDelay:'.18s' }}>
                <div className="row" style={{ justifyContent:'space-between' }}>
                  <div><div className="h3" style={{ fontSize:15 }}>先和阿禾见一面</div><div className="tiny">聊几句，信才知道该写给谁</div></div>
                  <button className="btn sm" onClick={onGoAhe}>去聊</button>
                </div>
              </div>
            )}
          </div>
        ) : (
          <div style={{ marginTop:18 }}>
            {pending.map(it => <IntroCard key={it.id} it={it} onDecide={onDecide}/>)}
            {rooms.map((it, i) => (
              <button key={it.id} className="card pcard rise" style={{ animationDelay:i * 60 + 'ms' }} onClick={() => onOpen(it.id)}>
                <Portrait p={person(it.other)} size={54}/>
                <div style={{ flex:1, minWidth:0 }}>
                  <div className="row" style={{ justifyContent:'space-between' }}><span className="nm" style={{ fontSize:16 }}>{person(it.other).name}</span><span className="tiny">{it.last ? ago(it.last.at) : ''}</span></div>
                  <div className="ln">{it.last ? it.last.text : '房间已准备好'}</div>
                </div>
                {it.unread && <span style={{ width:9, height:9, borderRadius:'50%', background:'var(--apricot)', flex:'none' }}/>}
              </button>
            ))}
            {waiting.length > 0 && <div className="eyebrow" style={{ margin:'22px 0 10px' }}>等待回应</div>}
            {waiting.map(it => (
              <div key={it.id} className="row gap12" style={{ padding:'8px 4px', opacity:.7 }}>
                <Portrait p={person(it.other)} size={40}/><div style={{ flex:1 }}><div style={{ fontWeight:500 }}>{person(it.other).name}</div><div className="tiny">TA 也愿意时，会提醒你</div></div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function RoomView({ id, onBack, flash }){
  const [room, setRoom] = useState(null);
  const [msgs, setMsgs] = useState([]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const [wxOpen, setWxOpen] = useState(false);
  const [photoView, setPhotoView] = useState(false);
  const lastId = useRef(0);
  const scRef = useRef(null);
  const load = useCallback(async () => {
    try {
      const r = await api(`/api/rooms/${id}?after=${lastId.current}`);
      setRoom(r.room);
      if (r.msgs.length || r.updates.length) {
        setMsgs(prev => {
          const map = new Map(prev.map(m => [m.id, m]));
          [...r.updates, ...r.msgs].forEach(m => map.set(m.id, m));
          return [...map.values()].sort((a, b) => a.id - b.id);
        });
        if (r.msgs.length) lastId.current = r.msgs[r.msgs.length - 1].id;
      }
    } catch (e) {}
  }, [id]);
  useEffect(() => { load(); const t = setInterval(load, 3000); return () => clearInterval(t); }, [load]);
  useEffect(() => { const el = scRef.current; if (el) setTimeout(() => el.scrollTo({ top: el.scrollHeight, behavior:'smooth' }), 30); }, [msgs.length]);
  const after = async (p) => { try { await p; } catch (e) { flash('没发出去，再试一次'); } load(); };
  async function send(t){ t = (t || '').trim(); if (!t || sending) return; setSending(true); setInput(''); await after(api(`/api/rooms/${id}/messages`, { text:t })); setSending(false); }
  const game = (type) => after(api(`/api/rooms/${id}/game`, { type }));
  const answer = (m, a) => after(api(`/api/rooms/${id}/game/${m.id}`, { answer:a }));
  const [topicBusy, setTopicBusy] = useState(false);
  const topic = async () => { setTopicBusy(true); await after(api(`/api/rooms/${id}/topic`, {})); setTopicBusy(false); };
  if (!room) return <div className="screen fade" style={{ position:'absolute', inset:0, background:'var(--bg)', zIndex:40, alignItems:'center', justifyContent:'center' }}><div className="spin"/></div>;
  const p = person(room.other);
  const hostOn = room.hostOn;
  return (
    <div className="screen fade" style={{ position:'absolute', inset:0, background:'var(--bg)', zIndex:40 }}>
      <div className="safe"/>
      <div className="row gap8" style={{ padding:'4px 14px 10px', flex:'none' }}>
        <button className="iconbtn" onClick={onBack}><I.back/></button>
        <button onClick={() => room.otherPhotos.length && setPhotoView(true)} style={{ borderRadius:'50%', overflow:'hidden', width:38, height:38, flex:'none' }}>
          {room.otherPhotos.length ? <img src={photoUrl(room.otherPhotos[0])} style={{ width:38, height:38, objectFit:'cover' }}/> : <Portrait p={p} size={38}/>}
        </button>
        <div style={{ flex:1, lineHeight:1.3, minWidth:0 }}>
          <div style={{ fontWeight:700 }}>{p.name}</div>
          <button className="tiny row" style={{ gap:4 }} onClick={() => after(api(`/api/rooms/${id}/host`, { on:!hostOn }))}><I.sprout s={12}/>{hostOn ? '阿禾在场' : '阿禾已安静'}</button>
        </div>
        <button className="chip" style={{ padding:'7px 13px', fontSize:12.5 }} onClick={() => setWxOpen(true)}>{room.wx && room.wx.theirs ? '已加微信' : '交换微信'}</button>
      </div>
      <div className="scroll" ref={scRef}>
        <div className="msgs" style={{ paddingTop:4 }}>
          {msgs.filter(m => hostOn || m.kind !== 'host').map(m => <RoomMsg key={m.id} m={m} p={p} onIce={(t) => send(t)} onAnswer={answer}/>)}
        </div>
      </div>
      <div className="toolbar">
        <button onClick={() => game('wyr')}><I.dice s={15}/>二选一</button>
        <button onClick={() => game('q')}><I.spark s={15}/>问题卡</button>
        <button onClick={topic} disabled={topicBusy}><I.sprout s={15}/>{topicBusy ? '阿禾在想…' : '给个话题'}</button>
      </div>
      <div className="composer inputrow">
        <textarea rows={1} value={input} placeholder={`和${p.name}说点什么`} onChange={e => setInput(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) { e.preventDefault(); send(input); } }}/>
        <button className="sendbtn" disabled={!input.trim() || sending} onClick={() => send(input)}><I.send s={19}/></button>
      </div>
      {wxOpen && <WechatSheet id={id} p={p} wx={room.wx} onClose={() => setWxOpen(false)} reload={load}/>}
      {photoView && (
        <div className="overlay" onClick={() => setPhotoView(false)} style={{ justifyContent:'center', padding:20 }}>
          <div className="row gap8" style={{ overflowX:'auto' }}>{room.otherPhotos.map(ph => <img key={ph} src={photoUrl(ph)} style={{ maxHeight:'70vh', maxWidth:'85%', borderRadius:18 }}/>)}</div>
        </div>
      )}
    </div>
  );
}

function RoomMsg({ m, p, onIce, onAnswer }){
  const [ans, setAns] = useState('');
  const pl = m.payload || {};
  if (m.from === 'sys') return <div className="sysline">{m.text}</div>;
  if (m.from === 'me') return <div className="bub me pop">{m.text}</div>;
  if (m.from === 'them') return <div className="msgrow pop"><Portrait p={p} size={28}/><div className="bub them">{m.text}</div></div>;
  if (m.kind === 'host') return <div className="hostnote fade"><I.sprout s={14}/><span>{m.text}</span></div>;
  if (m.kind === 'ice') return (
    <div className="game pop">
      <div className="gl"><I.chat s={13}/>开场卡 · 点一下就发出去</div>
      {(pl.items || []).map((t, i) => <button key={i} className="gopt" onClick={() => onIce(t)}>{t}<I.send s={15}/></button>)}
    </div>
  );
  if (m.kind === 'wyr') return (
    <div className="game pop">
      <div className="gl"><I.dice s={13}/>二选一</div>
      {[pl.a, pl.b].map(o => (
        <button key={o} className={'gopt' + (pl.mine === o ? ' sel' : '')} disabled={!!pl.mine} onClick={() => onAnswer(m, o)}>
          <span>{o}</span><span className="who">{[pl.mine === o ? '你' : null, pl.theirs === o ? p.name : null].filter(Boolean).join(' · ')}</span>
        </button>
      ))}
      {pl.mine && !pl.theirs && <p className="tiny" style={{ marginTop:8 }}>{pl.theirsDone ? '' : `等 ${p.name} 选…`}</p>}
    </div>
  );
  if (m.kind === 'q') return (
    <div className="game pop">
      <div className="gl"><I.spark s={13}/>问题卡</div>
      <p style={{ fontSize:17, fontWeight:700, lineHeight:1.5, letterSpacing:'-.01em' }}>{pl.q}</p>
      {!pl.mine ? (
        <div className="inputrow" style={{ marginTop:12 }}>
          <input value={ans} onChange={e => setAns(e.target.value)} placeholder="你的答案" onKeyDown={e => { if (e.key === 'Enter' && ans.trim() && !e.nativeEvent.isComposing) onAnswer(m, ans.trim()); }}/>
          <button className="sendbtn" disabled={!ans.trim()} onClick={() => onAnswer(m, ans.trim())}><I.send s={18}/></button>
        </div>
      ) : !pl.theirs ? <p className="tiny" style={{ marginTop:10 }}>等 {p.name} 写完，一起揭晓…</p> : (
        <div className="fade"><div className="qa"><b>你</b>{pl.mine}</div><div className="qa"><b>{p.name}</b>{pl.theirs}</div></div>
      )}
    </div>
  );
  return null;
}

function WechatSheet({ id, p, wx, onClose, reload }){
  const [val, setVal] = useState(wx && wx.mine || '');
  const [copied, setCopied] = useState('');
  const submit = async () => { try { await api(`/api/rooms/${id}/wechat`, { wx:val.trim() }); } catch (e) {} reload(); };
  const copy = async (t) => { try { await navigator.clipboard.writeText(t); setCopied(t); setTimeout(() => setCopied(''), 1500); } catch (e) {} };
  const state = !wx || !wx.mine ? 'none' : wx.theirs ? 'done' : 'pending';
  return (
    <div className="overlay" onClick={onClose}>
      <div className="sheet" onClick={e => e.stopPropagation()}>
        <div className="grab"/>
        <div className="pad" style={{ padding:'10px 22px 28px' }}>
          {state === 'none' && (<>
            <div className="title" style={{ fontSize:24 }}>交换微信</div>
            <p className="sub" style={{ marginTop:6 }}>双方都填了，才会互相显示。<br/>TA 没填，你也不会收到“拒绝”。</p>
            <div className="inputrow" style={{ marginTop:18 }}><input value={val} onChange={e => setVal(e.target.value)} placeholder="你的微信号"/></div>
            <button className="btn" style={{ marginTop:12 }} disabled={!val.trim()} onClick={submit}>同意交换</button>
            <p className="tiny" style={{ textAlign:'center', marginTop:12 }}>我们不挽留。认识彼此，本来就是目的。</p>
          </>)}
          {state === 'pending' && <div style={{ textAlign:'center', padding:'34px 0' }}><div className="spin" style={{ margin:'0 auto' }}/><p className="sub" style={{ marginTop:16 }}>你填好了。等 {p.name} 也愿意时，会互相显示。</p><button className="btn soft" style={{ marginTop:18 }} onClick={onClose}>好</button></div>}
          {state === 'done' && (
            <div className="fade">
              <div className="title" style={{ fontSize:24 }}>都同意了</div>
              {[[p.name, wx.theirs], ['你', wx.mine]].map(([n, w]) => (
                <div key={n} className="memitem" style={{ marginTop:12, padding:'14px 16px', alignItems:'center' }}>
                  <div><div className="q">{n}</div><div className="a" style={{ fontSize:16 }}>{w}</div></div>
                  <button className="chip line" onClick={() => copy(w)}><I.copy s={12}/>{copied === w ? '已复制' : '复制'}</button>
                </div>
              ))}
              <button className="btn soft" style={{ marginTop:16 }} onClick={onClose}>好</button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/* ============ Feed ============ */
function Feed({ flash }){
  const [posts, setPosts] = useState(null);
  const [text, setText] = useState('');
  const [writing, setWriting] = useState(false);
  const load = async () => { try { setPosts((await api('/api/posts')).posts); } catch (e) { setPosts([]); } };
  useEffect(() => { load(); }, []);
  const post = async () => { if (!text.trim()) return; try { await api('/api/posts', { text:text.trim() }); setText(''); setWriting(false); load(); } catch (e) { flash('没发出去'); } };
  const like = async (x) => { setPosts(ps => ps.map(p => p.id === x.id ? { ...p, liked:!p.liked } : p)); try { await api(`/api/posts/${x.id}/like`, {}); } catch (e) {} };
  const del = async (x) => { try { await api(`/api/posts/${x.id}`, null, 'DELETE'); load(); } catch (e) {} };
  const BG = ['linear-gradient(170deg,#C9D3D6,#8E9EA4 60%,#6E7F86)','linear-gradient(170deg,#EADBC5,#CDB08B 70%,#B39064)','linear-gradient(170deg,#E9CFC0,#C9907A 70%,#A86F5A)','linear-gradient(170deg,#D3DECF,#93AD94 70%,#6F8C73)'];
  return (
    <div className="scroll tabpage">
      <div className="pad" style={{ paddingTop:24, paddingBottom:120 }}>
        <div className="row" style={{ justifyContent:'space-between' }}><div className="title" style={{ fontSize:30 }}>动态</div><button className="chip" style={{ padding:'7px 13px' }} onClick={() => setWriting(w => !w)}><I.pen s={13}/>写一条</button></div>
        <p className="sub" style={{ margin:'4px 0 18px' }}>随手记一点生活。只有点赞，没有评论，没有数字。所有知遇用户都能看到。</p>
        {writing && (
          <div className="card pop" style={{ padding:14, marginBottom:14 }}>
            <div className="inputrow"><textarea rows={3} autoFocus value={text} maxLength={500} placeholder="今天看到的、吃到的、想到的…" onChange={e => setText(e.target.value)} style={{ maxHeight:160 }}/></div>
            <div className="row" style={{ justifyContent:'flex-end', marginTop:10 }}><button className="btn sm" disabled={!text.trim()} onClick={post}>发出去</button></div>
          </div>
        )}
        {posts === null && <div className="spin" style={{ margin:'40px auto' }}/>}
        {posts && !posts.length && <p className="tiny" style={{ textAlign:'center', padding:'40px 0' }}>还没有人写。你可以是第一个。</p>}
        {posts && posts.map((x, i) => (
          <div key={x.id} className="card post rise" style={{ animationDelay: Math.min(i, 6) * 60 + 'ms' }}>
            <div className="postimg" style={{ background:BG[x.id % BG.length], height:'auto', minHeight:120, padding:'22px 20px', display:'flex', alignItems:'flex-end' }}>
              <p style={{ position:'relative', color:'#fff', fontSize:17, fontWeight:500, lineHeight:1.6, textShadow:'0 1px 12px rgba(0,0,0,.18)', whiteSpace:'pre-wrap' }}>{x.text}</p>
            </div>
            <div className="row" style={{ justifyContent:'space-between', padding:'10px 16px 12px' }}>
              <span className="row gap8 tiny"><Portrait p={person({ name:x.name, id:x.id })} size={22}/>{x.name.replace(/^【测试】/, '')} · {ago(x.at)}{x.mine && <button className="tiny" style={{ marginLeft:6 }} onClick={() => del(x)}>删除</button>}</span>
              <button onClick={() => like(x)} style={{ color: x.liked ? 'var(--apricot)' : 'var(--muted)', transition:'transform .3s var(--spring)', transform: x.liked ? 'scale(1.15)' : 'none' }}>
                <svg width="22" height="22" viewBox="0 0 24 24" fill={x.liked ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="1.7"><path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z"/></svg>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ============ Me ============ */
function Me({ me, pf, setEdit, prefs, setPrefs, ob, setOb, photos, setPhotos, onGoAhe, onLogout }){
  const a = ob.ans || {};
  const facts = (ob.log || []).filter(l => l.key !== 'photos');
  const name = pf.name && pf.name !== '朋友' ? pf.name : '';
  return (
    <div className="scroll tabpage">
      <div className="pad" style={{ paddingTop:24 }}>
        <div className="row gap12 rise">
          <div style={{ width:64, height:64, borderRadius:22, overflow:'hidden', flex:'none', background:'linear-gradient(145deg,#E3EEE7,#BFD5C8)', display:'flex', alignItems:'center', justifyContent:'center', color:'var(--brand)', fontWeight:700, fontSize:24 }}>
            {photos[0] ? <img src={photoUrl(photos[0])} style={{ width:'100%', height:'100%', objectFit:'cover' }}/> : name ? name[0] : <I.user s={28}/>}
          </div>
          <div style={{ flex:1, minWidth:0 }}>
            <div className="title">{name || '你好'}</div>
            <div className="sub" style={{ marginTop:2 }}>{ob.firstDone ? pf.headline : '阿禾还在认识你'}</div>
          </div>
        </div>

        <div className="card rise" style={{ marginTop:20, padding:16 }}>
          <div className="row" style={{ justifyContent:'space-between' }}>
            <div>
              <div className="h3">{ob.firstDone ? `阿禾记得你 ${facts.length} 件事` : `初次见面 ${ob.asked || 0}/${MAXQ}`}</div>
              <div className="tiny">{ob.guessStat && ob.guessStat.total ? `猜中你 ${ob.guessStat.hit}/${ob.guessStat.total} 次 · ` : ''}{ob.firstDone ? '多聊聊，介绍会更准' : '聊完才会为你介绍人'}</div>
            </div>
            <button className="btn sm" onClick={onGoAhe}>{ob.firstDone ? '找阿禾' : '继续'}</button>
          </div>
        </div>

        {ob.firstDone && pf.about && (
          <div className="sec">
            <div className="sechead"><span className="h3">阿禾眼中的你</span></div>
            <p style={{ fontSize:15, lineHeight:1.75, color:'var(--ink2)' }}>{pf.about}</p>
            {pf.traits.length > 0 && <div className="tags" style={{ marginTop:10 }}>{pf.traits.map((t, i) => <span key={i} className="tag" style={{ paddingRight:14 }}>{t.label}</span>)}</div>}
          </div>
        )}

        <div className="sec">
          <div className="sechead"><span className="h3">基本信息</span></div>
          <div className="list">
            <div className="field"><span>称呼</span><input value={pf.name === '朋友' ? '' : pf.name} placeholder="怎么称呼你" onChange={e => { const v = e.target.value; setEdit(x => ({ ...x, name:v })); }}/></div>
            <div className="field"><span>城市</span><input value={pf.city} placeholder="所在城市" onChange={e => { const v = e.target.value; setEdit(x => ({ ...x, city:v })); }}/></div>
            <div className="field"><span>想认识</span><div className="seg">{['男生','女生','都可以'].map(x => <button key={x} className={pf.seek === x ? 'on' : ''} onClick={() => setEdit(e => ({ ...e, seek:x }))}>{x}</button>)}</div></div>
          </div>
        </div>

        <div className="sec">
          <div className="sechead"><span className="h3">此刻的心意</span><span className="tiny row gap6"><I.lock s={12}/>仅用于匹配，不会显示给别人</span></div>
          <div className="intentgrid">{INTENTS.map(o => <button key={o.k} className={pf.intent === o.v ? 'on' : ''} onClick={() => setEdit(e => ({ ...e, intent:o.v }))}>{o.v}</button>)}</div>
        </div>

        {facts.length > 0 && (
          <div className="sec">
            <div className="sechead"><span className="h3">阿禾记得的事</span><span className="tiny">删掉就真的忘了</span></div>
            {facts.slice(-12).reverse().map(l => (
              <div key={l.key} className="memitem">
                <div>{l.cat === '初次见面' && <div className="q">{l.q}</div>}<div className="a">{l.a}</div></div>
                <button className="tiny" style={{ flex:'none' }} onClick={() => setOb(o => ({ ...o, log:o.log.filter(x => x.key !== l.key) }))}>忘掉</button>
              </div>
            ))}
          </div>
        )}

        <div className="sec">
          <div className="sechead"><span className="h3">照片</span><span className="tiny">{photos.length ? '人工审核中' : '可选，最多 3 张'}</span></div>
          <PhotoSlots photos={photos} setPhotos={setPhotos} blur={false}/>
          <div className="plist" style={{ marginTop:4 }}>
            <div><I.lock s={14} w={2}/><span>谁能看到：只有审核同事，和你们<b style={{ fontWeight:500 }}>互相愿意认识之后</b>的那个人。</span></div>
            <div><I.check s={14} w={2}/><span>不进入任何列表，没人能搜到。外形由同事人工标注，仅用于匹配。</span></div>
          </div>
        </div>

        <div className="sec">
          <div className="sechead"><span className="h3">隐私</span></div>
          <div className="list">
            <div className="field"><span>暂停为我介绍</span><Toggle on={!!prefs.paused} onChange={v => setPrefs(p => ({ ...p, paused:v }))}/></div>
            <div className="field"><span>优先介绍同城的人</span><Toggle on={prefs.sameCity !== false} onChange={v => setPrefs(p => ({ ...p, sameCity:v }))}/></div>
          </div>
          <p className="tiny" style={{ marginTop:10 }}>你和阿禾的聊天只有你能看到。阿禾整理的画像只用于为你挑人。</p>
        </div>

        <div className="sec" style={{ paddingBottom:10 }}>
          <div className="list">
            <div className="field"><span>登录邮箱</span><span className="tiny" style={{ fontSize:13 }}>{me.email}</span></div>
            <div className="field"><button style={{ color:'#A2603F' }} onClick={onLogout}>退出登录</button></div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ============ App ============ */
function Main({ me0, onLogout }){
  const [tab, setTab] = useState('ahe');
  const [ob, setOb] = useState(() => (me0.ob && me0.ob.msgs ? { ...freshOb(), ...me0.ob } : freshOb()));
  const [prefs, setPrefs] = useState({ sameCity:true, ...(me0.prefs || {}) });
  const [edit, setEdit] = useState(me0.edit || {});
  const [summary, setSummary] = useState(me0.summary);
  const [photos, setPhotos] = useState(me0.photos || []);
  const [intros, setIntros] = useState([]);
  const [activeRoom, setActiveRoom] = useState(null);
  const [toast, setToast] = useState('');
  const flash = (t) => { setToast(t); setTimeout(() => setToast(''), 2400); };

  // persistence: debounce-save ob / prefs / edit to the server
  const latest = useRef({ ob, prefs, edit }); latest.current = { ob, prefs, edit };
  const saveNow = useCallback(async (obOverride) => {
    const s = latest.current;
    try { await api('/api/me/state', { ob: obOverride || s.ob, prefs: s.prefs, edit: s.edit }, 'PUT'); } catch (e) {}
  }, []);
  const first = useRef(true);
  useEffect(() => { if (first.current) { first.current = false; return; } const t = setTimeout(() => saveNow(), 700); return () => clearTimeout(t); }, [ob, prefs, edit]);
  useEffect(() => { const h = () => { navigator.sendBeacon && saveNow(); }; window.addEventListener('pagehide', h); return () => window.removeEventListener('pagehide', h); }, []);

  const loadIntros = useCallback(async () => { try { setIntros((await api('/api/intros')).intros); } catch (e) {} }, []);
  useEffect(() => { loadIntros(); const t = setInterval(loadIntros, 10000); return () => clearInterval(t); }, [loadIntros]);
  useEffect(() => { if (tab === 'chat' && !activeRoom) loadIntros(); }, [tab, activeRoom]);

  async function decide(it, d){
    try {
      const r = await api(`/api/intros/${it.id}/decide`, { d });
      await loadIntros();
      if (d === 'no') flash('TA 不会知道');
      else if (r.opened) { flash('你们互相愿意，聊天打开了'); setActiveRoom(it.id); }
      else flash('已悄悄告诉 TA');
    } catch (e) { flash('没成功，再试一次'); }
  }

  const pf = buildProfile(ob, summary, edit);
  const unread = intros.some(i => i.unread);
  const dark = tab === 'ahe' && !activeRoom;

  return (
    <div className="screen">
      <AheTab visible={tab === 'ahe'} ob={ob} setOb={setOb} prefs={prefs} setPrefs={setPrefs} photos={photos} setPhotos={setPhotos} saveNow={saveNow}
        onSummary={setSummary} onGoMe={() => setTab('me')} onGoChat={() => setTab('chat')}/>
      {tab !== 'ahe' && (
        <div className="screen">
          <div className="safe"/>
          <div className="screen">
            {tab === 'chat' && <ChatList intros={intros} firstDone={ob.firstDone} onOpen={setActiveRoom} onGoAhe={() => setTab('ahe')} onDecide={decide}/>}
            {tab === 'feed' && <Feed flash={flash}/>}
            {tab === 'me' && <Me me={me0} pf={pf} setEdit={setEdit} prefs={prefs} setPrefs={setPrefs} ob={ob} setOb={setOb} photos={photos} setPhotos={setPhotos} onGoAhe={() => setTab('ahe')} onLogout={onLogout}/>}
          </div>
        </div>
      )}
      <div className={'tabbar' + (dark ? ' dark' : ' glass')}>
        {[['ahe','阿禾'],['chat','聊天',I.chat],['feed','动态',I.leaf],['me','我',I.user]].map(([k, t, Ic]) => (
          <button key={k} className={tab === k ? 'on' : ''} onClick={() => { setTab(k); setActiveRoom(null); }}>
            {Ic ? <Ic s={23} w={tab === k ? 2 : 1.6}/> : <span className="ahetab"/>}{t}{k === 'chat' && unread && <span className="dot"/>}
          </button>
        ))}
      </div>
      {activeRoom && <RoomView key={activeRoom} id={activeRoom} flash={flash} onBack={() => { setActiveRoom(null); loadIntros(); }}/>}
      {toast && <div className="toast">{toast}</div>}
    </div>
  );
}

function App(){
  const [cfg, setCfg] = useState(null);
  const [me, setMe] = useState(undefined);
  const load = async () => { try { setMe(await api('/api/me')); } catch (e) { setMe(null); } };
  useEffect(() => { api('/api/config').then(setCfg).catch(() => setCfg({})); load(); }, []);
  const logout = async () => { try { await api('/api/auth/logout', {}); } catch (e) {} setMe(null); };
  return (
    <div className="stage">
      <div className="phone">
        {me === undefined ? <div className="screen night" style={{ alignItems:'center', justifyContent:'center' }}><div className="aheorb"/></div>
          : me === null ? <Login cfg={cfg || {}} onDone={load}/>
          : <Main me0={me} onLogout={logout}/>}
      </div>
    </div>
  );
}

createRoot(document.getElementById('root')).render(<App/>);
